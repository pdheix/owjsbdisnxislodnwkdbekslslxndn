#!/usr/bin/env python3
"""
Duck.ai (DuckDuckGo AI Chat) — unofficial Python client.

Implements the protocol used by https://duck.ai/ (verified live):

  1. GET  /                            -> data-version-tag / data-version-sha
  2. GET  /duckchat/v1/capabilities    -> experiment cookies
  3. GET  /duckchat/v1/status          -> JS challenge in header `x-vqd-hash-1`
  4. Solve the challenge with Node + jsdom (solve_challenge.mjs, same folder)
  5. POST /duckchat/v1/chat            -> SSE stream, header `X-Vqd-Hash-1`
  6. Each chat response returns a NEW challenge -> solve it for the next
     message (token rotation).

Requirements: Python 3.10+ (stdlib only), Node 20+, and `npm install jsdom`
(or just use duck_client.mjs which is fully self-contained in Node).

Usage:
    python3 api_client.py "your prompt"
    python3 api_client.py --model claude-haiku-4-5 "your prompt"
    python3 api_client.py --multi
"""

from __future__ import annotations

import argparse
import base64
import gzip
import http.client
import json
import os
import re
import secrets
import subprocess
import sys
import urllib.request
import uuid

BASE = "https://duck.ai"
HERE = os.path.dirname(os.path.abspath(__file__))
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)

FREE_MODELS = [
    "gpt-6-luna",
    "gpt-5.4-mini",
    "claude-haiku-4-5",
    "mistral-small-2603",
    "tinfoil/gpt-oss-120b",
    "tinfoil/gemma4-31b",
]


def solve_challenge(challenge_b64: str) -> str:
    """Run the jsdom solver (solve_challenge.mjs) and return the token."""
    solver = os.path.join(HERE, "solve_challenge.mjs")
    proc = subprocess.run(
        ["node", solver, challenge_b64, UA],
        capture_output=True, text=True, timeout=60,
        cwd=HERE,  # so `import 'jsdom'` resolves to ./node_modules
    )
    if proc.returncode != 0:
        raise RuntimeError(f"challenge solver failed: {proc.stderr.strip()[:500]}")
    return proc.stdout.strip()


class DuckAI:
    def __init__(self) -> None:
        self.cookies: dict[str, str] = {}
        self.fe_version: str | None = None
        self.jsa: str | None = None
        self.journey_id = secrets.token_hex(16)  # x-ddg-journey-id (32 hex)
        self.history: list[dict] = []

    # ------------------------------------------------------------ internals
    def _headers(self, extra: dict | None = None) -> dict:
        h = {
            "User-Agent": UA,
            "Origin": "https://duck.ai",
            "Referer": "https://duck.ai/",
            "Accept-Language": "en-US,en;q=0.9",
            "sec-ch-ua": '"Chromium";v="131", "Google Chrome";v="131", "Not-A.Brand";v="99"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Dest": "empty",
        }
        if self.cookies:
            h["Cookie"] = "; ".join(f"{k}={v}" for k, v in self.cookies.items())
        if extra:
            h.update(extra)
        return h

    def _store_cookies(self, resp) -> None:
        for line in resp.headers.get_all("Set-Cookie") or []:
            pair = line.split(";", 1)[0]
            if "=" in pair:
                k, v = pair.split("=", 1)
                self.cookies[k.strip()] = v.strip()

    def _get(self, path: str, extra: dict | None = None):
        req = urllib.request.Request(BASE + path, headers=self._headers(extra), method="GET")
        resp = urllib.request.urlopen(req, timeout=60)
        self._store_cookies(resp)
        return resp

    # --------------------------------------------------------------- public
    def init(self) -> "DuckAI":
        # 1) frontend version for the x-fe-version header
        resp = self._get("/")
        html = resp.read().decode("utf-8", "ignore")
        tag = re.search(r'data-version-tag="([^"]+)"', html)
        sha = re.search(r'data-version-sha="([^"]+)"', html)
        self.fe_version = f"{tag.group(1) if tag else 'dev'}-{sha.group(1) if sha else 'hash'}"

        # 2) capabilities -> experiment cookies
        self._get("/duckchat/v1/capabilities").read()

        # 3) status + first challenge
        self.refresh_challenge()
        return self

    def refresh_challenge(self) -> None:
        resp = self._get("/duckchat/v1/status", {"x-vqd-accept": "1"})
        body = json.loads(resp.read().decode("utf-8", "ignore") or "{}")
        if body.get("statusV2") not in (None, 0):
            # bitmask: 1=Chat, 2=Images, 4=Voice blocked
            raise RuntimeError(f"service limited (statusV2={body.get('statusV2')})")
        challenge = resp.headers.get("x-vqd-hash-1")
        if not challenge:
            raise RuntimeError("status response had no x-vqd-hash-1 challenge")
        self.jsa = solve_challenge(challenge)

    def chat(self, prompt: str, model: str = "gpt-6-luna", on_token=None) -> str:
        if not self.jsa:
            self.init()
        self.history.append({"role": "user", "content": [{"type": "text", "text": prompt}]})

        signals = base64.b64encode(
            json.dumps({"start": int(__import__("time").time() * 1000), "events": [], "end": 1}).encode()
        ).decode()

        payload = {
            "model": model,
            "messages": self.history,
            "canUseTools": True,
            "reasoningEffort": "none",
            "canUseApproxLocation": False,
            "canDelegateImageGeneration": False,
        }
        # NOTE: the chat endpoint fingerprints the HTTP client. urllib's
        # default headers (Accept-Encoding: identity, Connection: close) get
        # HTTP 418 ERR_BN_LIMIT, so the POST is done with http.client and an
        # explicit browser-like header set/order.
        body_bytes = json.dumps(payload).encode()
        headers = [
            ("Content-Type", "application/json"),
            ("Accept", "text/event-stream"),
            ("x-fe-version", self.fe_version or "dev-hash"),
            ("x-fe-signals", signals),
            ("X-Vqd-Hash-1", self.jsa or "initial"),
            ("x-duckai-response-id", str(uuid.uuid4())),
            ("x-ddg-journey-id", self.journey_id),
            ("x-duckai-continuation", "resubmit-context"),
            ("x-duckai-consent-purposes", "user-location,image-generation,web-search"),
            ("x-duckai-tool-approval", "web-search"),
            ("User-Agent", UA),
            ("Origin", "https://duck.ai"),
            ("Referer", "https://duck.ai/"),
            ("Accept-Language", "en-US,en;q=0.9"),
            ("Accept-Encoding", "gzip"),
            ("sec-ch-ua", '"Chromium";v="131", "Google Chrome";v="131", "Not-A.Brand";v="99"'),
            ("sec-ch-ua-mobile", "?0"),
            ("sec-ch-ua-platform", '"Windows"'),
            ("Sec-Fetch-Site", "same-origin"),
            ("Sec-Fetch-Mode", "cors"),
            ("Sec-Fetch-Dest", "empty"),
        ]
        if self.cookies:
            headers.append(("Cookie", "; ".join(f"{k}={v}" for k, v in self.cookies.items())))

        conn = http.client.HTTPSConnection("duck.ai", timeout=180)
        conn.putrequest("POST", "/duckchat/v1/chat", skip_accept_encoding=True)
        for k, v in headers:
            conn.putheader(k, v)
        conn.putheader("Content-Length", str(len(body_bytes)))
        conn.endheaders(body_bytes)
        resp = conn.getresponse()

        if resp.status != 200:
            detail = resp.read().decode("utf-8", "ignore")[:600]
            # on 418 the server may also rotate the challenge; keep session usable
            nxt = resp.getheader("x-vqd-hash-1")
            conn.close()
            if nxt:
                try:
                    self.jsa = solve_challenge(nxt)
                except Exception:
                    pass
            raise RuntimeError(f"chat HTTP {resp.status}: {detail}")

        for line in resp.msg.get_all("Set-Cookie") or []:
            pair = line.split(";", 1)[0]
            if "=" in pair:
                k, v = pair.split("=", 1)
                self.cookies[k.strip()] = v.strip()
        next_challenge = resp.getheader("x-vqd-hash-1")

        stream = resp
        if (resp.getheader("Content-Encoding") or "").lower() == "gzip":
            stream = gzip.GzipFile(fileobj=resp)

        full: list[str] = []
        buf = ""
        while True:
            chunk = stream.read(4096)
            if not chunk:
                break
            buf += chunk.decode("utf-8", "ignore")
            while "\n\n" in buf:
                frame, buf = buf.split("\n\n", 1)
                for line in frame.split("\n"):
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if not data or data == "[DONE]" or data.startswith("[PING]"):
                        continue
                    if data.startswith("[CHAT_TITLE:"):
                        continue
                    try:
                        ev = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    if ev.get("role") == "assistant" and isinstance(ev.get("message"), str):
                        full.append(ev["message"])
                        if on_token:
                            on_token(ev["message"])

        text = "".join(full)
        self.history.append(
            {"role": "assistant", "content": "", "parts": [{"type": "text", "text": text}]}
        )
        # token rotation for the next message
        if next_challenge:
            self.jsa = solve_challenge(next_challenge)
        return text


def main() -> None:
    ap = argparse.ArgumentParser(description="Duck.ai unofficial client")
    ap.add_argument("prompt", nargs="*", help="prompt text")
    ap.add_argument("--model", default="gpt-6-luna", help=f"model id (free: {', '.join(FREE_MODELS)})")
    ap.add_argument("--multi", action="store_true", help="interactive multi-turn mode")
    args = ap.parse_args()

    client = DuckAI().init()
    if args.multi:
        print("Duck.ai multi-turn chat. Ctrl+C to exit.")
        try:
            while True:
                q = input("\nyou> ").strip()
                if not q:
                    continue
                print("duck> ", end="", flush=True)
                client.chat(q, model=args.model, on_token=lambda t: print(t, end="", flush=True))
                print()
        except (KeyboardInterrupt, EOFError):
            print()
    else:
        prompt = " ".join(args.prompt) or "Say hello in one short sentence."
        client.chat(prompt, model=args.model, on_token=lambda t: print(t, end="", flush=True))
        print()


if __name__ == "__main__":
    main()
