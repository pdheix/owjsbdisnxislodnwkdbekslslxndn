#!/usr/bin/env node
/**
 * Duck.ai (DuckDuckGo AI Chat) — unofficial Node client.
 *
 * Implements the full protocol used by https://duck.ai/ (verified live):
 *   1. GET  /                       -> read data-version-tag / data-version-sha
 *   2. GET  /duckchat/v1/capabilities (stores experiment cookies)
 *   3. GET  /duckchat/v1/status     (header x-vqd-accept: 1)
 *                                   -> challenge in response header x-vqd-hash-1
 *   4. Solve the JS challenge in a jsdom iframe (see solve logic below)
 *   5. POST /duckchat/v1/chat       (SSE stream) with header X-Vqd-Hash-1
 *   6. Every chat response returns a NEW x-vqd-hash-1 challenge; solve it
 *      before the next message (token rotation).
 *
 * Usage:
 *   npm install            (installs jsdom)
 *   node duck_client.mjs "your prompt"
 *   node duck_client.mjs --model claude-haiku-4-5 "your prompt"
 *   node duck_client.mjs --multi          (interactive multi-turn REPL)
 *
 * Free-tier models: gpt-6-luna (default), gpt-5.4-mini, claude-haiku-4-5,
 * mistral-small-2603, tinfoil/gpt-oss-120b, tinfoil/gemma4-31b.
 */
import crypto from 'node:crypto';
import { JSDOM } from 'jsdom';

const BASE = 'https://duck.ai';
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

export const FREE_MODELS = [
  'gpt-6-luna',
  'gpt-5.4-mini',
  'claude-haiku-4-5',
  'mistral-small-2603',
  'tinfoil/gpt-oss-120b',
  'tinfoil/gemma4-31b',
];

// ---------------------------------------------------------------- cookies --
class CookieJar {
  constructor() { this.map = new Map(); }
  storeFrom(res) {
    const set = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    for (const line of set) {
      const [pair] = line.split(';');
      const idx = pair.indexOf('=');
      if (idx > 0) this.map.set(pair.slice(0, idx).trim(), pair.slice(idx + 1).trim());
    }
  }
  header() {
    return [...this.map.entries()].map(([k, v]) => `${k}=${v}`).join('; ');
  }
}

// ------------------------------------------------------------- JSA solver --
async function solveChallenge(challengeB64) {
  const code = Buffer.from(challengeB64, 'base64').toString('utf8');
  const dom = new JSDOM('<!DOCTYPE html><html><head></head><body></body></html>', {
    url: 'https://duck.ai/',
    runScripts: 'outside-only',
    pretendToBeVisual: true,
  });
  const iframe = dom.window.document.createElement('iframe');
  iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin');
  dom.window.document.body.appendChild(iframe);
  const iw = iframe.contentWindow;
  try {
    Object.defineProperty(iw.navigator, 'userAgent', { value: UA, configurable: true });
    Object.defineProperty(iw.navigator, 'webdriver', { value: false, configurable: true });
    const proto = iw.HTMLElement.prototype;
    const dims = { offsetWidth: 12, offsetHeight: 18, clientWidth: 12, clientHeight: 18, scrollWidth: 12, scrollHeight: 18 };
    for (const [k, v] of Object.entries(dims)) {
      Object.defineProperty(proto, k, { get() { return v; }, configurable: true });
    }
    proto.getBoundingClientRect = function () {
      return { x: 0, y: 0, top: 0, left: 0, right: 12, bottom: 18, width: 12, height: 18, toJSON() { return {}; } };
    };
  } catch { /* best effort */ }

  const started = Date.now();
  const result = await iw.eval(code);
  if (!result || typeof result !== 'object' || !('client_hashes' in result)) {
    throw new Error('unexpected challenge result: ' + JSON.stringify(result));
  }
  const sha256B64 = (s) =>
    crypto.createHash('sha256').update(Buffer.from(String(s), 'utf8')).digest().toString('base64');
  let stack = 'no-stack';
  try { throw new Error('jsa'); } catch (e) { stack = String(e.stack || '').split('\n').slice(0, 5).join('\n'); }
  const obj = {
    ...result,
    client_hashes: await Promise.all(result.client_hashes.map(sha256B64)),
    meta: { ...(result.meta || {}), origin: 'https://duck.ai', stack, duration: String(Math.max(1, Date.now() - started)) },
  };
  return Buffer.from(JSON.stringify(obj), 'utf8').toString('base64');
}

// ----------------------------------------------------------------- client --
export class DuckAI {
  constructor() {
    this.jar = new CookieJar();
    this.feVersion = null;   // "<data-version-tag>-<data-version-sha>"
    this.jsa = null;         // solved X-Vqd-Hash-1 token
    this.journeyId = crypto.randomBytes(16).toString('hex'); // 32 hex chars
    this.history = [];       // canonical messages
  }

  browserHeaders(extra = {}) {
    return {
      'User-Agent': UA,
      Origin: 'https://duck.ai',
      Referer: 'https://duck.ai/',
      'Accept-Language': 'en-US,en;q=0.9',
      'sec-ch-ua': '"Chromium";v="131", "Google Chrome";v="131", "Not-A.Brand";v="99"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'Sec-Fetch-Site': 'same-origin',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Dest': 'empty',
      ...(this.jar.header() ? { Cookie: this.jar.header() } : {}),
      ...extra,
    };
  }

  async init() {
    // 1) frontend version (x-fe-version header)
    const home = await fetch(BASE + '/', { headers: this.browserHeaders() });
    this.jar.storeFrom(home);
    const html = await home.text();
    const tag = html.match(/data-version-tag="([^"]+)"/)?.[1] || 'dev';
    const sha = html.match(/data-version-sha="([^"]+)"/)?.[1] || 'hash';
    this.feVersion = `${tag}-${sha}`;

    // 2) capabilities (sets duckai_experiment_* cookies used by chat)
    const cap = await fetch(BASE + '/duckchat/v1/capabilities', { headers: this.browserHeaders() });
    this.jar.storeFrom(cap);
    await cap.text();

    // 3) status + first challenge
    await this.refreshChallenge();
    return this;
  }

  async refreshChallenge() {
    const res = await fetch(BASE + '/duckchat/v1/status', {
      headers: this.browserHeaders({ 'x-vqd-accept': '1' }),
    });
    this.jar.storeFrom(res);
    const challenge = res.headers.get('x-vqd-hash-1');
    const body = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`status ${res.status}: ${JSON.stringify(body)}`);
    if (body.statusV2 !== undefined && body.statusV2 !== 0) {
      // bitmask: 1=Chat blocked, 2=Images, 4=Voice
      throw new Error(`service limited (statusV2=${body.statusV2})`);
    }
    if (!challenge) throw new Error('status response had no x-vqd-hash-1 challenge');
    this.jsa = await solveChallenge(challenge);
  }

  /** Send one user message; returns the full assistant text. */
  async chat(prompt, { model = 'gpt-6-luna', onToken = null } = {}) {
    if (!this.jsa) await this.init();
    this.history.push({ role: 'user', content: [{ type: 'text', text: prompt }] });

    const signals = Buffer.from(
      JSON.stringify({ start: Date.now(), events: [], end: 1 }),
      'utf8',
    ).toString('base64');

    const payload = {
      model,
      messages: this.history,
      canUseTools: true,
      reasoningEffort: 'none',
      canUseApproxLocation: false,
      canDelegateImageGeneration: false,
    };

    const res = await fetch(BASE + '/duckchat/v1/chat', {
      method: 'POST',
      headers: this.browserHeaders({
        'Content-Type': 'application/json',
        Accept: 'text/event-stream',
        'x-fe-version': this.feVersion,
        'x-fe-signals': signals,
        'X-Vqd-Hash-1': this.jsa,
        'x-duckai-response-id': crypto.randomUUID(),
        'x-ddg-journey-id': this.journeyId,
        'x-duckai-continuation': 'resubmit-context',
        'x-duckai-consent-purposes': 'user-location,image-generation,web-search',
        'x-duckai-tool-approval': 'web-search',
      }),
      body: JSON.stringify(payload),
    });
    this.jar.storeFrom(res);

    // token rotation: solve the next challenge in the background
    const nextChallenge = res.headers.get('x-vqd-hash-1');
    const rotate = nextChallenge ? solveChallenge(nextChallenge).then((t) => { this.jsa = t; }).catch(() => {}) : Promise.resolve();

    if (!res.ok || !res.body) {
      const errText = await res.text().catch(() => '');
      let err;
      try { err = JSON.parse(errText); } catch { err = { raw: errText }; }
      await rotate;
      // types seen live: ERR_BN_LIMIT / ERR_CHALLENGE (418), ERR_USER_LIMIT, ...
      throw new Error(`chat ${res.status}: ${JSON.stringify(err)}`);
    }

    let full = '';
    let title = null;
    const decoder = new TextDecoder();
    let buf = '';
    for await (const chunk of res.body) {
      buf += decoder.decode(chunk, { stream: true });
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const frame = buf.slice(0, idx); buf = buf.slice(idx + 2);
        for (const line of frame.split('\n')) {
          if (!line.startsWith('data:')) continue;
          const data = line.slice(5).trim();
          if (!data) continue;
          if (data === '[DONE]') continue;
          const titleMatch = data.match(/^\[CHAT_TITLE:(.*)\]$/);
          if (titleMatch) { title = titleMatch[1]; continue; }
          if (data.startsWith('[PING]')) continue;
          try {
            const ev = JSON.parse(data);
            if (ev.role === 'assistant' && typeof ev.message === 'string') {
              full += ev.message;
              if (onToken) onToken(ev.message);
            }
            // other frames: role:"reasoning" (encryptedText), role:"tool-invocation",
            // role:"source", ... — ignored by this minimal client.
          } catch { /* non-JSON control frame */ }
        }
      }
    }
    await rotate;
    this.history.push({ role: 'assistant', content: '', parts: [{ type: 'text', text: full }] });
    return { text: full, title };
  }
}

// -------------------------------------------------------------------- CLI --
const isMain = import.meta.url === `file://${process.argv[1]}`;
if (isMain) {
  const args = process.argv.slice(2);
  let model = 'gpt-6-luna';
  let multi = false;
  const rest = [];
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--model') model = args[++i];
    else if (args[i] === '--multi') multi = true;
    else rest.push(args[i]);
  }
  const client = await new DuckAI().init();
  if (multi) {
    const readline = await import('node:readline');
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    console.log('Duck.ai multi-turn chat. Ctrl+C / Ctrl+D to exit.');
    process.stdout.write('you> ');
    for await (const q of rl) {
      if (q.trim()) {
        process.stdout.write('duck> ');
        try {
          await client.chat(q, { model, onToken: (t) => process.stdout.write(t) });
        } catch (e) {
          process.stdout.write(`\n[error] ${e.message}`);
        }
        process.stdout.write('\n');
      }
      if (!process.stdin.isTTY && q === undefined) break;
      process.stdout.write('\nyou> ');
    }
  } else {
    const prompt = rest.join(' ') || 'Say hello in one short sentence.';
    const { text } = await client.chat(prompt, { model, onToken: (t) => process.stdout.write(t) });
    if (!text) console.log('(empty response)');
    else process.stdout.write('\n');
  }
}
