# گزارش استخراج API سایت Duck.ai

- **هدف:** https://duck.ai/ (چت هوش مصنوعی DuckDuckGo)
- **تاریخ بررسی:** ۲۹ اکتبر ۲۰۲۶
- **منابع شواهد:** HTML زنده صفحه، باندل فرانت‌اند (`entry.duckai.f0db33b1ad793c2cea4d.js`، نسخه فرانت‌اند `serp_20261028_231942_ET` با SHA `44aad864f3f3d88a808a38dd45bf928a0595f557`) و **درخواست‌های زنده موفق** (چت تک‌نوبتی و چندنوبتی با دو مدل و دو کلاینت مستقل).
- **نتیجه کلی:** API داخلی سایت کامل استخراج و به‌صورت عملی تست شد. استفاده از آن بدون حساب و API key ممکن است، اما اندپوینت چت با یک چالش جاوااسکریپتی ضدربات محافظت می‌شود که باید در محیط DOM اجرا شود.

---

## ۱) معماری کلی و جریان درخواست

```
1. GET  https://duck.ai/                          → خواندن نسخه فرانت‌اند از HTML
2. GET  /duckchat/v1/capabilities                 → فلگ‌ها + کوکی‌های آزمایش (experiment)
3. GET  /duckchat/v1/status  (x-vqd-accept: 1)    → چالش JS در هدر پاسخ x-vqd-hash-1
4. اجرای چالش در DOM و ساخت توکن حل‌شده
5. POST /duckchat/v1/chat                          → پاسخ استریم SSE
6. هر پاسخ چت، چالش جدید برمی‌گرداند (چرخش توکن) → حل مجدد برای پیام بعدی
```

Base URL همه اندپوینت‌های چت: `https://duck.ai/duckchat/v1` (در باندل: `DUCKCHAT_API: "/duckchat/v1"`).

## ۲) اندپوینت‌ها

| متد | مسیر | کاربرد | احراز هویت |
|---|---|---|---|
| GET | `/` | صفحه اصلی؛ شامل `data-version-tag` و `data-version-sha` | — |
| GET | `/duckchat/v1/capabilities` | فلگ‌های قابلیت و آزمایش‌ها؛ کوکی `duckai_experiment_*` ست می‌کند | عمومی |
| GET | `/duckchat/v1/status` | وضعیت سرویس + صدور چالش ضدربات | عمومی |
| POST | `/duckchat/v1/chat` | **چت استریمی (SSE)** | توکن چالش `X-Vqd-Hash-1` |
| POST | `/duckchat/v1/summarize` و `/summarize/compact` | خلاصه‌سازی مکالمه‌های طولانی | همان هدرهای چت |
| POST | `/duckchat/v1/dictation` | آپلود صدای دیکته (webm/ogg/mp4) | همان هدرها + هدر مدل |
| POST/DELETE | `/duckchat/v1/usage` | مدیریت پنجره‌های مصرف (reset/preset) | هدرهای احراز |
| POST | `/duckchat/v1/redeem` | بازخرید کمپین bonus | — |
| GET/POST | `/duckchat/v1/auth/authorize` ، `/auth/callback` ، `/auth/token` ، `/auth/logout` | ورود کاربران اشتراکی DuckDuckGo (Plus/Pro) | OAuth |

### پاسخ `/capabilities` (زنده)
```json
{"accessLevel":"public","flags":{},"experimentEnrollments":[],"experimentStateResets":["duckai-framework-browser-profile-aa","luna6-image-gen-prompt"]}
```

### پاسخ `/status` (زنده)
```json
{"status":"0","secondaryStatus":"0","statusV2":0,"grant":null}
```
`statusV2` بیت‌ماسک حالت‌های مسدود است: `1`=چت، `2`=تصویر، `4`=صدا. مقدار `0` یعنی همه بازند. اگر چت مسدود باشد، فرانت‌اند خطای `ERR_USER_LIMIT`/`ERR_ACCOUNT_LIMIT` نشان می‌دهد.

## ۳) مکانیزم ضدربات (JSA Challenge) — قلب پروتکل

1. در پاسخ `GET /duckchat/v1/status` (با هدر `x-vqd-accept: 1`)، هدر **`x-vqd-hash-1`** حاوی یک برنامه جاوااسکریپت مبهم‌سازی‌شده به‌صورت Base64 است: `(async function(){ ... })()`. این چالش در هر بار **تصادفی و متفاوت** است و پروب‌های مختلف DOM را بررسی می‌کند (User-Agent، `navigator.webdriver`، متریک‌های layout مثل `offsetWidth` و `getBoundingClientRect`، ساخت iframe، کلیدهای `window.top` و…).
2. کلاینت رسمی آن را داخل یک `<iframe sandbox="allow-scripts allow-same-origin">` با صفحه خالی اجرا می‌کند. خروجی شیئی شبیه این است:
   ```json
   {"server_hashes":["...","...","..."], "client_hashes":["<UA>","7560","3245"], "signals":{}, "meta":{"v":"4","challenge_id":"...","timestamp":"...","debug":"..."}}
   ```
3. سپس روی هر عضو `client_hashes` این تبدیل اعمال می‌شود: `base64(SHA-256(متن))` (بایت خام digest با Base64 استاندارد)، و به `meta` سه فیلد `origin` (برابر `https://duck.ai`)، `stack` و `duration` اضافه می‌شود.
4. کل شیء JSON و Base64 می‌شود و به‌عنوان هدر **`X-Vqd-Hash-1`** در درخواست چت ارسال می‌شود. (نام هدر در باندل به‌صورت ثابت `X-Vqd-Hash-1` تعریف شده است.)
5. **چرخش توکن:** پاسخ هر چت هم هدر `x-vqd-hash-1` جدید دارد؛ چالش بعدی باید پیش از پیام بعدی حل شود. فرانت‌اند حداکثر ۱۵ ثانیه برای آماده‌شدن توکن صبر می‌کند و در نبود آن مقدار `initial` می‌فرستد (که عملاً رد می‌شود).
6. اگر اثرانگشت کلاینت قانع‌کننده نباشد، سرور به‌جای پاسخ یکی از این‌ها را برمی‌گرداند:
   - `HTTP 418` با `{"type":"ERR_BN_LIMIT","overrideCode":"8e04","message":"You appear to be using an unsupported entrypoint..."}` — حتی هدرهای پیش‌فرض کتابخانه‌های HTTP (مثل `Accept-Encoding: identity` و `Connection: close` در urllib پایتون) همین خطا را می‌گیرند؛ هدرها باید دقیقاً شبیه مرورگر باشند.
   - `HTTP 418` با `{"type":"ERR_CHALLENGE","cd":{...}}` — ارتقا به چالش تعاملی تشخیص ناهنجاری (در مرورگر واقعی با IP معمولی معمولاً رخ نمی‌دهد).

فایل `solve_challenge.mjs` همین جریان را با **jsdom** بازتولید می‌کند. نکته مهم: jsdom موتور layout ندارد و همه متریک‌ها صفرند؛ حل‌کننده مقادیر معقول غیرصفر را patch می‌کند، چون چالش دقیقاً همین مقادیر را پروب می‌کند. بدون این patch سرور خطای `ERR_CHALLENGE` می‌دهد.

## ۴) درخواست چت

```
POST https://duck.ai/duckchat/v1/chat
Content-Type: application/json
Accept: text/event-stream
x-fe-version: serp_20261028_231942_ET-44aad864f3f3d88a808a38dd45bf928a0595f557
x-fe-signals: <base64 JSON: {"start":<ms>,"events":[],"end":1}>
X-Vqd-Hash-1: <توکن حل‌شده>
x-duckai-response-id: <UUID>
x-ddg-journey-id: <32 کاراکتر hex تصادفی برای هر نشست>
x-duckai-continuation: resubmit-context
x-duckai-consent-purposes: user-location,image-generation,web-search
x-duckai-tool-approval: web-search
Origin: https://duck.ai
Referer: https://duck.ai/
```

- `x-fe-version` از دو اتریبیوت HTML ساخته می‌شود: `data-version-tag` + `-` + `data-version-sha` (در کد: `window.__DDG_BE_VERSION__` و `window.__DDG_FE_CHAT_HASH__`).
- `x-fe-signals` در کلاینت رسمی تل‌متری تعامل کاربر است (`{start, events, end}` به‌صورت Base64)؛ مقدار مینیمال با `events: []` پذیرفته شد.
- هدرهای اختیاری: `x-duckai-bonus-id` (کمپین bonus)، `x-duckai-bypass-fixed-cost-windows` (دور زدن پنجره مصرف برای کاربران اشتراکی)، `Authorization` (فقط Plus/Pro).

### بدنه درخواست (فرمت canonical)
```json
{
  "model": "gpt-6-luna",
  "messages": [
    {"role": "user", "content": [{"type": "text", "text": "سلام!"}]}
  ],
  "canUseTools": true,
  "reasoningEffort": "none",
  "canUseApproxLocation": false,
  "canDelegateImageGeneration": false
}
```

قواعد مهم:
- پیام کاربر: `content` آرایه‌ای از پارت‌هاست (`text`، و در صورت نیاز `image`/`file`/`text-pasted`/`page-context`).
- پیام دستیار در تاریخچه باید دقیقاً با فرمت فرانت‌اند برگردد: `{"role":"assistant","content":"","parts":[{"type":"text","text":"..."}]}` — این فرمت در تست چندنوبتی زنده تأیید شد.
- `reasoningEffort`: برای حالت سریع `none` است؛ مدل‌ها بسته به مدل `low`/`medium` هم می‌پذیرند (حالت‌های reasoning/extended).
- فیلدهای اختیاری دیگر: `metadata` (مثل `toolChoice` و `customization`)، `summary` (خلاصه فشرده مکالمه)، `canUseWebSearch`، `canUploadFiles`، `durableStream` و `continuation` (ادامه استریم‌های ناتمام). برای چت ساده لازم نیستند.

## ۵) پاسخ استریمی (SSE)

اتصال با `Content-Type: text/event-stream` باز می‌شود. فریم‌ها:

```
data: [CHAT_TITLE:Hello from Duck AI]

data: {"id":"rs_...","action":"success","created":1793262449214,"model":"gpt-6-luna","role":"reasoning","state":"done","summaryText":[],"encryptedText":"<بلاب رمزنگاری‌شده>","sourceUpstreamId":"u10","sourceModelId":"gpt-6-luna"}

data: {"id":"msg_...","action":"success","created":1793262449226,"model":"gpt-6-luna","role":"assistant","message":"Hello"}
data: {... ,"message":" from"}
...

data: [DONE]
```

- فقط فریم‌های `role:"assistant"` با فیلد `message` متن پاسخ‌اند؛ به هم بچسبانید.
- فریم `role:"reasoning"` حاوی `encryptedText` غیرشفاف است (قابل رمزگشایی توسط کلاینت نیست؛ نادیده بگیرید).
- فریم‌های دیگر ممکن: `tool-invocation` (فراخوانی ابزار مثل WebSearch)، `source` (منابع وب)، `generated-image`، `refusal` (رد محتوا)، `continuation`.
- در فریم پایانی `[DONE]` ممکن است پسوندهایی بیاید: `[FIXED_COST_WINDOW_USAGE:...]`، `[SUMMARY_REFRESH_HINT:...]`، `[LIMIT_*]`، `[STOP_REASON:max_tokens]`، `[WARN_CONVERSATION_LIMIT:n]`.
- فریم `[PING]` ضربان قلب است.
- نمونه واقعی کامل در فایل `sample_sse.txt` آمده است.

## ۶) مدل‌ها (از رجیستری زنده فرانت‌اند)

بدون حساب (FREE) — پیش‌فرض: **`gpt-6-luna`**:

| شناسه مدل | نام نمایشی | سازنده |
|---|---|---|
| `gpt-6-luna` | GPT-6 Luna | OpenAI |
| `gpt-5.4-mini` | GPT-5.4 mini | OpenAI |
| `claude-haiku-4-5` | Claude Haiku 4.5 | Anthropic |
| `mistral-small-2603` | Mistral Small 4 | Mistral AI |
| `tinfoil/gpt-oss-120b` | gpt-oss 120B | OpenAI (هاست رمزنگاری‌شده Tinfoil) |
| `tinfoil/gemma4-31b` | Gemma 4 31B | Google (Tinfoil) |

اشتراکی: Plus/Pro: `gpt-5.6-terra` (پیش‌فرض)، `claude-sonnet-4-6`، `claude-sonnet-5-5` و فقط Pro: `gpt-5.6-sol`، `claude-opus-4-8`، `claude-opus-5-5`. جزئیات کامل در `models.json`.

## ۷) محدودیت‌ها و خطاها

- **سقف ورودی:** ۱۶٬۰۰۰ کاراکتر برای هر پیام (همه مدل‌ها).
- **تصویر (رایگان):** حداکثر ۳ تصویر در هر پیام، ۴۵۰۰ کاراکتر متن همراه تصویر، ۵ تصویر در کل مکالمه، حداکثر بُعد ۵۱۲px. (پولی: ۱۰ تصویر در مکالمه، ۱۰۲۴px.)
- **PDF (رایگان):** حداکثر ۳ فایل، هر فایل ۵MB، مجموع ۵MB، ۱۵ صفحه. (Plus: ۲۵MB/۵ فایل/۳۵ صفحه؛ Pro: ۵۰ صفحه.)
- **پنجره‌های مصرف:** مصرف با پنجره‌های `six_hours`، `day`، `iso_week` و `month` سنجیده می‌شود (فیلد `fixedCostWindowUsage`). با پرشدن پنجره، خطای `ERR_USER_LIMIT` (رایگان) یا `ERR_ACCOUNT_LIMIT` (اشتراکی) برمی‌گردد و فرانت‌اند مدل‌های ارزان‌تر (degraded) پیشنهاد می‌دهد.
- **خطاهای مهم:** `ERR_BN_LIMIT` و `ERR_CHALLENGE` (۴۱۸، ضدربات)، `ERR_USER_LIMIT`/`ERR_ACCOUNT_LIMIT`، `ERR_CONVERSATION_LIMIT`، `ERR_INPUT_LIMIT`، `ERR_MODEL_RESTRICTED` (مدل پولی با حساب رایگان)، `ERR_MODERATION_FLAG`، `ERR_REFUSAL`، `ERR_STREAM_EXPIRED` (استریم ناتمام بعد از ~۱۵ دقیقه)، `ERR_SERVICE_UNAVAILABLE`.
- **بازیابی استریم:** فرانت‌اند برای استریم‌های ذخیره‌شده تا ۱۰ دقیقه با فاصله ۴ ثانیه (و برای 429/418 با backoff نمایی) تلاش مجدد می‌کند.

## ۸) نحوه استفاده از فایل‌های این پوشه

```bash
cd duck-ai-analysis
npm install    # نصب jsdom (برای اجرای چالش ضدربات)

# Node — تک‌نوبتی و چندنوبتی
node duck_client.mjs "سلام، خودت را معرفی کن"
node duck_client.mjs --model claude-haiku-4-5 "گرانش را در یک جمله توضیح بده"
node duck_client.mjs --multi

# Python — همان قابلیت‌ها (HTTP با کتابخانه استاندارد + حل چالش با Node/jsdom)
python3 api_client.py "سلام!"
python3 api_client.py --multi

# حل‌کننده مستقل چالش
node solve_challenge.mjs "<base64 challenge>" "<user-agent>"
```

فایل‌ها: `duck_client.mjs` (کلاینت Node)، `api_client.py` (کلاینت پایتون)، `solve_challenge.mjs` (حل‌کننده چالش)، `models.json` (رجیستری مدل‌ها)، `openapi.yaml` (مشخصات OpenAPI)، `curl_examples.sh` (نمونه‌های خام HTTP)، `sample_sse.txt` (نمونه واقعی SSE).

## ۹) نتایج تست زنده (۲۹ اکتبر ۲۰۲۶)

- `GET /duckchat/v1/capabilities` → ۲۰۰ با JSON معتبر و کوکی آزمایش.
- `GET /duckchat/v1/status` با `x-vqd-accept: 1` → ۲۰۰، بدنه `statusV2:0` و چالش در هدر `x-vqd-hash-1`.
- چت تک‌نوبتی با `gpt-6-luna` («Reply with exactly: Hello from Duck AI») → استریم SSE کامل، پاسخ دقیق: `Hello from Duck AI`.
- چت چندنوبتی → مدل سؤال قبلی را درست به یاد آورد (حافظه مکالمه با فرمت `parts` تأیید شد).
- چت با `claude-haiku-4-5` از کلاینت پایتون → پاسخ دقیق درخواستی برگشت.
- هر دو کلاینت (`duck_client.mjs` و `api_client.py`) در حالت تک‌نوبتی و چندنوبتی موفق بودند.
- کنترل منفی: درخواست curl خام بدون توکن حل‌شده → `418 ERR_BN_LIMIT` («unsupported entrypoint»)؛ یعنی چالش واقعاً اجباری است.

## ۱۰) ملاحظات

- این API **رسمی و عمومی نیست**؛ قرارداد داخلی فرانت‌اند است و ممکن است با هر انتشار نسخه عوض شود (به‌خصوص نسخه فرانت‌اند در `x-fe-version` و ساختار چالش). کلاینت‌ها نسخه را در هر اجرا از HTML تازه می‌خوانند.
- چالش ضدربات تصادفی است؛ اگر DuckDuckGo پروب‌های سخت‌گیرانه‌تری (مثل WebGL) اضافه کند، شاید jsdom کافی نباشد و به مرورگر واقعی (Playwright) نیاز شود.
- از IPهای دیتاسنتری احتمال دریافت `ERR_CHALLENGE` (چالش تعاملی) بیشتر است؛ در صورت مشاهده، از IP/مرورگر معمولی اجرا کنید.
- برای استفاده محترمانه: نرخ درخواست را پایین نگه دارید؛ محدودیت‌های پنجره مصرف (`ERR_USER_LIMIT`) را رعایت کنید.
