#!/usr/bin/env bash
# Duck.ai (DuckDuckGo AI Chat) — raw HTTP examples.
#
# NOTE: /duckchat/v1/chat is protected by a JavaScript anti-bot challenge
# (header X-Vqd-Hash-1). A plain curl POST will be rejected with
# HTTP 418 ERR_BN_LIMIT / ERR_CHALLENGE. The challenge must be executed in a
# DOM environment — use duck_client.mjs / api_client.py for real chats.
# The curl calls below cover the unauthenticated, challenge-free endpoints
# and show the exact chat request shape with a solved token plugged in.

set -euo pipefail
BASE="https://duck.ai"
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
JAR="$(mktemp)"

echo "== 1) Frontend version (needed for x-fe-version) =="
curl -s -A "$UA" "$BASE/" | grep -oE 'data-version-(tag|sha)="[^"]+"'

echo
echo "== 2) Capabilities (public, sets experiment cookies) =="
curl -s -A "$UA" -c "$JAR" -b "$JAR" \
  -H "Origin: https://duck.ai" -H "Referer: https://duck.ai/" \
  "$BASE/duckchat/v1/capabilities"
echo

echo
echo "== 3) Status + JS challenge (challenge is in a RESPONSE HEADER) =="
curl -s -A "$UA" -c "$JAR" -b "$JAR" \
  -H "Origin: https://duck.ai" -H "Referer: https://duck.ai/" \
  -H "x-vqd-accept: 1" \
  -D - "$BASE/duckchat/v1/status" -o /tmp/duck_status.json \
  | grep -iE '^HTTP|x-vqd-hash-1' | cut -c1-120
echo "body: $(cat /tmp/duck_status.json)"
# -> {"status":"0","secondaryStatus":"0","statusV2":0,"grant":null}
# statusV2 is a bitmask of blocked modes: 1=Chat, 2=Images, 4=Voice (0 = all open)

echo
echo "== 4) Chat request shape (replace SOLVED_TOKEN via solve_challenge.mjs) =="
cat <<'EOF'
# CHALLENGE=$(curl -s -D - -H 'x-vqd-accept: 1' https://duck.ai/duckchat/v1/status -o /dev/null \
#             | awk 'BEGIN{IGNORECASE=1} /^x-vqd-hash-1:/{sub(/\r$/,"",$2); print $2}')
# SOLVED=$(node solve_challenge.mjs "$CHALLENGE")
#
# curl -sN https://duck.ai/duckchat/v1/chat \
#   -H 'Content-Type: application/json' \
#   -H 'Accept: text/event-stream' \
#   -H 'x-fe-version: serp_20261028_231942_ET-44aad864f3f3d88a808a38dd45bf928a0595f557' \
#   -H "x-fe-signals: $(printf '{"start":%s,"events":[],"end":1}' "$(date +%s)000" | base64 -w0)" \
#   -H "X-Vqd-Hash-1: $SOLVED" \
#   -H "x-duckai-response-id: $(cat /proc/sys/kernel/random/uuid)" \
#   -H "x-ddg-journey-id: $(openssl rand -hex 16)" \
#   -H 'x-duckai-continuation: resubmit-context' \
#   -H 'x-duckai-consent-purposes: user-location,image-generation,web-search' \
#   -H 'x-duckai-tool-approval: web-search' \
#   -H 'Origin: https://duck.ai' -H 'Referer: https://duck.ai/' \
#   -A 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36' \
#   --data '{"model":"gpt-6-luna","messages":[{"role":"user","content":[{"type":"text","text":"Hello!"}]}],"canUseTools":true,"reasoningEffort":"none","canUseApproxLocation":false,"canDelegateImageGeneration":false}'
#
# Response: SSE. Assistant text arrives as:
#   data: {"id":"msg_...","action":"success","created":...,"model":"gpt-6-luna","role":"assistant","message":"Hello"}
# terminated by:
#   data: [DONE]
# Every response also returns a NEW x-vqd-hash-1 header -> solve it before
# the next message.
EOF
