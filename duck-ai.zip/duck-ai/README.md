# Duck.ai API Package — راهنمای کامل استفاده

این بسته، API داخلی **Duck.ai** (چت هوش مصنوعی DuckDuckGo) در `https://duck.ai` را مستند و قابل اجرا می‌کند. این API رسمی/عمومی نیست؛ از روی فرانت‌اند زنده سایت استخراج شده و با درخواست واقعی تست شده است.

قلب پروتکل این است: سرور برای چت یک **چالش جاوااسکریپتی ضدربات** می‌دهد. کلاینت باید آن را داخل DOM اجرا کند، خروجی را به توکن `X-Vqd-Hash-1` تبدیل کند و بعد درخواست چت SSE بفرستد. این بسته همین کار را با Node/jsdom انجام می‌دهد؛ بنابراین چت واقعی بدون حساب و بدون API Key ممکن است، اما `curl` خام به‌تنهایی کافی نیست.

تاریخ استخراج و آخرین بررسی فایل‌ها: **2026-10-29**. نسخه فرانت‌اند مشاهده‌شده هنگام استخراج: `serp_20261028_231942_ET-44aad864f3f3d88a808a38dd45bf928a0595f557`. کلاینت‌ها نسخه را در هر اجرا تازه از HTML می‌خوانند، چون ممکن است تغییر کند.

---

## 1) اکشن‌های پوشش‌داده‌شده

### اکشن‌های قابل اجرا با فایل‌های بسته

| # | اکشن | روش/Endpoint | فایل/دستور |
|---:|---|---|---|
| 1 | خواندن نسخه فرانت‌اند | `GET /` و استخراج `data-version-tag`/`data-version-sha` | خودکار در هر دو کلاینت؛ دستی در `curl_examples.sh` |
| 2 | دریافت قابلیت‌ها و cookieهای experiment | `GET /duckchat/v1/capabilities` | خودکار در شروع نشست؛ دستی با curl |
| 3 | بررسی وضعیت سرویس و گرفتن چالش | `GET /duckchat/v1/status` با `x-vqd-accept: 1` | خودکار؛ چالش در هدر پاسخ `x-vqd-hash-1` است |
| 4 | حل مستقل چالش JSA | اجرای challenge در jsdom و ساخت توکن | `node solve_challenge.mjs <challenge|@file> [user-agent]` |
| 5 | چت تک‌نوبتی | `POST /duckchat/v1/chat` با SSE | `node duck_client.mjs "سلام"` یا `python3 api_client.py "سلام"` |
| 6 | چت چندنوبتی تعاملی | همان چت + history canonical + چرخش توکن | `--multi` در هر دو کلاینت |
| 7 | انتخاب مدل رایگان | فیلد `model` در بدنه چت | `--model MODEL_ID` در هر دو کلاینت |
| 8 | مشاهده رجیستری مدل‌ها | فایل آفلاین/استخراج‌شده | `models.json` |
| 9 | دیدن نمونه واقعی SSE | فایل نمونه | `sample_sse.txt` |
| 10 | بررسی قرارداد HTTP | مشخصات تقریبی OpenAPI | `openapi.yaml` |

### اکشن‌هایی که در فرانت‌اند مشاهده شده‌اند ولی کلاینت این بسته آن‌ها را wrap نمی‌کند

| Endpoint | کاربرد مشاهده‌شده | وضعیت در این بسته |
|---|---|---|
| `POST /duckchat/v1/summarize` و `/summarize/compact` | خلاصه‌سازی مکالمه‌های طولانی | فقط در `openapi.yaml`/`REPORT_FA.md` مستند است؛ payload کامل آن هدف این بسته نیست |
| `POST /duckchat/v1/dictation` | آپلود صدای دکمه میکروفون (`webm/ogg/mp4`) | wrap نشده |
| `POST/DELETE /duckchat/v1/usage` | مدیریت پنجره‌های مصرف preset/reset | wrap نشده؛ خطاهای usage در چت توضیح داده شده‌اند |
| `POST /duckchat/v1/redeem` | بازخرید کمپین bonus | wrap نشده |
| `GET/POST /duckchat/v1/auth/authorize`, `/auth/callback`, `/auth/token`, `/auth/logout` | OAuth ردیف‌های اشتراکی DuckDuckGo Plus/Pro | مربوط به حساب پولی است و برای چت رایگان لازم نیست |

پس مسیر عملی و تست‌شده این بسته، چت رایگان تک‌نوبتی/چندنوبتی با مدل‌های آزاد است. برای endpointهای wrap‌نشده، بدون دانستن payload و auth دقیق آن‌ها درخواست دستی نفرستید.

---

## 2) فایل‌های داخل ZIP و کاربرد هرکدام

| فایل | کاربرد | چطور استفاده می‌شود؟ |
|---|---|---|
| `README.md` | راهنمای مستقل همین بسته | مرجع اصلی پروتکل، payload، SSE، خطاها و دستورها |
| `REPORT_FA.md` | گزارش کامل فارسی استخراج API | جزئیات عمیق‌تر شواهد فرانت‌اند، هدرها، محدودیت‌ها و نتایج تست زنده |
| `duck_client.mjs` | کلاینت اصلی Node | چت تک‌نوبتی و چندنوبتی؛ حل چالش داخل خودش انجام می‌شود |
| `api_client.py` | کلاینت Python | همان چت را با HTTP کتابخانه استاندارد انجام می‌دهد، اما برای حل چالش Node/jsdom را صدا می‌زند |
| `solve_challenge.mjs` | حل‌کننده مستقل چالش | ورودی base64 challenge یا `@file` می‌گیرد و توکن حل‌شده را در stdout چاپ می‌کند |
| `models.json` | رجیستری مدل‌های استخراج‌شده از باندل زنده | دیدن مدل‌های رایگان/اشتراکی و مشخصاتشان به‌صورت آفلاین |
| `openapi.yaml` | مشخصات OpenAPI 3 تقریبی | Import در Postman/Swagger/Insomnia؛ قرارداد داخلی است و ممکن است تغییر کند |
| `curl_examples.sh` | نمونه خام HTTP برای endpointهای بدون چالش و قالب چت | اجرا برای دیدن version/capabilities/status؛ چت واقعی را با کلاینت‌ها انجام دهید |
| `sample_sse.txt` | نمونه واقعی کوتاه از stream چت | فهم فریم‌های reasoning/assistant و `[DONE]` |
| `package.json` | manifest نود | تعریف `type: module` و dependency `jsdom` |
| `package-lock.json` | قفل نسخه dependencyها | نصب reproducible با `npm ci` یا استفاده غیرمستقیم توسط `npm install` |

این بسته `node_modules` ندارد؛ قبل از اجرای کلاینت‌ها باید dependency نصب شود.

---

## 3) پیش‌نیاز و نصب

وارد پوشه شوید:

```bash
unzip duck-ai.zip
cd duck-ai
```

نصب dependency:

```bash
npm install
```

یا نصب دقیق‌تر بر اساس lockfile:

```bash
npm ci
```

نیازمندی‌ها:

- Node.js جدید (برای اجرای `duck_client.mjs` و `solve_challenge.mjs` و همچنین زیرپردازش حل چالش در Python). در عمل Node 20+ پیشنهاد می‌شود.
- Python 3.10+ فقط برای `api_client.py`.
- اینترنت و دسترسی به `duck.ai`.

نکته مهم: `api_client.py` از نظر HTTP فقط کتابخانه استاندارد Python می‌خواهد، اما حل چالش را با اجرای `node solve_challenge.mjs` انجام می‌دهد. پس حتی برای کلاینت Python هم Node و `npm install` در همین پوشه لازم است.

---

## 4) شروع سریع

### Node — پیشنهاد اصلی

```bash
node duck_client.mjs "سلام، خودت را کوتاه معرفی کن"
node duck_client.mjs --model claude-haiku-4-5 "گرانش را در یک جمله توضیح بده"
node duck_client.mjs --multi
```

### Python

```bash
python3 api_client.py "سلام!"
python3 api_client.py --model mistral-small-2603 "Hello!"
python3 api_client.py --multi
```

در حالت `--multi`، هر خط ورودی یک پیام کاربر است و تاریخچه مکالمه در همان اجرا نگه داشته می‌شود. برای خروج از REPL از `Ctrl+C` استفاده کنید؛ در Node، بستن ورودی (`Ctrl+D`) هم حلقه را تمام می‌کند. خط خالی در Python نادیده گرفته می‌شود و خروج محسوب نمی‌شود.

---

## 5) پروتکل کامل در شش مرحله

کلاینت‌ها این مراحل را خودکار انجام می‌دهند؛ این بخش برای فهم request/response و دیباگ است.

### مرحله 1 — خواندن نسخه فرانت‌اند

```http
GET https://duck.ai/
```

از HTML دو مقدار خوانده می‌شود:

- `data-version-tag`
- `data-version-sha`

هدر نسخه چت از ترکیب آن‌ها ساخته می‌شود:

```text
x-fe-version: <data-version-tag>-<data-version-sha>
```

نمونه هنگام استخراج:

```text
serp_20261028_231942_ET-44aad864f3f3d88a808a38dd45bf928a0595f557
```

این مقدار را hardcode نکنید؛ کلاینت‌ها در هر اجرا HTML تازه را می‌خوانند.

### مرحله 2 — قابلیت‌ها

```http
GET https://duck.ai/duckchat/v1/capabilities
Origin: https://duck.ai
Referer: https://duck.ai/
```

نمونه پاسخ زنده:

```json
{
  "accessLevel": "public",
  "flags": {},
  "experimentEnrollments": [],
  "experimentStateResets": ["duckai-framework-browser-profile-aa", "luna6-image-gen-prompt"]
}
```

این endpoint عمومی است و ممکن است cookieهای `duckai_experiment_*` تنظیم کند. کلاینت cookieها را در همان نشست نگه می‌دارد.

### مرحله 3 — وضعیت و صدور چالش

```http
GET https://duck.ai/duckchat/v1/status
x-vqd-accept: 1
Origin: https://duck.ai
Referer: https://duck.ai/
```

بدنه نمونه:

```json
{"status": "0", "secondaryStatus": "0", "statusV2": 0, "grant": null}
```

`statusV2` بیت‌ماسک حالت‌های مسدود است:

| بیت | معنی |
|---:|---|
| `1` | Chat مسدود |
| `2` | Images مسدود |
| `4` | Voice مسدود |
| `0` | همه باز |

چالش واقعی در **هدر پاسخ** است، نه بدنه:

```http
x-vqd-hash-1: <base64 JavaScript challenge>
```

### مرحله 4 — حل چالش در DOM

مقدار `x-vqd-hash-1` یک برنامه JavaScript مبهم‌سازی‌شده به‌صورت base64 است. کلاینت رسمی آن را در iframe ساندباکس‌شده اجرا می‌کند. خروجی خام شکلی شبیه این دارد:

```json
{
  "server_hashes": ["...", "...", "..."],
  "client_hashes": ["<user-agent or probe>", "7560", "3245"],
  "signals": {},
  "meta": {
    "v": "4",
    "challenge_id": "...",
    "timestamp": "...",
    "debug": "..."
  }
}
```

تبدیل نهایی که `solve_challenge.mjs` انجام می‌دهد:

1. هر عضو `client_hashes` با `base64(SHA-256(utf8(text)))` جایگزین می‌شود؛ digest خام با Base64 استاندارد encode می‌شود.
2. به `meta` فیلدهای `origin=https://duck.ai`، `stack` و `duration` اضافه می‌شود.
3. کل object به JSON و سپس Base64 تبدیل می‌شود.
4. خروجی به‌عنوان هدر `X-Vqd-Hash-1` در چت ارسال می‌شود.

jsdom موتور layout ندارد و متریک‌هایی مثل `offsetWidth` را صفر می‌دهد؛ حل‌کننده مقادیر معقول غیرصفر را patch می‌کند، چون چالش دقیقاً همین probeها را بررسی می‌کند. از حل‌کننده‌های دستی ساده استفاده نکنید؛ چالش تصادفی و probeهایش متغیر است.

حل مستقل:

```bash
node solve_challenge.mjs "<BASE64_CHALLENGE>" "Mozilla/5.0 ..."
node solve_challenge.mjs @challenge.txt
```

خروجی فقط توکن حل‌شده در stdout است. چالش و توکن کوتاه‌عمر/یک‌بارمصرف‌اند؛ آن‌ها را ذخیره یا publish نکنید.

### مرحله 5 — ارسال چت

```http
POST https://duck.ai/duckchat/v1/chat
Content-Type: application/json
Accept: text/event-stream
x-fe-version: <tag>-<sha>
x-fe-signals: <base64 JSON telemetry>
X-Vqd-Hash-1: <solved token>
x-duckai-response-id: <uuid>
x-ddg-journey-id: <32 hex chars per session>
x-duckai-continuation: resubmit-context
x-duckai-consent-purposes: user-location,image-generation,web-search
x-duckai-tool-approval: web-search
Origin: https://duck.ai
Referer: https://duck.ai/
User-Agent: <browser-like UA>
```

هدرهای اختیاری مشاهده‌شده در فرانت‌اند:

- `x-duckai-bonus-id` برای کمپین bonus
- `x-duckai-bypass-fixed-cost-windows` برای برخی کاربران اشتراکی
- `Authorization` فقط برای ردیف‌های Plus/Pro

برای چت رایگان این بسته، `Authorization` و API Key لازم نیست.

### مرحله 6 — چرخش توکن

هر پاسخ چت، هدر `x-vqd-hash-1` تازه برمی‌گرداند. قبل از پیام بعدی باید چالش جدید حل شود. کلاینت‌ها این کار را خودکار انجام می‌دهند. اگر توکن قبلی را دوباره استفاده کنید یا دیر بفرستید، احتمال خطای 418 بالا می‌رود.

---

## 6) بدنه درخواست چت

فرمت canonical فرانت‌اند:

```json
{
  "model": "gpt-6-luna",
  "messages": [
    {
      "role": "user",
      "content": [
        {"type": "text", "text": "سلام!"}
      ]
    }
  ],
  "canUseTools": true,
  "reasoningEffort": "none",
  "canUseApproxLocation": false,
  "canDelegateImageGeneration": false
}
```

### فیلدها

| فیلد | مقدار/توضیح |
|---|---|
| `model` | شناسه مدل؛ پیش‌فرض رایگان `gpt-6-luna` |
| `messages` | تاریخچه کامل مکالمه در قالب canonical |
| `messages[].role` | `user` یا `assistant` |
| پیام user | `content` آرایه‌ای از partهاست؛ برای متن: `{"type":"text","text":"..."}` |
| پیام assistant در history | باید به شکل `{"role":"assistant","content":"","parts":[{"type":"text","text":"..."}]}` برگردد |
| `canUseTools` | کلاینت‌ها `true` می‌فرستند |
| `reasoningEffort` | برای پاسخ سریع `none`؛ بعضی مدل‌ها `low`/`medium` هم می‌پذیرند |
| `canUseApproxLocation` | در کلاینت ساده `false` |
| `canDelegateImageGeneration` | در کلاینت ساده `false` |

فیلدهای اختیاری دیگری در فرانت‌اند دیده شده‌اند؛ مثل `metadata`، `summary`، `canUseWebSearch`، `canUploadFiles`، `durableStream` و `continuation`. برای چت ساده لازم نیستند و کلاینت‌های این بسته آن‌ها را به‌صورت عمومی expose نمی‌کنند.

انواع part مشاهده‌شده برای ورودی کاربر: `text`، `image`، `file`، `text-pasted` و `page-context`. کلاینت‌های این بسته برای ورودی متنی ساده ساخته شده‌اند؛ آپلود تصویر/PDF را از CLI آن‌ها فرض نکنید.

---

## 7) پاسخ SSE و نحوه parse

پاسخ موفق `Content-Type: text/event-stream` دارد. نمونه کوتاه واقعی در `sample_sse.txt` هست.

فریم‌های نمونه:

```text
data: [CHAT_TITLE:Hello from Duck AI]

data: {"id":"rs_...","action":"success","created":1793262449214,"model":"gpt-6-luna","role":"reasoning","state":"done","summaryText":[],"encryptedText":"<opaque>","sourceUpstreamId":"u10","sourceModelId":"gpt-6-luna"}

data: {"id":"msg_...","action":"success","created":1793262449226,"model":"gpt-6-luna","role":"assistant","message":"Hello"}
data: {"id":"msg_...","action":"success","created":1793262449230,"model":"gpt-6-luna","role":"assistant","message":" from"}

...

data: [DONE]
```

قواعد parse:

- فقط فریم‌هایی با `role:"assistant"` و فیلد `message` متن پاسخ‌اند؛ `message`ها را به‌ترتیب بچسبانید.
- فریم `role:"reasoning"` شامل `encryptedText` غیرشفاف است؛ آن را نمایش ندهید و تلاش نکنید رمزگشایی کنید.
- `data: [CHAT_TITLE:...]` عنوان مکالمه است، نه متن پاسخ.
- فریم‌های دیگری ممکن است دیده شوند: `tool-invocation`، `source`، `generated-image`، `refusal` و `continuation`.
- `data: [PING]` heartbeat است.
- پایان عادی `data: [DONE]` است. پسوندهایی مثل `[FIXED_COST_WINDOW_USAGE:...]`، `[SUMMARY_REFRESH_HINT:...]`، `[LIMIT_*]`، `[STOP_REASON:max_tokens]` یا `[WARN_CONVERSATION_LIMIT:n]` ممکن است کنار پایان بیایند.

اگر خودتان parser می‌نویسید، خطوط خالی جداکننده فریم‌ها هستند و هر `data:` باید جداگانه parse شود. برای استفاده عادی، خروجی تمیز کلاینت‌ها کافی است.

---

## 8) مدل‌ها

مدل پیش‌فرض رایگان: `gpt-6-luna`.

| شناسه | نام/سازنده |
|---|---|
| `gpt-6-luna` | GPT-6 Luna — OpenAI |
| `gpt-5.4-mini` | GPT-5.4 mini — OpenAI |
| `claude-haiku-4-5` | Claude Haiku 4.5 — Anthropic |
| `mistral-small-2603` | Mistral Small 4 — Mistral AI |
| `tinfoil/gpt-oss-120b` | gpt-oss 120B — OpenAI/Tinfoil |
| `tinfoil/gemma4-31b` | Gemma 4 31B — Google/Tinfoil |

مثال:

```bash
node duck_client.mjs --model claude-haiku-4-5 "یک جمله درباره باران بگو"
python3 api_client.py --model tinfoil/gpt-oss-120b "Hello!"
```

مدل‌های اشتراکی مشاهده‌شده در رجیستری شامل `gpt-5.6-terra`، `claude-sonnet-4-6`، `claude-sonnet-5-5` و برای Pro `gpt-5.6-sol`، `claude-opus-4-8` و `claude-opus-5-5` هستند. انتخاب آن‌ها بدون حساب/اشتراک معتبر می‌تواند `ERR_MODEL_RESTRICTED` بدهد. جزئیات کامل در `models.json` است:

```bash
python3 -m json.tool models.json | head -160
```

---

## 9) استفاده برنامه‌نویسی

### Node

`duck_client.mjs` برای استفاده CLI ساخته شده است و منطق کامل نشست/حل چالش/SSE داخل همان فایل است. برای ادغام در پروژه، بهترین مسیر اجرای آن به‌عنوان subprocess یا کپی‌کردن منطق نشست با احترام به تغییرات نسخه فرانت‌اند است. قبل از import جانبی، انتهای فایل و رفتار CLI آن را بررسی کنید؛ فایل برای اجرای مستقیم طراحی شده است.

نمونه subprocess:

```bash
node duck_client.mjs --model gpt-6-luna "فقط بنویس: سلام"
```

### Python

`api_client.py` همان نشست را مدیریت می‌کند و حل چالش را به Node می‌سپارد. اجرای مستقیم:

```bash
python3 api_client.py --model claude-haiku-4-5 "فقط بنویس: سلام"
```

اگر آن را در کد خودتان صدا می‌زنید، ساده‌ترین و پایدارترین روش در این بسته اجرای subprocess است، چون توکن چالش باید تازه حل شود و نشست/cookie/Journey ID در هر اجرا مدیریت می‌شود.

---

## 10) اجرای `curl_examples.sh`

```bash
bash curl_examples.sh
```

این اسکریپت:

1. نسخه فرانت‌اند را از HTML می‌خواند.
2. `/duckchat/v1/capabilities` را صدا می‌زند.
3. `/duckchat/v1/status` را با `x-vqd-accept: 1` می‌گیرد و وجود هدر چالش را نشان می‌دهد.
4. قالب دقیق درخواست چت را به‌صورت کامنت/متن آموزشی چاپ می‌کند.

نکته: خود اسکریپت چت واقعی نمی‌فرستد، چون curl به‌تنهایی چالش را حل نمی‌کند. برای چت از `duck_client.mjs` یا `api_client.py` استفاده کنید.

قالب کلی چت با توکن حل‌شده در انتهای `curl_examples.sh` آمده است. اگر خواستید دستی اجرا کنید، ترتیب درست این است:

```bash
# 1) challenge را از هدر status بگیرید
# 2) SOLVED=$(node solve_challenge.mjs "$CHALLENGE" "$UA")
# 3) همان لحظه POST /duckchat/v1/chat را با X-Vqd-Hash-1: $SOLVED بفرستید
```

بین گرفتن چالش و POST مکث طولانی نکنید.

---

## 11) محدودیت‌ها و خطاها

### محدودیت‌های مشاهده‌شده

- سقف ورودی هر پیام: 16,000 کاراکتر برای مدل‌ها.
- تصویر رایگان: حداکثر 3 تصویر در هر پیام، 4500 کاراکتر متن همراه تصویر، 5 تصویر در کل مکالمه و حداکثر بُعد 512px طبق گزارش استخراج.
- PDF رایگان: حداکثر 3 فایل، هر فایل 5MB، مجموع 5MB و 15 صفحه طبق گزارش استخراج.
- مصرف با پنجره‌های `six_hours`، `day`، `iso_week` و `month` سنجیده می‌شود. پرشدن پنجره می‌تواند پاسخ مدل را محدود یا خطای limit ایجاد کند.

این اعداد از فرانت‌اند/گزارش استخراج آمده‌اند و ممکن است با پلن/نسخه تغییر کنند؛ برای جزئیات کامل `REPORT_FA.md` را بخوانید.

### خطاهای مهم

| خطا/وضعیت | معنی | اقدام |
|---|---|---|
| HTTP `418`, `ERR_BN_LIMIT` | entrypoint/اثرانگشت پذیرفته نشده؛ «unsupported entrypoint» | از کلاینت‌های بسته استفاده کنید؛ هدرهای مرورگری و حل تازه چالش لازم است |
| HTTP `418`, `ERR_CHALLENGE` | ارتقا به چالش تعاملی anomaly detection | از IP/مرورگر معمولی تلاش کنید؛ این بسته چالش تعاملی را دور نمی‌زند |
| `ERR_USER_LIMIT` | سقف مصرف رایگان/پنجره مصرف پر شده | صبر کنید یا مدل/حساب مجاز دیگری طبق قوانین سرویس استفاده کنید |
| `ERR_ACCOUNT_LIMIT` | سقف حساب اشتراکی | وضعیت اشتراک/پنجره مصرف را بررسی کنید |
| `ERR_CONVERSATION_LIMIT` | مکالمه بیش از حد طولانی شده | مکالمه تازه شروع کنید یا خلاصه‌سازی دستی انجام دهید |
| `ERR_INPUT_LIMIT` | ورودی بیش از سقف | متن را کوتاه کنید |
| `ERR_MODEL_RESTRICTED` | مدل برای سطح حساب شما مجاز نیست | یکی از مدل‌های رایگان جدول بالا را انتخاب کنید |
| `ERR_MODERATION_FLAG` / `ERR_REFUSAL` | محتوا رد/پرچم‌گذاری شده | درخواست را مطابق سیاست سرویس اصلاح کنید |
| `ERR_STREAM_EXPIRED` | stream ناتمام منقضی شده؛ حدود 15 دقیقه در گزارش | پیام را دوباره در نشست تازه بفرستید |
| `ERR_SERVICE_UNAVAILABLE` | سرویس موقتاً در دسترس نیست | بعداً با فاصله تلاش کنید |

در صورت 418 گاه‌به‌گاه، یک اجرای تازه با نشست جدید انجام دهید. از retry سنگین و موازی خودداری کنید؛ رفتار ضدربات و پنجره مصرف ممکن است بدتر شود.

---

## 12) عیب‌یابی سریع

| مشکل | علت محتمل | راه‌حل |
|---|---|---|
| `Cannot find package 'jsdom'` | dependency نصب نشده یا cwd اشتباه است | داخل پوشه بسته `npm install` یا `npm ci` اجرا کنید |
| Python خطای Node/solver می‌دهد | Node نیست یا `node_modules` در همان پوشه نیست | Node 20+ نصب کنید و در پوشه بسته `npm install` بزنید |
| `ERR_BN_LIMIT` | curl خام، هدرهای کتابخانه‌ای، توکن قدیمی یا fingerprint نامناسب | فقط از کلاینت‌ها استفاده کنید و بین solve و POST مکث نکنید |
| `ERR_CHALLENGE` | IP دیتاسنتری/ریسک بالا یا probe سخت‌تر | از شبکه/مرورگر معمولی اجرا کنید؛ دور زدن چالش تعاملی در این بسته نیست |
| پاسخ خالی ولی stream تمام شد | فقط فریم‌های reasoning/title آمده یا اتصال زود قطع شد | `sample_sse.txt` را با خروجی خام مقایسه کنید و فقط `role=assistant` را جمع کنید |
| در multi پیام قبلی یادش نیست | history با فرمت assistant اشتباه برگشته | از `--multi` کلاینت‌ها استفاده کنید؛ assistant history باید `parts` داشته باشد |
| بعد از مدتی کار نمی‌کند | نسخه فرانت‌اند یا چالش عوض شده | فایل‌ها نسخه را تازه می‌خوانند؛ اگر باز هم خطا بود، `REPORT_FA.md` و `openapi.yaml` را با نسخه جدید تطبیق دهید |
| مدل انتخابی کار نمی‌کند | مدل اشتراکی/محدود انتخاب شده | یکی از شش مدل رایگان را با `--model` انتخاب کنید |

---

## 13) استفاده از `openapi.yaml` و `REPORT_FA.md`

- `openapi.yaml` برای دیدن سریع method/path/header/body مفید است، اما چون API رسمی نیست، تولید کلاینت از آن به‌تنهایی کافی نیست؛ حل چالش و چرخش توکن باید مثل `duck_client.mjs` پیاده شود.
- `REPORT_FA.md` گزارش کامل فارسی است و برای این موارد به آن رجوع کنید: شواهد نسخه فرانت‌اند، هدرهای اختیاری، انواع فریم SSE، محدودیت تصویر/PDF، پنجره‌های مصرف و نتایج تست زنده.
- `sample_sse.txt` را کنار parser خودتان نگه دارید تا تفاوت فریم `reasoning` و `assistant` را درست پیاده کنید.

---

## 14) وضعیت تست زنده

در زمان استخراج، این موارد موفق بودند:

- `GET /duckchat/v1/capabilities` با HTTP 200 و JSON معتبر.
- `GET /duckchat/v1/status` با `x-vqd-accept: 1` و دریافت چالش در `x-vqd-hash-1`.
- چت تک‌نوبتی `gpt-6-luna` و دریافت پاسخ دقیق مورد انتظار از SSE.
- چت چندنوبتی و به‌یادآوردن سؤال قبلی با history canonical.
- چت `claude-haiku-4-5` از کلاینت Python.
- کنترل منفی: curl خام بدون توکن حل‌شده `418 ERR_BN_LIMIT` گرفت.

با گذشت زمان، نسخه فرانت‌اند و چالش ممکن است تغییر کند؛ کلاینت‌ها برای کم‌کردن این ریسک نسخه را تازه می‌خوانند و چالش را در DOM اجرا می‌کنند، اما تضمینی برای آینده وجود ندارد.

---

## 15) نکات مسئولانه

- این API داخلی/غیررسمی است؛ برای production حیاتی روی آن حساب نکنید.
- چالش ضدربات را فقط در حد اجرای پروتکل استخراج‌شده استفاده کنید؛ چالش تعاملی/کپچا را دور نزنید.
- نرخ درخواست را پایین نگه دارید و محدودیت‌های مصرف سرویس را رعایت کنید.
- توکن‌های حل‌شده، cookieها و challengeها را لاگ یا منتشر نکنید.
- مدل‌های اشتراکی را بدون اشتراک معتبر استفاده نکنید.

---

## 16) مسیر پیشنهادی برای هر هدف

| هدف | دستور |
|---|---|
| چت سریع | `node duck_client.mjs "سلام"` |
| انتخاب مدل دیگر | `node duck_client.mjs --model mistral-small-2603 "Hello"` |
| مکالمه چندنوبتی | `node duck_client.mjs --multi` |
| استفاده از Python | `python3 api_client.py --multi` |
| دیباگ چالش | `node solve_challenge.mjs @challenge.txt` |
| فهم SSE | خواندن `sample_sse.txt` و بخش 7 همین README |
| جزئیات عمیق پروتکل | `REPORT_FA.md` |
