#!/usr/bin/env node
/**
 * Duck.ai (DuckDuckGo AI Chat) — JSA anti-bot challenge solver.
 *
 * Duck.ai protects POST /duckchat/v1/chat with a JavaScript challenge:
 *   1. GET /duckchat/v1/status  (header: x-vqd-accept: 1)
 *      returns the challenge in the response header `x-vqd-hash-1`
 *      (base64 of an obfuscated `(async function(){...})()` program).
 *   2. The official web client executes that program inside a sandboxed
 *      <iframe sandbox="allow-scripts allow-same-origin"> and expects an
 *      object: { server_hashes, client_hashes, signals:{}, meta:{...} }.
 *   3. It then replaces every client_hashes entry h with
 *      base64( SHA-256( utf8(h) ) )  (raw digest bytes, standard base64),
 *      adds meta.origin / meta.stack / meta.duration, JSON-stringifies the
 *      whole object and base64-encodes it. That string is sent back as the
 *      `X-Vqd-Hash-1` request header of the chat call.
 *
 * This script reproduces steps 2-3 faithfully with jsdom (a real DOM), which
 * matters: the challenge variants probe layout metrics (offsetWidth,
 * getBoundingClientRect, getComputedStyle, ...). jsdom has no layout engine,
 * so we patch the layout getters to plausible non-zero values — the same
 * values a real browser would produce for the probed elements.
 *
 * Usage:
 *   node solve_challenge.mjs <base64-challenge | @file> [user-agent]
 * Prints the solved token (single line) to stdout.
 *
 * Requires: npm install jsdom
 */
import fs from 'node:fs';
import crypto from 'node:crypto';
import { JSDOM } from 'jsdom';

const arg = process.argv[2];
if (!arg) {
  console.error('usage: node solve_challenge.mjs <base64-challenge | @file> [user-agent]');
  process.exit(1);
}
const challengeB64 = arg.startsWith('@')
  ? fs.readFileSync(arg.slice(1), 'utf8').trim()
  : arg;
const UA =
  process.argv[3] ||
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const code = Buffer.from(challengeB64, 'base64').toString('utf8');

const dom = new JSDOM('<!DOCTYPE html><html><head></head><body></body></html>', {
  url: 'https://duck.ai/',
  runScripts: 'outside-only',
  pretendToBeVisual: true,
});
const { window } = dom;

// The web client runs the challenge inside a sandboxed iframe with a blank
// srcDoc page. Mirror that so `window.top`, `document`, `navigator`, ...
// look the way the challenge expects.
const iframe = window.document.createElement('iframe');
iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin');
window.document.body.appendChild(iframe);
const iw = iframe.contentWindow;

try {
  Object.defineProperty(iw.navigator, 'userAgent', { value: UA, configurable: true });
  Object.defineProperty(iw.navigator, 'webdriver', { value: false, configurable: true });
} catch { /* best effort */ }

// jsdom performs no layout: every metric is 0, which real browsers never
// return for attached elements. Patch plausible non-zero values.
try {
  const proto = iw.HTMLElement.prototype;
  const dims = {
    offsetWidth: 12, offsetHeight: 18,
    clientWidth: 12, clientHeight: 18,
    scrollWidth: 12, scrollHeight: 18,
  };
  for (const [k, v] of Object.entries(dims)) {
    Object.defineProperty(proto, k, { get() { return v; }, configurable: true });
  }
  proto.getBoundingClientRect = function () {
    return {
      x: 0, y: 0, top: 0, left: 0, right: 12, bottom: 18, width: 12, height: 18,
      toJSON() { return {}; },
    };
  };
} catch { /* best effort */ }

const started = Date.now();
let result;
try {
  result = await iw.eval(code);
} catch (e) {
  // Mirror the official client's error path: it still returns a token built
  // from "<decoded>::<error>::<stack>::<origin>".
  const fallback = Buffer.from(
    `${code}::${e && e.message ? e.message : String(e)}::${e && e.stack ? e.stack : 'no-stack'}::https://duck.ai`,
    'utf8',
  ).toString('base64');
  console.log(fallback);
  process.exit(0);
}

if (!result || typeof result !== 'object' || !('client_hashes' in result)) {
  console.error('unexpected challenge result:', JSON.stringify(result));
  process.exit(2);
}

const sha256B64 = (s) =>
  crypto.createHash('sha256').update(Buffer.from(String(s), 'utf8')).digest().toString('base64');

let stack = 'no-stack';
try {
  throw new Error('jsa');
} catch (e) {
  stack = String(e.stack || '').split('\n').slice(0, 5).join('\n');
}

const solvedObj = {
  ...result,
  client_hashes: await Promise.all(result.client_hashes.map(sha256B64)),
  meta: {
    ...(result.meta || {}),
    origin: 'https://duck.ai',
    stack,
    duration: String(Math.max(1, Date.now() - started)),
  },
};

console.log(Buffer.from(JSON.stringify(solvedObj), 'utf8').toString('base64'));
