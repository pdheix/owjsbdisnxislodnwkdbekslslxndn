#!/usr/bin/env python3
"""
KikiVoice internal web API client (reverse-engineered from the public frontend).

IMPORTANT: kikivoice.ai states in its FAQ that it does not currently provide a
public API. These are the site's own internal `/jsapi/...` endpoints used by the
web UI. They may change without notice and first-time generation can require a
GeeTest human verification (error_code 777). Use only in accordance with the
site's terms.

No third-party packages are required.
"""
from __future__ import annotations

import argparse
import json
import mimetypes
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from http.cookiejar import CookieJar
from pathlib import Path

BASE = "https://kikivoice.ai"
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
)


class KikiClient:
    def __init__(self) -> None:
        self.cj = CookieJar()
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self.cj)
        )

    def request(
        self,
        path: str,
        *,
        method: str = "GET",
        data: bytes | None = None,
        headers: dict[str, str] | None = None,
        referer: str = "/text-to-speech",
        timeout: int = 60,
    ) -> tuple[int, str, bytes]:
        url = path if path.startswith("http") else BASE + path
        h = {"User-Agent": UA, "Accept": "application/json", "Referer": BASE + referer}
        if headers:
            h.update(headers)
        req = urllib.request.Request(url, data=data, headers=h, method=method)
        try:
            with self.opener.open(req, timeout=timeout) as resp:
                return resp.status, resp.headers.get_content_type(), resp.read()
        except urllib.error.HTTPError as e:
            return e.code, e.headers.get_content_type() if e.headers else "", e.read()

    def json(self, path: str, **kw) -> dict:
        status, _ctype, body = self.request(path, **kw)
        try:
            data = json.loads(body.decode("utf-8", "replace"))
        except Exception:
            data = {"http_status": status, "raw": body[:500].decode("utf-8", "replace")}
        data.setdefault("_http_status", status)
        return data

    def warm_cookie(self, page: str = "/text-to-speech") -> None:
        """Load a page once so the server sets the anonymous `uuid` cookie."""
        self.request(page, headers={"Accept": "text/html"})

    # ----- TTS catalog / models -----
    def tts_models(self) -> dict:
        self.warm_cookie("/text-to-speech")
        return self.json("/jsapi/tts/tts-model-capabilities")

    def clone_models(self) -> dict:
        self.warm_cookie("/ai-voice-cloning")
        return self.json("/jsapi/model-capabilities", referer="/ai-voice-cloning")

    def voices(self, lang: str = "en") -> dict:
        self.warm_cookie("/text-to-speech")
        q = urllib.parse.urlencode({"lang_str": lang})
        return self.json(f"/jsapi/tts/get-all-tts-voice-data?{q}")

    def detect_language(self, text: str) -> dict:
        self.warm_cookie("/text-to-speech")
        body = json.dumps({"text": text}, ensure_ascii=False).encode("utf-8")
        return self.json(
            "/jsapi/detect-language",
            method="POST",
            data=body,
            headers={"Content-Type": "application/json"},
        )

    # ----- TTS generation -----
    @staticmethod
    def multipart(fields: dict[str, object]) -> tuple[bytes, str]:
        boundary = "----kiki-" + uuid.uuid4().hex
        out = []
        for name, value in fields.items():
            out.append(f"--{boundary}\r\n".encode())
            out.append(
                f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode()
            )
            out.append(str(value).encode("utf-8"))
            out.append(b"\r\n")
        out.append(f"--{boundary}--\r\n".encode())
        return b"".join(out), f"multipart/form-data; boundary={boundary}"

    def create_tts_task(
        self,
        *,
        text: str,
        voice_id: str,
        voice_code: str,
        library_type: str = "llm",
        lang_name_code: str = "en",
        model_type: str | None = None,
        model_version_text: str | None = None,
        speed: float = 1.0,
        volume: int = 100,
        pitch: float = 1.0,
        audio_format: str = "mp3",
        audio_high_quality: int = 0,
        emotion: str = "normal",
        intensity: str = "normal",
        region: str = "",
        voice_gender: int = 0,
    ) -> dict:
        self.warm_cookie("/text-to-speech")
        if model_type is None:
            model_type = "kiki_core" if library_type == "standard" else "kiki_core"
        if model_version_text is None:
            model_version_text = "v2" if model_type == "kiki_multilingual" else "default"
        fields = {
            "library_type": library_type,
            "voice_code": voice_code,
            "voice_id": voice_id,
            "text": text,
            "lang_name_code": lang_name_code,
            "speed": speed,
            "volume": volume,
            "pitch": pitch,
            "audio_format": audio_format,
            "audio_high_quality": audio_high_quality,
            "model_type": model_type,
            "model_version_text": model_version_text,
            "emotion": emotion if model_type == "kiki_pro" else "normal",
            "intensity": intensity if model_type == "kiki_pro" else "normal",
            "region": region,
            "voice_gender": voice_gender if model_type == "kiki_multilingual" else 0,
        }
        body, ctype = self.multipart(fields)
        return self.json(
            "/jsapi/tts/create-new-tts-task",
            method="POST",
            data=body,
            headers={"Content-Type": ctype},
            timeout=70,
        )

    def tts_status(self, job_id: str, library_type: str = "llm") -> dict:
        q = urllib.parse.urlencode({"job_id": job_id, "library_type": library_type})
        return self.json(f"/jsapi/tts/get-tts-task-status?{q}")

    def create_and_wait(self, *, poll_seconds: int = 3, max_seconds: int = 390, **kw) -> dict:
        created = self.create_tts_task(**kw)
        job_id = created.get("job_id") or (created.get("data") or {}).get("job_id")
        if not job_id:
            return created
        started = time.time()
        last = created
        while time.time() - started < max_seconds:
            time.sleep(poll_seconds)
            last = self.tts_status(job_id, kw.get("library_type", "llm"))
            state = int(last.get("job_state", last.get("state", 0)) or 0)
            audio = last.get("audiourl") or last.get("audio_url")
            if state == 1 and audio:
                return last
            if state in (1, 2, -1):
                return last
        return last

    # ----- cloning helpers -----
    def auth_status(self) -> dict:
        self.warm_cookie("/ai-voice-cloning")
        return self.json("/jsapi/auth/check-status", referer="/ai-voice-cloning")

    def cloning_sig(self) -> dict:
        self.warm_cookie("/ai-voice-cloning")
        return self.json("/jsapi/get-cloning-file-sig", referer="/ai-voice-cloning")

    @staticmethod
    def multipart_file(
        file_field: str,
        filename: str,
        file_bytes: bytes,
        content_type: str,
        fields: dict[str, object] | None = None,
    ) -> tuple[bytes, str]:
        boundary = "----kiki-" + uuid.uuid4().hex
        out = []
        for name, value in (fields or {}).items():
            out.append(f"--{boundary}\r\n".encode())
            out.append(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
            out.append(str(value).encode("utf-8"))
            out.append(b"\r\n")
        out.append(f"--{boundary}\r\n".encode())
        safe_name = filename.replace('"', "")
        out.append(
            f'Content-Disposition: form-data; name="{file_field}"; filename="{safe_name}"\r\n'.encode()
        )
        out.append(f"Content-Type: {content_type}\r\n\r\n".encode())
        out.append(file_bytes)
        out.append(b"\r\n")
        out.append(f"--{boundary}--\r\n".encode())
        return b"".join(out), f"multipart/form-data; boundary={boundary}"

    def _sig_or_raise(self) -> dict:
        data = self.cloning_sig()
        if data.get("error_code") not in (0, "0") or not data.get("sig"):
            raise RuntimeError(f"Could not get cloning signature: {data}")
        return data

    def clone_upload(self, file_path: str, voice_name: str, denoise: int = 0) -> dict:
        """Upload/record a reference voice to the signed custom-voice microservice."""
        sig = self._sig_or_raise()
        base_url = sig["kiki_voice_microservices_api_create_voice_url"]
        q = urllib.parse.urlencode(
            {"voice_name": voice_name, "denoise": denoise, "asr": 1, "sig": sig["sig"]}
        )
        p = Path(file_path)
        ctype = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        body, content_type = self.multipart_file("voice-file", p.name, p.read_bytes(), ctype)
        return self.json(
            f"{base_url}?{q}",
            method="POST",
            data=body,
            headers={"Content-Type": content_type},
            referer="/ai-voice-cloning",
            timeout=120,
        )

    def clone_list(self) -> dict:
        sig = self._sig_or_raise()
        base_url = sig["kiki_voice_microservices_api_voice_list_url"]
        q = urllib.parse.urlencode({"sig": sig["sig"]})
        return self.json(f"{base_url}?{q}", referer="/ai-voice-cloning")

    def clone_delete(self, voice_id: str) -> dict:
        sig = self._sig_or_raise()
        base_url = sig["kiki_voice_microservices_api_delete_voice_url"]
        q = urllib.parse.urlencode({"sig": sig["sig"]})
        body = json.dumps({"voice_id_list": [voice_id]}).encode("utf-8")
        return self.json(
            f"{base_url}?{q}",
            method="POST",
            data=body,
            headers={"Content-Type": "application/json"},
            referer="/ai-voice-cloning",
        )

    def clone_create_task(
        self,
        *,
        text: str,
        custom_voice_id: str,
        lang_name_code: str = "en",
        model_type: str = "kiki_core",
        model_version_text: str | None = None,
        emotion: str = "normal",
        intensity: str = "normal",
        region: str = "",
        speed: float = 1.0,
        volume: int = 100,
        audio_format: str = "mp3",
        audio_high_quality: int = 0,
        voice_gender: int = 0,
        prompt_text: str = "",
        prompt_text_language: str = "",
    ) -> dict:
        self.warm_cookie("/ai-voice-cloning")
        if model_version_text is None:
            model_version_text = "v2" if model_type == "kiki_multilingual" else "default"
        fields: dict[str, object] = {
            "text": text,
            "clone_source_voice_custom_voice_id": custom_voice_id,
            "lang_name_code": lang_name_code,
            "emotion": emotion,
            "intensity": intensity,
            "clone_source_voice_gender": voice_gender,
            "model_type": model_type,
            "speed": speed,
            "volume": volume,
            "audio_format": audio_format,
            "audio_high_quality": audio_high_quality,
            "model_version_text": model_version_text,
        }
        if region:
            fields["region"] = region
        if prompt_text:
            fields["clone_source_voice_prompt_text"] = prompt_text
            if prompt_text_language:
                fields["clone_source_voice_prompt_text_language"] = prompt_text_language
        body, ctype = self.multipart(fields)
        return self.json(
            "/jsapi/create-new-clone-task",
            method="POST",
            data=body,
            headers={"Content-Type": ctype},
            referer="/ai-voice-cloning",
            timeout=70,
        )

    def clone_status(self, job_id: str) -> dict:
        q = urllib.parse.urlencode({"job_id": job_id})
        return self.json(f"/jsapi/get-job-task-status?{q}", referer="/ai-voice-cloning")

    def clone_preview(self, voice_id: str, out_path: str) -> tuple[int, str, int]:
        """Download/playback file for an uploaded custom voice.

        Frontend playback URL:
        https://custom-voice-upload.kikivoice.ai/file/{voice_id}?sig=...
        Returns (http_status, content_type, byte_count) and writes out_path.
        """
        sig = self._sig_or_raise()
        q = urllib.parse.urlencode({"sig": sig["sig"]})
        url = f"https://custom-voice-upload.kikivoice.ai/file/{urllib.parse.quote(voice_id)}?{q}"
        status, ctype, body = self.request(url, referer="/ai-voice-cloning", timeout=120)
        if status == 200:
            Path(out_path).write_bytes(body)
        else:
            try:
                detail = body.decode("utf-8", "replace")[:500]
            except Exception:
                detail = ""
            raise RuntimeError(f"Preview download failed HTTP {status}: {detail}")
        return status, ctype, len(body)

    def clone_create_and_wait(
        self, *, poll_seconds: int = 3, max_seconds: int = 390, **kw
    ) -> dict:
        created = self.clone_create_task(**kw)
        job_id = created.get("job_id") or (created.get("data") or {}).get("job_id")
        if not job_id:
            return created
        started = time.time()
        last = created
        while time.time() - started < max_seconds:
            time.sleep(poll_seconds)
            last = self.clone_status(job_id)
            state = int(last.get("job_state", last.get("state", 0)) or 0)
            audio = last.get("audiourl") or last.get("audio_url")
            if state == 1 and audio:
                return last
            if state in (1, 2, -1):
                return last
        return last


def print_json(data: object) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2))


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="KikiVoice internal web API client")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("models", help="TTS model capabilities")
    sub.add_parser("clone-models", help="Clone model capabilities")
    p = sub.add_parser("voices", help="Voice catalog")
    p.add_argument("--lang", default="en")
    p.add_argument("--fa", action="store_true", help="Only print fa/fa-IR voices")
    p = sub.add_parser("detect", help="Detect language")
    p.add_argument("text")
    sub.add_parser("auth-status")
    sub.add_parser("clone-sig")

    p = sub.add_parser("create", help="Create a TTS task and poll until done")
    p.add_argument("text")
    p.add_argument("--voice-id", required=True)
    p.add_argument("--voice-code", required=True)
    p.add_argument("--library-type", choices=["llm", "standard"], default="llm")
    p.add_argument("--lang", default="en", dest="lang_name_code")
    p.add_argument("--model", default=None, dest="model_type")
    p.add_argument("--format", default="mp3", dest="audio_format")
    p.add_argument("--speed", type=float, default=1.0)
    p.add_argument("--volume", type=int, default=100)
    p.add_argument("--pitch", type=float, default=1.0)
    p.add_argument("--emotion", default="normal")
    p.add_argument("--intensity", default="normal")
    p.add_argument("--region", default="")
    p.add_argument("--voice-gender", type=int, default=0)
    p.add_argument("--out", help="Download the finished audio to this file")

    p = sub.add_parser("status", help="Poll one library-voice TTS job once")
    p.add_argument("job_id")
    p.add_argument("--library-type", choices=["llm", "standard"], default="llm")

    p = sub.add_parser("clone-upload", help="Upload a reference voice file")
    p.add_argument("file")
    p.add_argument("--name", required=True, help="Voice name")
    p.add_argument("--denoise", type=int, default=0)
    sub.add_parser("clone-list", help="List uploaded custom voices")
    p = sub.add_parser("clone-delete", help="Delete an uploaded custom voice")
    p.add_argument("voice_id")
    p = sub.add_parser("clone-preview", help="Download an uploaded custom voice preview/file")
    p.add_argument("voice_id")
    p.add_argument("--out", required=True)
    p = sub.add_parser("clone-create", help="Create a cloned-voice task and poll")
    p.add_argument("text")
    p.add_argument("--voice-id", required=True, help="Custom voice id from clone-list")
    p.add_argument("--lang", default="en", dest="lang_name_code")
    p.add_argument("--model", default="kiki_core", dest="model_type")
    p.add_argument("--format", default="mp3", dest="audio_format")
    p.add_argument("--speed", type=float, default=1.0)
    p.add_argument("--volume", type=int, default=100)
    p.add_argument("--emotion", default="normal")
    p.add_argument("--intensity", default="normal")
    p.add_argument("--region", default="")
    p.add_argument("--voice-gender", type=int, default=0)
    p.add_argument("--out", help="Download the finished audio to this file")
    p = sub.add_parser("clone-status", help="Poll one clone job once")
    p.add_argument("job_id")

    args = ap.parse_args(argv)
    c = KikiClient()

    if args.cmd == "models":
        print_json(c.tts_models())
    elif args.cmd == "clone-models":
        print_json(c.clone_models())
    elif args.cmd == "voices":
        data = c.voices(args.lang)
        if args.fa:
            out = []
            for lib in (data.get("data") or {}).get("libraries", {}).values():
                for v in lib.get("voices", []):
                    if str(v.get("language_hint", "")).lower().startswith("fa"):
                        out.append(v)
            print_json(out)
        else:
            print_json(data)
    elif args.cmd == "detect":
        print_json(c.detect_language(args.text))
    elif args.cmd == "auth-status":
        print_json(c.auth_status())
    elif args.cmd == "clone-sig":
        data = c.cloning_sig()
        if "sig" in data:
            data["sig"] = "<redacted>"
        print_json(data)
    elif args.cmd == "create":
        result = c.create_and_wait(
            text=args.text,
            voice_id=args.voice_id,
            voice_code=args.voice_code,
            library_type=args.library_type,
            lang_name_code=args.lang_name_code,
            model_type=args.model_type,
            audio_format=args.audio_format,
            speed=args.speed,
            volume=args.volume,
            pitch=args.pitch,
            emotion=args.emotion,
            intensity=args.intensity,
            region=args.region,
            voice_gender=args.voice_gender,
        )
        print_json(result)
        audio = result.get("audiourl") or result.get("audio_url")
        if audio and args.out:
            status, _ctype, body = c.request(audio, referer="/text-to-speech")
            Path(args.out).write_bytes(body)
            print(f"saved {args.out} ({len(body)} bytes, HTTP {status})", file=sys.stderr)
        if result.get("error_code") not in (0, "0", None) and not audio:
            return 2
    elif args.cmd == "status":
        print_json(c.tts_status(args.job_id, args.library_type))
    elif args.cmd == "clone-upload":
        print_json(c.clone_upload(args.file, args.name, args.denoise))
    elif args.cmd == "clone-list":
        print_json(c.clone_list())
    elif args.cmd == "clone-delete":
        print_json(c.clone_delete(args.voice_id))
    elif args.cmd == "clone-preview":
        status, ctype, n = c.clone_preview(args.voice_id, args.out)
        print(f"saved {args.out} ({n} bytes, HTTP {status}, {ctype})", file=sys.stderr)
    elif args.cmd == "clone-status":
        print_json(c.clone_status(args.job_id))
    elif args.cmd == "clone-create":
        result = c.clone_create_and_wait(
            text=args.text,
            custom_voice_id=args.voice_id,
            lang_name_code=args.lang_name_code,
            model_type=args.model_type,
            audio_format=args.audio_format,
            speed=args.speed,
            volume=args.volume,
            emotion=args.emotion,
            intensity=args.intensity,
            region=args.region,
            voice_gender=args.voice_gender,
        )
        print_json(result)
        audio = result.get("audiourl") or result.get("audio_url")
        if audio and args.out:
            status, _ctype, body = c.request(audio, referer="/ai-voice-cloning")
            Path(args.out).write_bytes(body)
            print(f"saved {args.out} ({len(body)} bytes, HTTP {status})", file=sys.stderr)
        if result.get("error_code") not in (0, "0", None) and not audio:
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
