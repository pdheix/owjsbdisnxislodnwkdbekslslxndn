# KikiVoice API Package — راهنمای کامل استفاده

این بسته، API داخلی وب‌سایت **KikiVoice** به نشانی `https://kikivoice.ai` را مستند و قابل اجرا می‌کند؛ همان APIای که فرانت‌اند سایت برای Text-to-Speech، کاتالوگ صداها، تشخیص زبان و Voice Cloning استفاده می‌کند.

> **هشدار مهم:** KikiVoice در FAQ رسمی خود اعلام کرده است که فعلاً **Public Developer API** ارائه نمی‌کند. اندپوینت‌های این بسته، API داخلی و بدون سند رسمی (`/jsapi/...`) هستند؛ ممکن است بدون اطلاع تغییر کنند. از آن‌ها فقط مطابق قوانین سایت و با صداهایی استفاده کنید که حق استفاده/کلون‌کردنشان را دارید.

تاریخ استخراج و آخرین بررسی فایل‌ها: **2026-10-29**.

---

## 1) این بسته چه کارهایی را پوشش می‌دهد؟

همه اکشن‌های API استخراج‌شده و قابل اجرای این بسته:

| # | اکشن | Endpoint اصلی | کلاینت Python | کلاینت Node | curl |
|---:|---|---|:---:|:---:|:---:|
| 1 | دریافت قابلیت مدل‌های TTS | `GET /jsapi/tts/tts-model-capabilities` | ✅ `models` | ✅ `models` | ✅ |
| 2 | دریافت قابلیت مدل‌های Clone | `GET /jsapi/model-capabilities` | ✅ `clone-models` | ✅ `clone-models` | ✅ |
| 3 | دریافت کاتالوگ صداها | `GET /jsapi/tts/get-all-tts-voice-data` | ✅ `voices` | ✅ `voices` | ✅ |
| 4 | تشخیص زبان متن | `POST /jsapi/detect-language` | ✅ `detect` | ✅ `detect` | ✅ |
| 5 | بررسی وضعیت تأیید انسان | `GET /jsapi/auth/check-status` | ✅ `auth-status` | ❌ | دستی |
| 6 | گرفتن امضای میکروسرویس کلون | `GET /jsapi/get-cloning-file-sig` | ✅ `clone-sig` | ❌ | دستی |
| 7 | ساخت TTS با صدای آماده و Poll خودکار | `POST /jsapi/tts/create-new-tts-task` | ✅ `create` | ✅ `create` | نمونه ساخت |
| 8 | Poll یک تسک TTS | `GET /jsapi/tts/get-tts-task-status` | ✅ `status` | ❌ | نمونه کامنت‌شده |
| 9 | آپلود فایل صدای مرجع برای کلون | `POST {create_voice_url}` | ✅ `clone-upload` | ❌ | قالب خام در همین README |
| 10 | لیست صداهای کلون‌شده کاربر ناشناس | `GET {voice_list_url}` | ✅ `clone-list` | ❌ | قالب خام در همین README |
| 11 | دانلود/پخش فایل صدای کلون‌شده | `GET https://custom-voice-upload.kikivoice.ai/file/{voice_id}` | ✅ `clone-preview` | ❌ | قالب خام در همین README |
| 12 | حذف صدای کلون‌شده | `POST {delete_voice_url}` | ✅ `clone-delete` | ❌ | قالب خام در همین README |
| 13 | ساخت صدا با صدای کلون‌شده و Poll خودکار | `POST /jsapi/create-new-clone-task` | ✅ `clone-create` | ❌ | قالب خام در همین README |
| 14 | Poll یک تسک کلون | `GET /jsapi/get-job-task-status` | ✅ `clone-status` | ❌ | قالب خام در همین README |

نتیجه عملی: **کلاینت Python کامل‌ترین فایل این بسته است.** کلاینت Node برای خواندن مدل/کاتالوگ، تشخیص زبان و ساخت TTS با صدای آماده مناسب است؛ برای Clone از Python استفاده کنید.

---

## 2) فایل‌های داخل ZIP و کاربرد هرکدام

| فایل | کاربرد | چطور استفاده می‌شود؟ |
|---|---|---|
| `README.md` | همین راهنمای مستقل | مرجع اصلی قرارداد API، payloadها، پاسخ‌ها، خطاها و دستورها |
| `api_client.py` | کلاینت کامل Python؛ بدون پکیج خارجی | اجرای همه ۱۴ اکشن جدول بالا با CLI یا import در کد Python |
| `api_client.mjs` | کلاینت سبک Node برای اکشن‌های اصلی TTS | اجرای `models`، `clone-models`، `voices`، `detect` و `create` |
| `curl_examples.sh` | نمونه‌های خام curl برای cookie، مدل‌ها، کاتالوگ، تشخیص زبان و ساخت TTS | مطالعه یا اجرای اسکریپت؛ بعضی بخش‌های Poll به‌صورت کامنت الگو هستند |
| `openapi.yaml` | مشخصات OpenAPI 3 تقریبی از روی ترافیک فرانت‌اند | import در Swagger UI/Postman/Insomnia یا تولید کلاینت؛ برای `/jsapi` است و امضاهای زنده ندارد |
| `tts_model_capabilities.json` | خروجی زنده قابلیت مدل‌های TTS هنگام استخراج | دیدن آفلاین زبان‌ها، سقف متن، نرخ اعتبار، emotion/region و نسخه مدل‌ها |
| `clone_model_capabilities.json` | خروجی زنده قابلیت مدل‌ها از مسیر Clone | مقایسه همان مدل‌ها در envelope صفحه کلون |
| `voices_full.json` | کاتالوگ کامل صداها هنگام استخراج؛ 910 صدا | جست‌وجوی آفلاین `voice_id`، `voice_code`، جنسیت، زبان و sample |
| `persian_voices.json` | زیرمجموعه صداهای فارسی کاتالوگ | انتخاب سریع صدای فارسی استاندارد |
| `clone_signature_response_structure_redacted.json` | ساختار پاسخ امضای کلون، بدون sig واقعی | فهم فیلدهای پاسخ `get-cloning-file-sig` بدون افشای مقدار حساس |
| `clone_signature_error_without_uuid_cookie.json` | نمونه خطای نبود cookie | تشخیص خطای `UUID_REQUIRED` |

هیچ فایل این بسته شامل `sig` واقعی، cookie واقعی یا URL امضاشده دائمی نیست. این مقادیر هنگام اجرا از سرور گرفته می‌شوند و نباید ذخیره/منتشر شوند.

---

## 3) پیش‌نیازها و شروع سریع

### پیش‌نیاز

- Python 3.10 یا جدیدتر — برای `api_client.py`؛ فقط کتابخانه استاندارد استفاده شده و `pip install` لازم نیست.
- Node.js 18 یا جدیدتر — فقط اگر می‌خواهید `api_client.mjs` را اجرا کنید.
- اتصال اینترنت و دسترسی به `kikivoice.ai`.
- برای خروجی صوتی موفق ممکن است حساب/نشست ناشناس شما سهمیه داشته باشد و در تولید اول، تأیید انسان GeeTest لازم شود.

### شروع سریع با Python

```bash
unzip kikivoice.zip
cd kikivoice

python3 api_client.py models
python3 api_client.py voices --fa
python3 api_client.py detect "سلام من پرهام هستم"
```

ساخت TTS فارسی با صدای استاندارد زن فارسی:

```bash
python3 api_client.py create "سلام، این یک تست کوتاه است." \
  --library-type standard \
  --voice-id standard_410001 \
  --voice-code S233 \
  --lang fa \
  --out test-fa.mp3
```

ساخت TTS فارسی با صدای استاندارد مرد فارسی:

```bash
python3 api_client.py create "سلام، این یک تست کوتاه است." \
  --library-type standard \
  --voice-id standard_410002 \
  --voice-code S234 \
  --lang fa \
  --out test-fa-male.mp3
```

### شروع سریع با Node

```bash
node api_client.mjs models
node api_client.mjs voices --fa
node api_client.mjs detect "سلام من پرهام هستم"
node api_client.mjs create "Hello from KikiVoice" \
  --library-type llm --voice-id VOICE_ID --voice-code VOICE_CODE \
  --lang en --out test-en.mp3
```

در بعضی شبکه‌ها/محیط‌های دیتاسنتری، Node ممکن است از Cloudflare پاسخ `403` بگیرد؛ در تست ما Python و curl قابل اتکاتر بودند. اگر Node خطای HTML/403 داد، همان دستور را با `api_client.py` اجرا کنید.

---

## 4) احراز هویت و چرخه نشست

KikiVoice برای این API داخلی API Key یا هدر `Authorization` ندارد. نشست بر اساس cookie ناشناس و گاهی تأیید انسان کار می‌کند:

1. کلاینت ابتدا یکی از صفحات سایت را باز می‌کند؛ مثلاً:
   - TTS: `GET https://kikivoice.ai/text-to-speech`
   - Clone: `GET https://kikivoice.ai/ai-voice-cloning`
2. سرور cookie ناشناس `uuid` تنظیم می‌کند. کلاینت Python آن را در `CookieJar` نگه می‌دارد؛ کلاینت Node هدر `Cookie` را در حافظه نگه می‌دارد.
3. درخواست‌های بعدی با همان cookie و `Referer` صفحه مربوطه ارسال می‌شوند.
4. برای Clone، کلاینت از `GET /jsapi/get-cloning-file-sig` یک `sig` موقت و URLهای میکروسرویس می‌گیرد.
5. در اولین تولید از یک IP/نشست جدید، ممکن است پاسخ زیر برگردد:

```json
{
  "success": false,
  "error_code": 777,
  "error_summary": "HUMAN_VERIFICATION_REQUIRED",
  "msg": "First-time verification: Verifying you are human.",
  "auth_solution": "GEETEST"
}
```

این یعنی payload الزاماً اشتباه نیست؛ سایت تأیید انسان می‌خواهد. راه درست این است که همان مسیر را در مرورگر واقعی باز کنید و GeeTest را به‌صورت انسانی کامل کنید. این بسته captcha را دور نمی‌زند.

بررسی وضعیت تأیید:

```bash
python3 api_client.py auth-status
```

نمونه پاسخ:

```json
{"authenticated": false}
```

---

## 5) قرارداد عمومی پاسخ‌ها

بیشتر endpointهای `/jsapi` یک envelope JSON شبیه این برمی‌گردانند؛ همه فیلدها در همه endpointها الزاماً وجود ندارند:

```json
{
  "success": true,
  "error_code": 0,
  "error_summary": "SUCCESS",
  "msg": "",
  "data": {}
}
```

فیلدهای مهم:

| فیلد | معنی |
|---|---|
| `success` | موفقیت منطقی عملیات؛ در بعضی پاسخ‌ها ممکن است وجود نداشته باشد و باید `error_code` را هم بررسی کرد |
| `error_code` | `0` یعنی موفق؛ `777` یعنی نیاز به تأیید انسان؛ `-1` در خطای امضا یعنی خطای عمومی/نشست |
| `error_summary` | کد متنی خطا مثل `UUID_REQUIRED`، `QUOTA_EXCEEDED` یا `SUCCESS` |
| `msg` | پیام قابل نمایش/تشخیص |
| `data` | بدنه اصلی در endpointهای catalog/capabilities |
| `job_id` | شناسه تسک در ساخت TTS/Clone |
| `quota_info` | اطلاعات سهمیه/اعتبار پس از ساخت تسک، وقتی سرور برگرداند |
| `estimated_time_seconds` | زمان تخمینی پردازش، وقتی برگردد |
| `heartbeat_interval_seconds` | فاصله پیشنهادی Poll، وقتی برگردد |
| `audiourl` یا `audio_url` | URL فایل صوتی نهایی در پاسخ status موفق |
| `job_state` | وضعیت تسک: `0` در حال پردازش، `1` موفق، `-1` یا `2` خطادار/ناموفق |

کلاینت‌های این بسته برای راحتی یک فیلد کمکی `_http_status` هم به خروجی JSON اضافه می‌کنند؛ این فیلد جزو API سایت نیست.

---

## 6) مدل‌ها و انتخاب درست برای فارسی

داده کامل و زنده مدل‌ها در `tts_model_capabilities.json` و `clone_model_capabilities.json` هست. خلاصه استخراج‌شده:

| `model_type` | زبان‌ها | سقف متن | نرخ اعتبار | قابلیت مهم | فارسی |
|---|---:|---:|---:|---|:---:|
| `kiki_core` | 34 | 1000 کاراکتر | 2.0x | مدل عمومی | ✅ |
| `kiki_pro` | 9 | 500 کاراکتر | 3.0x | `emotion` و `intensity` و region | ❌ |
| `kiki_multilingual` | 72 | 2000 کاراکتر | 2.0x | region و `voice_gender` | ✅ |
| کتابخانه `standard` | وابسته به صدا | 3000 کاراکتر | 1.0x | ارزان‌تر؛ با `kiki_core` ارسال می‌شود | ✅ برای صداهای fa |

قواعد انتخاب:

- برای فارسی استاندارد و ساده: `library_type=standard` + `S233`/`S234` + `model_type=kiki_core`.
- برای فارسی با صدای LLM: `library_type=llm` + `--model kiki_multilingual` و `model_version_text=v2` (کلاینت خودش برای multilingual مقدار `v2` می‌گذارد).
- `kiki_pro` برای فارسی استفاده نکنید؛ در داده استخراج‌شده فارسی ندارد.
- `emotion` و `intensity` فقط برای `kiki_pro` معنا دارند؛ کلاینت برای مدل‌های دیگر آن‌ها را `normal` می‌فرستد.
- `voice_gender` فقط برای `kiki_multilingual` معنا دارد: `0` مرد، `1` زن.

مشاهده آفلاین مدل‌ها:

```bash
python3 -m json.tool tts_model_capabilities.json | head -120
python3 api_client.py models
python3 api_client.py clone-models
```

---

## 7) کاتالوگ صداها و پیدا کردن `voice_id`/`voice_code`

Endpoint:

```http
GET https://kikivoice.ai/jsapi/tts/get-all-tts-voice-data?lang_str=en
```

پارامتر `lang_str` بیشتر برای محلی‌سازی برچسب‌هاست. ساختار کلی پاسخ:

```json
{
  "success": true,
  "error_code": 0,
  "data": {
    "voice_counts": {"total": 910, "llm": 600, "standard": 310},
    "libraries": {
      "llm": {"voices": []},
      "standard": {"voices": []}
    }
  }
}
```

هر voice معمولاً فیلدهایی مثل این‌ها دارد:

| فیلد | کاربرد |
|---|---|
| `voice_id` | شناسه لازم برای ساخت تسک؛ مثل `standard_410001` |
| `voice_code` | کد لازم برای ساخت تسک؛ مثل `S233` |
| `display_name` | نام نمایشی |
| `gender` | `0` مرد، `1` زن |
| `language_hint` | زبان/نشانه زبان صدا؛ مثل `fa-IR` یا `en` |
| `language_display_name` | نام زبان برای نمایش |
| `category_name` | دسته‌بندی |
| `sample_audio_url` | نمونه صدا، اگر موجود باشد |
| `avatar_url` | تصویر صدا، اگر موجود باشد |
| `style_tags` | برچسب‌های سبک |
| `status` | وضعیت فعال/قابل استفاده |

دستورها:

```bash
# فقط صداهای فارسی از پاسخ زنده
python3 api_client.py voices --fa
node api_client.mjs voices --fa

# کل کاتالوگ زنده؛ خروجی بزرگ است
python3 api_client.py voices --lang en > voices-live.json

# جست‌وجو در فایل آفلاین داخل بسته
python3 - <<'PY'
import json
from pathlib import Path
data = json.loads(Path("voices_full.json").read_text(encoding="utf-8"))
for lib_name, lib in data["data"]["libraries"].items():
    for v in lib["voices"]:
        if str(v.get("language_hint", "")).lower().startswith("fa"):
            print(lib_name, v.get("voice_code"), v.get("voice_id"), v.get("display_name"), v.get("gender"))
PY
```

صداهای فارسی استاندارد تأییدشده در کاتالوگ:

| جنسیت | `voice_code` | `voice_id` | توضیح |
|---|---|---|---|
| زن | `S233` | `standard_410001` | Mila - Iran Female Voice / فارسی |
| مرد | `S234` | `standard_410002` | Jonah - Iran Male Voice / فارسی |

نکته: صداهای LLM در کاتالوگ عمدتاً `language_hint=en` دارند؛ زبان خروجی با `lang_name_code`، متن و مدل تعیین می‌شود. برای فارسی با LLM از `kiki_multilingual` استفاده کنید.

---

## 8) اکشن‌های خواندنی: مدل‌ها، صداها، تشخیص زبان و وضعیت نشست

### 8.1 مدل‌های TTS

```bash
python3 api_client.py models
node api_client.mjs models
```

درخواست خام:

```http
GET /jsapi/tts/tts-model-capabilities
Referer: https://kikivoice.ai/text-to-speech
Cookie: uuid=<anonymous cookie from page visit>
```

### 8.2 مدل‌های Clone

```bash
python3 api_client.py clone-models
node api_client.mjs clone-models
```

درخواست خام:

```http
GET /jsapi/model-capabilities
Referer: https://kikivoice.ai/ai-voice-cloning
Cookie: uuid=<anonymous cookie from page visit>
```

### 8.3 کاتالوگ صداها

```bash
python3 api_client.py voices --fa
python3 api_client.py voices --lang en
node api_client.mjs voices --lang en
```

### 8.4 تشخیص زبان

```bash
python3 api_client.py detect "سلام من پرهام هستم"
node api_client.mjs detect "سلام من پرهام هستم"
```

درخواست خام:

```http
POST /jsapi/detect-language
Content-Type: application/json

{"text": "سلام من پرهام هستم"}
```

نمونه پاسخ زنده:

```json
{
  "error_code": 0,
  "error_summary": "SUCCESS",
  "detected_language": {
    "code": "fa",
    "name": "Persian",
    "local_name": "فارسی",
    "full_name": "Persian (fa) - فارسی"
  },
  "detector_source": "microservice",
  "is_native_supported": false
}
```

### 8.5 وضعیت تأیید انسان

```bash
python3 api_client.py auth-status
```

درخواست خام:

```http
GET /jsapi/auth/check-status
Referer: https://kikivoice.ai/ai-voice-cloning
```

### 8.6 امضای Clone

```bash
python3 api_client.py clone-sig
```

کلاینت خروجی `sig` را redacted چاپ می‌کند. برای عملیات واقعی clone، متدهای داخلی کلاینت sig تازه می‌گیرند و آن را فقط در همان اجرا مصرف می‌کنند.

اگر cookie `uuid` نباشد، پاسخ نمونه داخل `clone_signature_error_without_uuid_cookie.json` است:

```json
{"error_code": -1, "error_summary": "UUID_REQUIRED", "msg": "Failed to generate signature."}
```

---

## 9) ساخت TTS با صدای آماده

### دستور آماده

```bash
python3 api_client.py create "متن شما" \
  --library-type standard \
  --voice-id standard_410001 \
  --voice-code S233 \
  --lang fa \
  --format mp3 \
  --speed 1.0 \
  --volume 100 \
  --pitch 1.0 \
  --out خروجی.mp3
```

کلاینت این کارها را انجام می‌دهد:

1. صفحه TTS را برای cookie باز می‌کند.
2. `POST /jsapi/tts/create-new-tts-task` را با `multipart/form-data` می‌فرستد.
3. اگر `job_id` برگردد، هر 3 ثانیه تا حداکثر حدود 390 ثانیه `status` را Poll می‌کند.
4. وقتی `job_state=1` و `audiourl`/`audio_url` موجود باشد، JSON نهایی را چاپ می‌کند.
5. اگر `--out` داده باشید، فایل صوتی را دانلود می‌کند.

فقط Poll دستی:

```bash
python3 api_client.py status JOB_ID --library-type standard
python3 api_client.py status JOB_ID --library-type llm
```

### Payload کامل `create-new-tts-task`

نوع محتوا: `multipart/form-data`. همه مقادیر در فرانت‌اند به‌صورت فیلد متنی فرم ارسال می‌شوند.

| فیلد | اجباری؟ | پیش‌فرض کلاینت | توضیح |
|---|:---:|---|---|
| `library_type` | بله | `llm` | `llm` یا `standard` |
| `voice_code` | بله | — | از کاتالوگ؛ مثل `S233` |
| `voice_id` | بله | — | از کاتالوگ؛ مثل `standard_410001` |
| `text` | بله | — | متن ورودی؛ سقف به مدل/کتابخانه بستگی دارد |
| `lang_name_code` | بله | `en` | مثل `fa`، `en` |
| `speed` | خیر | `1.0` | فرانت‌اند معمولاً 0.5 تا 2.0 را clamp می‌کند |
| `volume` | خیر | `100` | فرانت‌اند معمولاً 50 تا 300 را clamp می‌کند |
| `pitch` | خیر | `1.0` | مقدار نزدیک 1.0؛ بازه مشاهده‌شده 0.5 تا 2.0 |
| `audio_format` | خیر | `mp3` | `mp3`، `wav`، `ogg`، `aac`، `opus` طبق spec استخراج‌شده |
| `audio_high_quality` | خیر | `0` | `0` یا `1` |
| `model_type` | بله | `kiki_core` | `kiki_core`، `kiki_pro` یا `kiki_multilingual` |
| `model_version_text` | خیر | `default` یا `v2` | برای `kiki_multilingual` مقدار `v2` |
| `emotion` | خیر | `normal` | فقط `kiki_pro` |
| `intensity` | خیر | `normal` | فقط `kiki_pro`: `low`/`normal`/`high` |
| `region` | خیر | خالی | لهجه/منطقه، اگر مدل پشتیبانی کند |
| `voice_gender` | خیر | `0` | فقط `kiki_multilingual`: `0` مرد، `1` زن |
| `uuid_text` | اختیاری فرانت‌اند | ارسال نمی‌شود | در بعضی حالت‌های فرانت‌اند ممکن است ارسال شود؛ کلاینت این بسته آن را نمی‌فرستد |

نمونه پاسخ موفق ساخت تسک می‌تواند شامل `job_id` و اطلاعات سهمیه/زمان باشد. نمونه پاسخ خطای GeeTest در بخش 4 آمده است.

### Poll وضعیت TTS

```http
GET /jsapi/tts/get-tts-task-status?job_id=<JOB_ID>&library_type=standard
```

معنای وضعیت:

| `job_state` | معنی | اقدام |
|---:|---|---|
| `0` | در حال پردازش | چند ثانیه بعد دوباره Poll کنید |
| `1` | موفق | `audiourl` یا `audio_url` را دانلود کنید |
| `-1` یا `2` | ناموفق | `msg`/`error_summary` را بررسی کنید |

---

## 10) Voice Cloning کامل

چرخه کلون در KikiVoice چهار مرحله دارد:

1. گرفتن `sig` و URLهای میکروسرویس از `/jsapi/get-cloning-file-sig`.
2. آپلود فایل صدای مرجع به میکروسرویس `create-voice`.
3. گرفتن `voice_id` از لیست صداهای آپلودشده.
4. ساخت تسک با `/jsapi/create-new-clone-task` و Poll با `/jsapi/get-job-task-status`.

### 10.1 ساختار پاسخ امضا

فایل `clone_signature_response_structure_redacted.json` ساختار واقعی را بدون sig نشان می‌دهد. فیلدهای مهم:

```json
{
  "error_code": 0,
  "error_summary": "",
  "msg": "Signature generated successfully.",
  "sig": "<redacted>",
  "user_id": "<same anonymous uuid>",
  "business_type": "free",
  "max_voice_count": 10,
  "kiki_voice_microservices_api_create_voice_url": "https://custom-voice-upload.kikivoice.ai/create-voice",
  "kiki_voice_microservices_api_voice_list_url": "https://custom-voice-upload.kikivoice.ai/get-voice-list",
  "kiki_voice_microservices_api_delete_voice_url": "https://custom-voice-upload.kikivoice.ai/delete-voice-list",
  "vc_source_access": {
    "upload_url": "https://file-upload.kikivoice.ai/upload",
    "list_url": "https://file-upload.kikivoice.ai/get-file-list",
    "detail_url": "https://file-upload.kikivoice.ai/get-file",
    "preview_base_url": "https://kikivoice-file.com/file/",
    "delete_url": "https://file-upload.kikivoice.ai/delete-file"
  }
}
```

کلاینت Python برای لیست/آپلود/حذف صدای سفارشی از سه URL اصلی `custom-voice-upload` استفاده می‌کند. مجموعه `vc_source_access` در پاسخ امضا دیده می‌شود و مربوط به فایل‌های منبع Voice Changer است؛ در کلاینت این بسته wrap نشده، چون قرارداد کامل آن در تست جداگانه این بسته تأیید نشده است. آن را با sig واقعی در فایل‌ها ذخیره نکنید.

### 10.2 آپلود صدای مرجع

```bash
python3 api_client.py clone-upload ./sample.wav --name "My Voice" --denoise 0
```

درخواست واقعی کلاینت:

```http
POST https://custom-voice-upload.kikivoice.ai/create-voice?voice_name=<NAME>&denoise=0&asr=1&sig=<SIG>
Content-Type: multipart/form-data
Referer: https://kikivoice.ai/ai-voice-cloning

voice-file: <audio file>
```

نکات:

- فیلد فایل دقیقاً `voice-file` است.
- `voice_name` نام نمایشی صدای کلون‌شده است.
- `denoise` سطح حذف نویز انتخابی کاربر/فرانت‌اند است؛ پیش‌فرض کلاینت `0`.
- `asr=1` در فرانت‌اند ثابت ارسال می‌شود.
- در تست‌های این بسته، آپلود واقعی اجرا نشد تا صدای کاربر/داده آزمایشی روی سرویس ساخته نشود؛ مسیر از کد فرانت‌اند استخراج و در کلاینت پیاده شده است.

### 10.3 لیست صداهای کلون‌شده

```bash
python3 api_client.py clone-list
```

درخواست:

```http
GET https://custom-voice-upload.kikivoice.ai/get-voice-list?sig=<SIG>
```

پاسخ میکروسرویس معمولاً envelope متفاوتی دارد: `errcode`، `errmsg` و `voice_list`. از داخل `voice_list` باید `voice_id` صدای مورد نظر را برای `clone-create` بردارید. نام دقیق فیلد شناسه را از خروجی واقعی همان حساب بررسی کنید؛ فرانت‌اند همان آیتم‌های `voice_list` را به‌عنوان صداهای قابل انتخاب مصرف می‌کند.

### 10.4 دانلود/پخش فایل صدای آپلودشده

```bash
python3 api_client.py clone-preview VOICE_ID --out preview.wav
```

درخواست:

```http
GET https://custom-voice-upload.kikivoice.ai/file/<VOICE_ID>?sig=<SIG>
```

کلاینت در صورت HTTP 200 فایل را ذخیره می‌کند؛ در غیر این صورت خطا و ابتدای بدنه پاسخ را گزارش می‌کند.

### 10.5 حذف صدای کلون‌شده

```bash
python3 api_client.py clone-delete VOICE_ID
```

درخواست:

```http
POST https://custom-voice-upload.kikivoice.ai/delete-voice-list?sig=<SIG>
Content-Type: application/json

{"voice_id_list": ["VOICE_ID"]}
```

حذف برگشت‌پذیر نیست. قبل از اجرا مطمئن شوید `VOICE_ID` درست است.

### 10.6 ساخت خروجی با صدای کلون‌شده

```bash
python3 api_client.py clone-create "این متن با صدای کلون‌شده خوانده می‌شود." \
  --voice-id CUSTOM_VOICE_ID \
  --lang fa \
  --model kiki_multilingual \
  --format mp3 \
  --out cloned-fa.mp3
```

کلاینت `POST /jsapi/create-new-clone-task` را با `multipart/form-data` می‌فرستد و سپس با `clone-status` Poll می‌کند.

فیلدهای payload کلون:

| فیلد | توضیح |
|---|---|
| `text` | متن خروجی |
| `clone_source_voice_custom_voice_id` | `voice_id` گرفته‌شده از `clone-list` |
| `clone_source_voice_prompt_text` | متن نمونه/پرامپت صدا، اختیاری؛ فقط وقتی مقدار داشته باشد ارسال می‌شود |
| `clone_source_voice_prompt_text_language` | زبان prompt text، اختیاری |
| `clone_source_voice_gender` | `0` مرد، `1` زن |
| `lang_name_code` | زبان خروجی؛ مثل `fa` |
| `emotion` / `intensity` | برای مدل‌های پشتیبان، مخصوصاً `kiki_pro` |
| `region` | لهجه/منطقه، اختیاری |
| `model_type` | `kiki_core`، `kiki_pro` یا `kiki_multilingual` |
| `model_version_text` | برای multilingual مقدار `v2`؛ در غیر این صورت `default` |
| `speed` | سرعت |
| `volume` | بلندی؛ پیش‌فرض 100 |
| `audio_format` | مثل `mp3` |
| `audio_high_quality` | `0` یا `1` |

Poll دستی کلون:

```bash
python3 api_client.py clone-status JOB_ID
```

```http
GET /jsapi/get-job-task-status?job_id=<JOB_ID>
```

معنای `job_state` مثل TTS است: `0` پردازش، `1` موفق با `audiourl`، `-1` ناموفق.

---

## 11) استفاده مستقیم در کد Python

```python
from api_client import KikiClient

c = KikiClient()
print(c.detect_language("سلام من پرهام هستم"))
print(c.voices("en")["data"]["voice_counts"])

result = c.create_and_wait(
    text="سلام، این یک تست است.",
    voice_id="standard_410001",
    voice_code="S233",
    library_type="standard",
    lang_name_code="fa",
    model_type="kiki_core",
    audio_format="mp3",
)
print(result)

# Clone:
# sig/upload/list/delete/create are available as methods:
# c.clone_upload("sample.wav", "My Voice")
# c.clone_list()
# c.clone_create_and_wait(text="Hello", custom_voice_id="...", lang_name_code="en")
```

اگر چند عملیات را پشت سر هم انجام می‌دهید، از یک نمونه `KikiClient` استفاده کنید تا cookie نشست حفظ شود. ساخت نمونه جدید یعنی نشست/cookie جدید و احتمال بیشتر برای GeeTest.

---

## 12) اجرای `curl_examples.sh`

```bash
bash curl_examples.sh
```

این اسکریپت به‌ترتیب cookie می‌گیرد، مدل‌ها و کاتالوگ را می‌خواند، تشخیص زبان را تست می‌کند و یک نمونه ساخت TTS فارسی را نشان می‌دهد. چون ساخت TTS ممکن است سهمیه مصرف کند یا GeeTest بگیرد، قبل از اجرا متن و صدای داخل اسکریپت را بررسی کنید. بخش Poll در انتهای اسکریپت کامنت است؛ `JOB_ID` واقعی را جایگزین کنید.

---

## 13) استفاده از `openapi.yaml`

`openapi.yaml` قرارداد تقریبی endpointهای `/jsapi` است. می‌توانید آن را در ابزارهای زیر باز کنید:

- Swagger UI / Swagger Editor
- Postman یا Insomnia از مسیر Import
- تولید کلاینت با OpenAPI Generator

محدودیت: endpointهای میکروسرویس clone با URLهای برگشتی از پاسخ امضا کار می‌کنند و `sig` پویاست؛ بنابراین قرارداد کامل آن‌ها در همین README و فایل redacted توضیح داده شده و در OpenAPI به‌صورت مسیر ثابت سایت اصلی نیامده است.

---

## 14) خطاهای مهم و راه‌حل

| خطا/وضعیت | معنی | کار درست |
|---|---|---|
| `error_code=777`, `HUMAN_VERIFICATION_REQUIRED` | GeeTest/تأیید انسان برای نشست یا IP جدید | در مرورگر واقعی سایت را باز و تأیید انسانی را کامل کنید؛ captcha را دور نزنید |
| `UUID_REQUIRED` | cookie `uuid` قبل از درخواست امضا ست نشده | اول صفحه `/ai-voice-cloning` را با همان نشست باز کنید؛ در کلاینت از همان `KikiClient` استفاده کنید |
| `QUOTA_EXCEEDED` / `TTS_QUOTA_EXCEEDED` | سهمیه تمام شده | صبر برای ریست سهمیه یا استفاده از حساب/پلن معتبر سایت |
| `TTS_DAILY_LIMIT_EXCEEDED` / `CLONE_DAILY_LIMIT_EXCEEDED` | سقف روزانه | روز بعد/ریست سهمیه تلاش کنید |
| `MODEL_LANGUAGE_NOT_SUPPORTED` | مدل آن زبان را ندارد | برای فارسی از `kiki_core` استاندارد یا `kiki_multilingual` استفاده کنید، نه `kiki_pro` |
| `TTS_VOICE_NOT_FOUND` | `voice_id`/`voice_code` اشتباه یا منقضی | از `voices` یا `voices_full.json` جفت معتبر را دوباره بگیرید |
| `TOO_MANY_BREAK_TAGS` | تگ‌های مکث بیش از حد | تعداد تگ‌های مکث متن را کم کنید |
| `MODEL_VERSION_DEPRECATED` | نسخه مدل قدیمی | برای multilingual از `v2` استفاده کنید |
| `IP_DISABLED` / `ACCOUNT_DISABLED` | IP/حساب مسدود | از شبکه/حساب مجاز استفاده کنید؛ تلاش برای دور زدن نکنید |
| HTTP `429` | Rate limit | فاصله بین درخواست‌ها را زیاد کنید |
| HTTP `403` HTML در Node | Cloudflare/TLS fingerprint در بعضی محیط‌ها | Python یا curl را استفاده کنید |
| ساخت تسک `job_id` ندارد | معمولاً خطای quota/GeeTest/validation | کل JSON پاسخ و `error_code`/`error_summary`/`msg` را بررسی کنید |
| Poll تمام می‌شود ولی audio نیست | timeout کلاینت یا خطای تسک | با `status`/`clone-status` و همان `job_id` دوباره بررسی کنید؛ `job_state` را ببینید |

---

## 15) وضعیت تست زنده این بسته

موارد زیر در زمان استخراج با درخواست واقعی بررسی شدند:

- `models` و `clone-models`: موفق.
- کاتالوگ صداها: موفق؛ 910 صدا در زمان استخراج.
- `voices --fa`: موفق.
- `detect` برای متن فارسی: موفق و `fa` برگشت.
- `auth-status`: موفق؛ نشست ناشناس `authenticated:false` بود.
- گرفتن sig کلون پس از ساخت cookie صفحه: از نظر ساختار موفق؛ مقدار sig در فایل‌ها redacted است.
- ساخت TTS از IP سندباکس: با `777 HUMAN_VERIFICATION_REQUIRED` متوقف شد؛ بنابراین فایل صوتی Kiki در آن تست ساخته نشد.
- آپلود/حذف/ساخت clone به‌صورت زنده اجرا نشد تا داده یا صدای آزمایشی روی سرویس ایجاد/حذف نشود؛ payload آن‌ها از فرانت‌اند استخراج و در Python پیاده شده است.

---

## 16) نکات امنیتی و حقوقی

- `sig`، cookie `uuid` و URLهای امضاشده فایل‌ها را منتشر نکنید و داخل git عمومی نگذارید.
- فایل صوتی افراد را فقط با رضایت و حق قانونی کلون کنید.
- این API داخلی محصول رسمی توسعه‌دهنده نیست؛ برای محصول production روی پایداری آن حساب نکنید.
- درخواست‌های ساخت TTS/Clone ممکن است سهمیه مصرف کنند؛ برای تست از متن کوتاه استفاده کنید.
- حذف صدای کلون‌شده برگشت‌پذیر نیست.

---

## 17) مسیر پیشنهادی برای هر هدف

| هدف | دستور پیشنهادی |
|---|---|
| فقط تست سریع فارسی | `python3 api_client.py create "سلام" --library-type standard --voice-id standard_410001 --voice-code S233 --lang fa --out fa.mp3` |
| دیدن صداهای فارسی | `python3 api_client.py voices --fa` |
| انتخاب مدل مناسب | `python3 api_client.py models` و فایل `tts_model_capabilities.json` |
| کلون صدا | `clone-upload` ← `clone-list` ← `clone-create` |
| حذف صدای کلون | اول `clone-list` برای تأیید ID، بعد `clone-delete VOICE_ID` |
| دیباگ خطای امضا | `python3 api_client.py auth-status` و `python3 api_client.py clone-sig` |
| استفاده در کد | import کردن `KikiClient` از `api_client.py` |
