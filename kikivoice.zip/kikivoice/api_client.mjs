#!/usr/bin/env node
/**
 * KikiVoice internal web API client (frontend endpoints, not a public API).
 * Requires Node.js 18+ (global fetch/FormData).
 */
const BASE = 'https://kikivoice.ai';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';

let cookieHeader = '';

function storeCookies(resp) {
  const values = typeof resp.headers.getSetCookie === 'function' ? resp.headers.getSetCookie() : [];
  const pairs = values.map((v) => v.split(';')[0]).filter(Boolean);
  if (pairs.length) cookieHeader = pairs.join('; ');
}

async function req(path, options = {}, referer = '/text-to-speech') {
  const url = path.startsWith('http') ? path : BASE + path;
  const headers = { 'User-Agent': UA, Accept: 'application/json', Referer: BASE + referer, ...(options.headers || {}) };
  if (cookieHeader) headers.Cookie = cookieHeader;
  const resp = await fetch(url, { ...options, headers, redirect: 'follow' });
  storeCookies(resp);
  return resp;
}

async function json(path, options = {}, referer) {
  const resp = await req(path, options, referer);
  const text = await resp.text();
  try { return { _http_status: resp.status, ...JSON.parse(text) }; }
  catch { return { _http_status: resp.status, raw: text.slice(0, 500) }; }
}

async function warm(page = '/text-to-speech') {
  await req(page, { headers: { Accept: 'text/html' } }, page);
}

async function ttsModels() { await warm('/text-to-speech'); return json('/jsapi/tts/tts-model-capabilities'); }
async function cloneModels() { await warm('/ai-voice-cloning'); return json('/jsapi/model-capabilities', {}, '/ai-voice-cloning'); }
async function voices(lang = 'en') { await warm('/text-to-speech'); return json(`/jsapi/tts/get-all-tts-voice-data?lang_str=${encodeURIComponent(lang)}`); }
async function detect(text) {
  await warm('/text-to-speech');
  return json('/jsapi/detect-language', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) });
}

async function createTtsTask(o) {
  await warm('/text-to-speech');
  const modelType = o.modelType || 'kiki_core';
  const fd = new FormData();
  const fields = {
    library_type: o.libraryType || 'llm',
    voice_code: o.voiceCode,
    voice_id: o.voiceId,
    text: o.text,
    lang_name_code: o.lang || 'en',
    speed: o.speed ?? 1.0,
    volume: o.volume ?? 100,
    pitch: o.pitch ?? 1.0,
    audio_format: o.format || 'mp3',
    audio_high_quality: o.highQuality ?? 0,
    model_type: modelType,
    model_version_text: o.modelVersion || (modelType === 'kiki_multilingual' ? 'v2' : 'default'),
    emotion: modelType === 'kiki_pro' ? (o.emotion || 'normal') : 'normal',
    intensity: modelType === 'kiki_pro' ? (o.intensity || 'normal') : 'normal',
    region: o.region || '',
    voice_gender: modelType === 'kiki_multilingual' ? (o.voiceGender ?? 0) : 0,
  };
  for (const [k, v] of Object.entries(fields)) fd.append(k, String(v));
  return json('/jsapi/tts/create-new-tts-task', { method: 'POST', body: fd });
}

async function status(jobId, libraryType = 'llm') {
  return json(`/jsapi/tts/get-tts-task-status?job_id=${encodeURIComponent(jobId)}&library_type=${encodeURIComponent(libraryType)}`);
}

async function createAndWait(o) {
  const created = await createTtsTask(o);
  const jobId = created.job_id || created.data?.job_id;
  if (!jobId) return created;
  const started = Date.now();
  let last = created;
  while (Date.now() - started < 390_000) {
    await new Promise((r) => setTimeout(r, 3000));
    last = await status(jobId, o.libraryType || 'llm');
    const state = Number(last.job_state ?? last.state ?? 0);
    const audio = last.audiourl || last.audio_url;
    if ((state === 1 && audio) || state === 1 || state === 2 || state === -1) return last;
  }
  return last;
}

function arg(name, fallback) {
  const i = process.argv.indexOf(name);
  return i >= 0 ? process.argv[i + 1] : fallback;
}
function has(name) { return process.argv.includes(name); }

const cmd = process.argv[2];
try {
  if (cmd === 'models') console.log(JSON.stringify(await ttsModels(), null, 2));
  else if (cmd === 'clone-models') console.log(JSON.stringify(await cloneModels(), null, 2));
  else if (cmd === 'voices') {
    const data = await voices(arg('--lang', 'en'));
    if (has('--fa')) {
      const out = [];
      for (const lib of Object.values(data.data?.libraries || {})) {
        for (const v of lib.voices || []) if (String(v.language_hint || '').toLowerCase().startsWith('fa')) out.push(v);
      }
      console.log(JSON.stringify(out, null, 2));
    } else console.log(JSON.stringify(data, null, 2));
  } else if (cmd === 'detect') console.log(JSON.stringify(await detect(process.argv[3] || ''), null, 2));
  else if (cmd === 'create') {
    const result = await createAndWait({
      text: process.argv[3] || '',
      voiceId: arg('--voice-id'), voiceCode: arg('--voice-code'),
      libraryType: arg('--library-type', 'llm'), lang: arg('--lang', 'en'),
      modelType: arg('--model'), format: arg('--format', 'mp3'),
      speed: Number(arg('--speed', '1')), volume: Number(arg('--volume', '100')), pitch: Number(arg('--pitch', '1')),
      emotion: arg('--emotion', 'normal'), intensity: arg('--intensity', 'normal'), region: arg('--region', ''),
      voiceGender: Number(arg('--voice-gender', '0')),
    });
    console.log(JSON.stringify(result, null, 2));
    const audio = result.audiourl || result.audio_url;
    const out = arg('--out');
    if (audio && out) {
      const resp = await req(audio);
      const buf = Buffer.from(await resp.arrayBuffer());
      await import('node:fs').then((fs) => fs.writeFileSync(out, buf));
      console.error(`saved ${out} (${buf.length} bytes)`);
    }
    if (!audio && result.error_code !== 0 && result.error_code !== '0' && result.error_code != null) process.exitCode = 2;
  } else {
    console.error('Usage: node api_client.mjs models|clone-models|voices [--fa]|detect "text"|create "text" --voice-id ID --voice-code CODE [--out file.mp3]');
    process.exitCode = 1;
  }
} catch (e) {
  console.error(e);
  process.exitCode = 1;
}
