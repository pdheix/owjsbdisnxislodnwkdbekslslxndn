#!/usr/bin/env bash
# KikiVoice internal web endpoints (not a documented public API).
# Run from any directory. Generation may return error_code 777 (GeeTest) for a
# first-time/IP-verification flow; complete verification in a real browser.
set -euo pipefail
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'
JAR="${TMPDIR:-/tmp}/kiki_cookies.txt"

# 1) Visit a page once: server sets the anonymous uuid cookie.
curl -s -A "$UA" -c "$JAR" -b "$JAR" https://kikivoice.ai/text-to-speech -o /dev/null

# 2) TTS model capabilities (credit rates, limits, languages, emotions)
curl -s -A "$UA" -b "$JAR" -e 'https://kikivoice.ai/text-to-speech' \
  'https://kikivoice.ai/jsapi/tts/tts-model-capabilities' | python3 -m json.tool | head -120

# 3) Clone model capabilities
curl -s -A "$UA" -b "$JAR" -e 'https://kikivoice.ai/ai-voice-cloning' \
  'https://kikivoice.ai/jsapi/model-capabilities' | python3 -m json.tool | head -80

# 4) Voice catalog (910 voices at extraction time; ?lang_str localizes labels)
curl -s -A "$UA" -b "$JAR" -e 'https://kikivoice.ai/text-to-speech' \
  'https://kikivoice.ai/jsapi/tts/get-all-tts-voice-data?lang_str=en' \
  -o /tmp/kiki_voices.json
python3 - << 'PY'
import json
d=json.load(open('/tmp/kiki_voices.json'))
print(d['data']['voice_counts'])
for lib in d['data']['libraries'].values():
    for v in lib['voices']:
        if str(v.get('language_hint','')).lower().startswith('fa'):
            print(v['library_type'], v['voice_code'], v['voice_id'], v['display_name'])
PY

# 5) Language detection
curl -s -A "$UA" -b "$JAR" -e 'https://kikivoice.ai/text-to-speech' \
  -H 'Content-Type: application/json' \
  -d '{"text":"سلام من پرهام هستم"}' \
  'https://kikivoice.ai/jsapi/detect-language'

echo
# 6) Create a Persian standard-voice TTS task (may return 777 GeeTest)
curl -s -A "$UA" -b "$JAR" -c "$JAR" -e 'https://kikivoice.ai/text-to-speech' \
  -F 'library_type=standard' \
  -F 'voice_code=S233' \
  -F 'voice_id=standard_410001' \
  -F 'text=سلام، این یک تست کوتاه است.' \
  -F 'lang_name_code=fa' \
  -F 'speed=1.0' -F 'volume=100' -F 'pitch=1.0' \
  -F 'audio_format=mp3' -F 'audio_high_quality=0' \
  -F 'model_type=kiki_core' -F 'model_version_text=default' \
  -F 'emotion=normal' -F 'intensity=normal' -F 'region=' -F 'voice_gender=0' \
  'https://kikivoice.ai/jsapi/tts/create-new-tts-task'

echo
# 7) Poll a task (replace JOB_ID):
# curl -s -A "$UA" -b "$JAR" -e 'https://kikivoice.ai/text-to-speech' \
#   'https://kikivoice.ai/jsapi/tts/get-tts-task-status?job_id=JOB_ID&library_type=standard'
