#!/usr/bin/env node
/**
 * YourVoic client: official /api/v1 API (X-API-Key) + free web /api/generate.
 * Requires Node.js 18+.
 */
import fs from 'node:fs';

const BASE = 'https://yourvoic.com';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36';

function arg(name, fallback) {
  const i = process.argv.indexOf(name);
  return i >= 0 ? process.argv[i + 1] : fallback;
}
function has(name) { return process.argv.includes(name); }

function key() {
  const k = (process.env.YOURVOIC_API_KEY || '').trim();
  if (!k) throw new Error('Set YOURVOIC_API_KEY first (official API only).');
  return k;
}

async function officialGenerate(text) {
  const payload = {
    text,
    voice: arg('--voice', 'Rowshan'),
    language: arg('--language', 'fa'),
    model: arg('--model', 'aura-prime'),
    format: arg('--format', 'mp3'),
  };
  if (has('--speed')) payload.speed = Number(arg('--speed'));
  if (has('--pitch')) payload.pitch = Number(arg('--pitch'));
  if (has('--mode')) payload.mode = arg('--mode');
  const resp = await fetch(BASE + '/api/v1/tts/generate', {
    method: 'POST',
    headers: { 'User-Agent': UA, 'X-API-Key': key(), 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  console.error(`HTTP ${resp.status} ${resp.headers.get('content-type')}`);
  if (!resp.ok) { console.log(await resp.text()); process.exitCode = 2; return; }
  const buf = Buffer.from(await resp.arrayBuffer());
  const out = arg('--out', 'yourvoic.mp3');
  fs.writeFileSync(out, buf);
  console.log(`saved ${out} (${buf.length} bytes)`);
}

async function officialGet(path) {
  const resp = await fetch(BASE + path, { headers: { 'User-Agent': UA, 'X-API-Key': key() } });
  console.error(`HTTP ${resp.status}`);
  const text = await resp.text();
  try { console.log(JSON.stringify(JSON.parse(text), null, 2)); } catch { console.log(text); }
  if (!resp.ok) process.exitCode = 2;
}

async function webGenerate(text) {
  const prefix = has('--no-prefix') ? '' : 'This speaker speaks with a Persian accent.: ';
  const resp = await fetch(BASE + '/api/generate', {
    method: 'POST',
    headers: { 'User-Agent': UA, 'Content-Type': 'application/json', Referer: BASE + '/tools/persian-text-to-speech' },
    body: JSON.stringify({
      text: prefix + text,
      voice: arg('--voice', 'Zephyr'),
      language: arg('--language', 'fa'),
      device_fingerprint: arg('--device-fingerprint', 'fp_local_client'),
    }),
  });
  console.error(`HTTP ${resp.status}`);
  const data = await resp.json().catch(async () => ({ raw: await resp.text() }));
  console.log(JSON.stringify(data, null, 2));
  const out = arg('--out');
  if (out && data.audio_url) {
    const audio = await fetch(data.audio_url, { headers: { 'User-Agent': UA } });
    const buf = Buffer.from(await audio.arrayBuffer());
    fs.writeFileSync(out, buf);
    console.error(`saved ${out} (${buf.length} bytes)`);
  }
  if (!data.success) process.exitCode = 2;
}

const cmd = process.argv[2];
try {
  if (cmd === 'official-generate') await officialGenerate(process.argv[3] || '');
  else if (cmd === 'official-voices') await officialGet(`/api/v1/voices?model=${encodeURIComponent(arg('--model', 'aura-prime'))}&language=${encodeURIComponent(arg('--language', 'fa'))}`);
  else if (cmd === 'official-models') await officialGet('/api/v1/models');
  else if (cmd === 'official-languages') await officialGet(`/api/v1/languages?model=${encodeURIComponent(arg('--model', 'aura-prime'))}`);
  else if (cmd === 'official-usage') await officialGet('/api/v1/usage');
  else if (cmd === 'web-generate') await webGenerate(process.argv[3] || '');
  else {
    console.error('Usage: node api_client.mjs official-generate "text" [--out file.mp3] | official-voices | official-models | official-languages | official-usage | web-generate "سلام" [--out file.mp3]');
    process.exitCode = 1;
  }
} catch (e) {
  console.error(e.message || e);
  process.exitCode = 1;
}
