#!/usr/bin/env python3
"""
YourVoic API client.

Two surfaces are implemented:
1) Official developer API: https://yourvoic.com/api/v1/... with X-API-Key.
2) Free web tool endpoint used by https://yourvoic.com/tools/... pages:
   POST https://yourvoic.com/api/generate (no API key; 3 free trials, max 150
   chars in the frontend; returns JSON with a signed audio_url).

No third-party packages are required.
"""
from __future__ import annotations

import argparse
import json
import mimetypes
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

BASE = "https://yourvoic.com"
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
)


def request(
    url: str,
    *,
    method: str = "GET",
    json_body: dict | None = None,
    data: bytes | None = None,
    headers: dict[str, str] | None = None,
    timeout: int = 120,
) -> tuple[int, str, bytes]:
    h = {"User-Agent": UA, "Accept": "*/*"}
    if json_body is not None:
        data = json.dumps(json_body, ensure_ascii=False).encode("utf-8")
        h["Content-Type"] = "application/json"
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.headers.get_content_type(), resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.headers.get_content_type() if e.headers else "", e.read()


def api_key() -> str:
    key = os.getenv("YOURVOIC_API_KEY", "").strip()
    if not key:
        raise SystemExit("Set YOURVOIC_API_KEY first (official API only).")
    return key


def official_headers() -> dict[str, str]:
    # The server also documents api_key query param and Authorization: Bearer,
    # but X-API-Key is the documented/recommended header.
    return {"X-API-Key": api_key()}


def official_generate(
    *,
    text: str,
    voice: str = "Rowshan",
    language: str = "fa",
    model: str = "aura-prime",
    speed: float | None = None,
    pitch: float | None = None,
    audio_format: str | None = "mp3",
    mode: str | None = None,
    out: str | None = None,
) -> int:
    payload: dict[str, object] = {
        "text": text,
        "voice": voice,
        "language": language,
        "model": model,
    }
    if speed is not None:
        payload["speed"] = speed
    if pitch is not None:
        payload["pitch"] = pitch
    if audio_format:
        payload["format"] = audio_format
    if mode:
        payload["mode"] = mode
    status, ctype, body = request(
        BASE + "/api/v1/tts/generate",
        method="POST",
        json_body=payload,
        headers=official_headers(),
    )
    print(f"HTTP {status} Content-Type={ctype} bytes={len(body)}", file=sys.stderr)
    if status == 200 and not ctype.endswith("json"):
        if out:
            Path(out).write_bytes(body)
            print(f"saved {out}")
        else:
            sys.stdout.buffer.write(body)
        return 0
    print(body.decode("utf-8", "replace"))
    return 2


def official_get(path: str) -> int:
    status, _ctype, body = request(BASE + path, headers=official_headers())
    print(f"HTTP {status}", file=sys.stderr)
    try:
        print(json.dumps(json.loads(body), ensure_ascii=False, indent=2))
    except Exception:
        print(body.decode("utf-8", "replace"))
    return 0 if status == 200 else 2


def official_stream(
    *,
    text: str,
    voice: str = "Peter",
    language: str = "en-US",
    model: str = "aura-prime",
    sample_rate: int = 24000,
    out: str = "yourvoic.pcm",
) -> int:
    """POST /api/v1/tts/stream. Saves the raw chunked PCM stream to a file.

    Convert to WAV with: ffmpeg -f s16le -ar 24000 -ac 1 -i yourvoic.pcm out.wav
    """
    status, ctype, body = request(
        BASE + "/api/v1/tts/stream",
        method="POST",
        json_body={
            "text": text,
            "voice": voice,
            "language": language,
            "model": model,
            "sample_rate": sample_rate,
        },
        headers=official_headers(),
        timeout=300,
    )
    print(f"HTTP {status} Content-Type={ctype} bytes={len(body)}", file=sys.stderr)
    if status != 200:
        print(body.decode("utf-8", "replace"))
        return 2
    Path(out).write_bytes(body)
    print(f"saved raw PCM to {out}")
    return 0


def _multipart_file(
    file_field: str,
    filename: str,
    file_bytes: bytes,
    content_type: str,
    fields: dict[str, object] | None = None,
) -> tuple[bytes, str]:
    boundary = "----yourvoic-" + uuid.uuid4().hex
    out = []
    for name, value in (fields or {}).items():
        if value is None:
            continue
        out.append(f"--{boundary}\r\n".encode())
        out.append(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
        out.append(str(value).encode("utf-8"))
        out.append(b"\r\n")
    out.append(f"--{boundary}\r\n".encode())
    safe_name = filename.replace('"', "")
    out.append(
        f'Content-Disposition: form-data; name="{file_field}"; filename="{safe_name}"\r\n'.encode()
    )
    out.append(f"Content-Type: {content_type}\r\n\r\n".encode())
    out.append(file_bytes)
    out.append(b"\r\n")
    out.append(f"--{boundary}--\r\n".encode())
    return b"".join(out), f"multipart/form-data; boundary={boundary}"


def official_stt(
    file_path: str,
    *,
    model: str = "cipher-fast",
    endpoint: str = "/api/v1/stt/transcribe",
    extra: dict[str, object] | None = None,
) -> int:
    """POST a speech-to-text endpoint with multipart field `file`.

    Extra documented STT options (language, diarization, timestamps, etc.)
    can be passed as form fields with --field key=value.
    """
    p = Path(file_path)
    ctype = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
    fields: dict[str, object] = {"model": model}
    if extra:
        fields.update(extra)
    body, content_type = _multipart_file("file", p.name, p.read_bytes(), ctype, fields)
    headers = official_headers()
    headers["Content-Type"] = content_type
    status, _ctype, resp = request(
        BASE + endpoint, method="POST", data=body, headers=headers, timeout=600
    )
    print(f"HTTP {status}", file=sys.stderr)
    try:
        print(json.dumps(json.loads(resp), ensure_ascii=False, indent=2))
    except Exception:
        print(resp.decode("utf-8", "replace"))
    return 0 if status == 200 else 2


def web_generate(
    *,
    text: str,
    voice: str = "Zephyr",
    language: str = "fa",
    device_fingerprint: str = "fp_local_client",
    accent_instruction: str | None = "This speaker speaks with a Persian accent.",
    out: str | None = None,
) -> int:
    """Call the free web-tool endpoint exactly like the Persian tool page.

    The frontend prefixes the user's text with an accent/style instruction:
    "{instruction}: {text}". For fa the shared instruction is
    "This speaker speaks with a Persian accent.".
    Set --no-prefix to send the raw text only.
    """
    sent_text = f"{accent_instruction}: {text}" if accent_instruction else text
    status, _ctype, body = request(
        BASE + "/api/generate",
        method="POST",
        json_body={
            "text": sent_text,
            "voice": voice,
            "language": language,
            "device_fingerprint": device_fingerprint,
        },
        headers={"Referer": BASE + "/tools/persian-text-to-speech"},
    )
    print(f"HTTP {status}", file=sys.stderr)
    try:
        data = json.loads(body)
    except Exception:
        print(body.decode("utf-8", "replace"))
        return 2
    print(json.dumps(data, ensure_ascii=False, indent=2))
    if out and data.get("audio_url"):
        astatus, actype, audio = request(data["audio_url"])
        Path(out).write_bytes(audio)
        print(f"saved {out} ({len(audio)} bytes, HTTP {astatus}, {actype})", file=sys.stderr)
    return 0 if data.get("success") else 2


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="YourVoic API client")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("official-generate", help="POST /api/v1/tts/generate (needs API key)")
    p.add_argument("text")
    p.add_argument("--voice", default="Rowshan")
    p.add_argument("--language", default="fa")
    p.add_argument("--model", default="aura-prime")
    p.add_argument("--speed", type=float)
    p.add_argument("--pitch", type=float)
    p.add_argument("--format", default="mp3", dest="audio_format")
    p.add_argument("--mode")
    p.add_argument("--out", default="yourvoic.mp3")

    p = sub.add_parser("official-voices", help="GET /api/v1/voices (needs API key)")
    p.add_argument("--model", default="aura-prime")
    p.add_argument("--language", default="fa")

    p = sub.add_parser("official-models", help="GET /api/v1/models (needs API key)")
    p = sub.add_parser("official-languages", help="GET /api/v1/languages (needs API key)")
    p.add_argument("--model", default="aura-prime")
    sub.add_parser("official-usage", help="GET /api/v1/usage (needs API key)")

    p = sub.add_parser("official-stream", help="POST /api/v1/tts/stream (needs API key)")
    p.add_argument("text")
    p.add_argument("--voice", default="Peter")
    p.add_argument("--language", default="en-US")
    p.add_argument("--model", default="aura-prime")
    p.add_argument("--sample-rate", type=int, default=24000)
    p.add_argument("--out", default="yourvoic.pcm")

    p = sub.add_parser("official-stt", help="POST STT transcribe endpoint (needs API key)")
    p.add_argument("file")
    p.add_argument("--model", default="cipher-fast")
    p.add_argument(
        "--endpoint",
        default="/api/v1/stt/transcribe",
        help="e.g. /api/v1/stt/transcribe, /api/v1/stt/transcribe-url, /api/v1/stt/translations",
    )
    p.add_argument(
        "--field",
        action="append",
        default=[],
        help="Extra multipart field, repeatable: --field language=fa",
    )

    p = sub.add_parser("web-generate", help="POST /api/generate (free web tool, no key)")
    p.add_argument("text")
    p.add_argument("--voice", default="Zephyr", help="Underlying voice id, e.g. Zephyr (Rowshan)")
    p.add_argument("--language", default="fa")
    p.add_argument("--device-fingerprint", default="fp_local_client")
    p.add_argument("--no-prefix", action="store_true")
    p.add_argument("--out")

    args = ap.parse_args(argv)
    if args.cmd == "official-generate":
        return official_generate(
            text=args.text,
            voice=args.voice,
            language=args.language,
            model=args.model,
            speed=args.speed,
            pitch=args.pitch,
            audio_format=args.audio_format,
            mode=args.mode,
            out=args.out,
        )
    if args.cmd == "official-voices":
        q = urllib.parse.urlencode({"model": args.model, "language": args.language})
        return official_get(f"/api/v1/voices?{q}")
    if args.cmd == "official-models":
        return official_get("/api/v1/models")
    if args.cmd == "official-languages":
        q = urllib.parse.urlencode({"model": args.model})
        return official_get(f"/api/v1/languages?{q}")
    if args.cmd == "official-usage":
        return official_get("/api/v1/usage")
    if args.cmd == "official-stream":
        return official_stream(
            text=args.text,
            voice=args.voice,
            language=args.language,
            model=args.model,
            sample_rate=args.sample_rate,
            out=args.out,
        )
    if args.cmd == "official-stt":
        extra: dict[str, object] = {}
        for item in args.field:
            if "=" not in item:
                raise SystemExit(f"--field must be key=value, got: {item}")
            k, v = item.split("=", 1)
            extra[k] = v
        return official_stt(args.file, model=args.model, endpoint=args.endpoint, extra=extra)
    if args.cmd == "web-generate":
        return web_generate(
            text=args.text,
            voice=args.voice,
            language=args.language,
            device_fingerprint=args.device_fingerprint,
            accent_instruction=None if args.no_prefix else "This speaker speaks with a Persian accent.",
            out=args.out,
        )
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
