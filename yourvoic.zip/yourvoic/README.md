# YourVoic API Package — راهنمای کامل استفاده

این بسته دو مسیر جدا برای استفاده از **YourVoic** (`https://yourvoic.com`) را پوشش می‌دهد:

1. **API رسمی توسعه‌دهنده** زیر `https://yourvoic.com/api/v1` با هدر `X-API-Key`؛ مناسب استفاده پایدار و production.
2. **ابزار رایگان وب** در صفحاتی مثل `https://yourvoic.com/tools/persian-text-to-speech` که بدون API Key از `POST /api/generate` استفاده می‌کند؛ مناسب تست سریع، اما محدود به 150 کاراکتر در فرانت‌اند و 3 تلاش رایگان.

> این دو مسیر را با هم قاطی نکنید: در API رسمی فارسی، نام صدا `Rowshan` است؛ در ابزار وب، شناسه زیرین همان صدا `Zephyr` ارسال می‌شود. سقف، احراز هویت و قالب پاسخ هم متفاوت است.

تاریخ استخراج و آخرین بررسی فایل‌ها: **2026-10-29**.

---

## 1) اکشن‌های پوشش‌داده‌شده

| # | اکشن | Endpoint | نیاز به API Key | Python | Node | curl |
|---:|---|---|:---:|:---:|:---:|:---:|
| 1 | تولید TTS رسمی و ذخیره فایل صوتی | `POST /api/v1/tts/generate` | ✅ | ✅ `official-generate` | ✅ `official-generate` | ✅ |
| 2 | تولید TTS رسمی به‌صورت Stream و ذخیره PCM خام | `POST /api/v1/tts/stream` | ✅ | ✅ `official-stream` | ❌ | نمونه کامنت‌شده |
| 3 | لیست صداهای رسمی برای مدل/زبان | `GET /api/v1/voices` | ✅ | ✅ `official-voices` | ✅ `official-voices` | ✅ |
| 4 | لیست مدل‌های رسمی | `GET /api/v1/models` | ✅ | ✅ `official-models` | ✅ `official-models` | ✅ |
| 5 | لیست زبان‌های رسمی برای مدل | `GET /api/v1/languages` | ✅ | ✅ `official-languages` | ✅ `official-languages` | ✅ |
| 6 | مشاهده مصرف و سهمیه | `GET /api/v1/usage` | ✅ | ✅ `official-usage` | ✅ `official-usage` | ✅ |
| 7 | تبدیل گفتار به متن از فایل | `POST /api/v1/stt/transcribe` یا endpoint انتخابی STT | ✅ | ✅ `official-stt` | ❌ | نمونه در README |
| 8 | تولید رایگان از ابزار وب فارسی/ابزارها | `POST /api/generate` | ❌ | ✅ `web-generate` | ✅ `web-generate` | ✅ |
| 9 | اطلاعات STT بلادرنگ | `GET /api/v1/stt/realtime/info` | ✅ طبق مستندات | دستی با curl | دستی | قالب در README |
| 10 | STT بلادرنگ WebSocket | `wss://yourvoic.com:8443/api/v1/stt/realtime/stream?api_key=...` | ✅ طبق مستندات | wrap نشده | wrap نشده | نیازمند WebSocket client |

کلاینت Python کامل‌ترین فایل بسته است و Stream/STT را هم دارد. کلاینت Node برای TTS رسمی، discovery (`voices/models/languages/usage`) و ابزار رایگان وب مناسب است.

مواردی مثل ساخت حساب، خرید پلن، ساخت API Key از داشبورد، login و مدیریت billing داخل API این بسته نیستند و باید از وب‌سایت YourVoic انجام شوند.

---

## 2) فایل‌های داخل ZIP و کاربرد هرکدام

| فایل | کاربرد | چطور استفاده می‌شود؟ |
|---|---|---|
| `README.md` | راهنمای مستقل همین بسته | مرجع قراردادها، payload/response، خطاها، مدل‌ها و همه دستورها |
| `api_client.py` | کلاینت کامل Python با کتابخانه استاندارد | اجرای هر دو مسیر رسمی و رایگان، شامل Stream و STT |
| `api_client.mjs` | کلاینت Node برای مسیرهای اصلی | TTS رسمی، voices/models/languages/usage و `web-generate` |
| `curl_examples.sh` | نمونه‌های خام curl | اجرای مستقیم نمونه رایگان و رسمی؛ Stream در انتها به‌صورت کامنت آموزشی است |
| `openapi.yaml` | مشخصات OpenAPI 3 از روی مستندات رسمی + تست زنده | Import در Postman/Swagger/Insomnia یا تولید کلاینت |
| `models.json` | خلاصه مدل‌ها، هزینه‌ها و ناسازگاری‌های مستندات | انتخاب مدل، مخصوصاً تشخیص اینکه فارسی فقط با Aura است |
| `persian_voices_webtool.json` | 30 صدای Aura با نام فارسی و شناسه زیرین | انتخاب صدا برای ابزار وب (`Zephyr`) و نگاشت آن به نام رسمی (`Rowshan`) |
| `web_generate_sample_redacted.json` | نمونه پاسخ زنده ابزار وب، بدون امضای کامل URL | فهم ساختار `success/audio_url/trialsRemaining` بدون افشای لینک موقت |

هیچ فایل بسته شامل API Key واقعی یا URL امضاشده کامل نیست.

---

## 3) پیش‌نیاز و گرفتن API Key

### برای ابزار رایگان وب

هیچ کلیدی لازم نیست:

```bash
unzip yourvoic.zip
cd yourvoic
python3 api_client.py web-generate "سلام، این یک تست کوتاه است." --out fa-web.mp3
```

### برای API رسمی

1. در سایت YourVoic ثبت‌نام/ورود کنید.
2. از بخش API/داشبورد توسعه‌دهنده یک API Key بسازید. طبق مستندات، کلیدها با پیشوندهایی مثل `yv_test_...` و `yv_live_...` دیده می‌شوند.
3. کلید را فقط در متغیر محیطی بگذارید:

```bash
export YOURVOIC_API_KEY="yv_live_xxxxxxxxxxxxx"
```

PowerShell:

```powershell
$env:YOURVOIC_API_KEY="yv_live_xxxxxxxxxxxxx"
```

کلید را داخل کد، README، git یا فایل‌های خروجی ذخیره نکنید. کلاینت‌های این بسته اگر `YOURVOIC_API_KEY` خالی باشد، قبل از ارسال درخواست رسمی متوقف می‌شوند.

پیش‌نیاز اجرا:

- Python 3.10+ برای `api_client.py`؛ پکیج خارجی لازم نیست.
- Node.js 18+ برای `api_client.mjs`.
- `ffmpeg` فقط برای تبدیل خروجی PCM استریم به WAV/MP3 لازم است.

---

## 4) احراز هویت API رسمی

هدر پیشنهادی و مورد استفاده کلاینت‌ها:

```http
X-API-Key: yv_live_xxxxxxxxxxxxx
Content-Type: application/json
```

مستندات/پاسخ سرور روش‌های دیگری مثل query parameter به نام `api_key` و `Authorization: Bearer ...` را هم ذکر می‌کنند، اما این بسته برای سازگاری و امنیت از `X-API-Key` استفاده می‌کند. کلید را در URL لاگ نکنید.

بدون کلید، پاسخ زنده سرور در تست ما:

```json
{
  "success": false,
  "error": {
    "code": "AUTH_MISSING_API_KEY",
    "message": "API key is required",
    "category": "auth",
    "resolution": "Include your API key in the request..."
  },
  "request_id": "...",
  "timestamp": 1793269646.159
}
```

کدهای مستندات ممکن است در بعضی مثال‌ها نام‌های نزدیک دیگری مثل `MISSING_API_KEY` داشته باشند؛ کد زنده مشاهده‌شده در این بررسی `AUTH_MISSING_API_KEY` بود.

---

## 5) شروع سریع

### 5.1 فارسی رایگان، بدون کلید

```bash
python3 api_client.py web-generate "سلام، این یک تست کوتاه است." --out fa-web.mp3
node api_client.mjs web-generate "سلام، این یک تست کوتاه است." --out fa-web.mp3
```

خروجی موفق JSON چاپ می‌شود و اگر `--out` داده باشید MP3 دانلود می‌شود.

### 5.2 فارسی رسمی با API Key

```bash
export YOURVOIC_API_KEY="yv_live_xxxxxxxxxxxxx"

python3 api_client.py official-voices
python3 api_client.py official-generate "سلام، این یک تست کوتاه است." \
  --voice Rowshan --language fa --model aura-prime --format mp3 \
  --out fa-official.mp3
```

معادل Node:

```bash
node api_client.mjs official-voices
node api_client.mjs official-generate "سلام، این یک تست کوتاه است." \
  --voice Rowshan --language fa --model aura-prime --format mp3 \
  --out fa-official.mp3
```

---

## 6) API رسمی — تولید TTS معمولی

### Endpoint

```http
POST https://yourvoic.com/api/v1/tts/generate
X-API-Key: <YOURVOIC_API_KEY>
Content-Type: application/json
```

### بدنه درخواست

نمونه فارسی:

```json
{
  "text": "سلام، این یک تست کوتاه است.",
  "voice": "Rowshan",
  "language": "fa",
  "model": "aura-prime",
  "format": "mp3"
}
```

| فیلد | اجباری؟ | پیش‌فرض مستند/کلاینت | توضیح |
|---|:---:|---|---|
| `text` | بله | — | متن؛ سقف استاندارد طبق مستندات 5000 کاراکتر است و `mode:"bulk"` می‌تواند طبق پلن بالاتر باشد |
| `voice` | عملاً بله | `Peter` در مستندات؛ کلاینت این بسته `Rowshan` | نام صدا؛ در Aura بر اساس زبان localize می‌شود. برای فارسی: `Rowshan` |
| `language` | خیر | `en-US` | مثل `fa`، `fa-IR`، `en-US` |
| `model` | خیر | `aura-prime` | `aura-lite`، `aura-prime`، `aura-max`، `rapid-flash`، `rapid-max` |
| `speed` | خیر | `1.0` | بازه مستند اصلی 0.5 تا 2.0؛ پشتیبانی به مدل/حالت بستگی دارد |
| `pitch` | خیر | `1.0` | مستندات ناسازگارند: یک جا 0.5 تا 2.0 و جای دیگر -20 تا +20. فقط وقتی نیاز دارید ارسال کنید |
| `format` | خیر | `mp3` | در مستندات اصلی `mp3/wav`؛ بعضی صفحات `output_format` و `ogg/flac/aac` هم ذکر می‌کنند. کلاینت این بسته `format` می‌فرستد |
| `mode` | خیر | `standard` | `standard` یا `bulk` طبق مستندات/پلن |

### پاسخ موفق

پاسخ موفق **JSON نیست**؛ بدنه همان فایل صوتی باینری است. `Content-Type` می‌تواند مثلاً `audio/mpeg` یا `audio/wav` باشد. طبق مستندات، هدرهای مفید ممکن است شامل این‌ها باشند:

- `X-Credits-Used`
- `X-Credits-Remaining`
- `X-Duration-Ms`
- `X-Request-ID`
- گاهی `Content-Disposition: attachment; filename=tts_<id>.wav`

کلاینت Python/Node در حالت موفق فایل را در `--out` ذخیره می‌کند. اگر `--out` در Python ندهید، مقدار پیش‌فرض `yourvoic.mp3` است.

### دستورها

```bash
python3 api_client.py official-generate "سلام دنیا" \
  --voice Rowshan --language fa --model aura-prime --format mp3 --out hello-fa.mp3

# فقط وقتی مدل/صدا از speed/pitch پشتیبانی می‌کند:
python3 api_client.py official-generate "Hello world" \
  --voice Peter --language en-US --model aura-prime \
  --speed 1.1 --pitch 1.0 --out hello-en.mp3
```

### curl معادل

```bash
curl -s -X POST 'https://yourvoic.com/api/v1/tts/generate' \
  -H "X-API-Key: $YOURVOIC_API_KEY" \
  -H 'Content-Type: application/json' \
  -d '{"text":"سلام، این یک تست کوتاه است.","voice":"Rowshan","language":"fa","model":"aura-prime","format":"mp3"}' \
  --output yourvoic_fa.mp3
file yourvoic_fa.mp3
```

---

## 7) API رسمی — Streaming TTS

### Endpoint مورد استفاده این بسته

```http
POST https://yourvoic.com/api/v1/tts/stream
X-API-Key: <YOURVOIC_API_KEY>
Content-Type: application/json
```

بدنه:

```json
{
  "text": "Streaming audio content.",
  "voice": "Peter",
  "language": "en-US",
  "model": "aura-prime",
  "sample_rate": 24000
}
```

خروجی موفق طبق مستندات، **PCM خام chunked** است: 16-bit، mono، با `sample_rate` درخواستی/برگشتی. آن را مستقیم با پخش‌کننده معمولی باز نکنید؛ اول به WAV تبدیل کنید:

```bash
python3 api_client.py official-stream "Streaming audio content." \
  --voice Peter --language en-US --model aura-prime \
  --sample-rate 24000 --out yourvoic.pcm

ffmpeg -f s16le -ar 24000 -ac 1 -i yourvoic.pcm yourvoic.wav
```

نکته ناسازگاری مستندات: در بعضی مثال‌های پاسخ، مسیر `/api/v1/tts/generate/stream` هم دیده می‌شود، اما صفحات endpoints/streaming مسیر `/api/v1/tts/stream` را می‌دهند. این بسته `/api/v1/tts/stream` را استفاده می‌کند. همچنین درباره پشتیبانی streaming برای `rapid-flash` بین صفحات اختلاف هست؛ آن را بدون تست با کلید خودتان قطعی فرض نکنید.

---

## 8) API رسمی — Discovery و Usage

همه این endpointها `X-API-Key` می‌خواهند.

### صداها

```bash
python3 api_client.py official-voices
python3 api_client.py official-voices --model aura-prime --language fa
node api_client.mjs official-voices --model aura-prime --language fa
```

```http
GET /api/v1/voices?model=aura-prime&language=fa
```

طبق spec، پاسخ شامل فهرست `voices` و `total` است. همیشه `model` را بدهید؛ نام صداها به مدل و زبان وابسته است. فیلتر `gender` (`male`/`female`) نیز در spec دیده می‌شود، اما CLI این بسته فقط `model` و `language` را expose می‌کند؛ برای فیلتر جنسیت از curl/openapi استفاده کنید:

```bash
curl -s -H "X-API-Key: $YOURVOIC_API_KEY" \
  'https://yourvoic.com/api/v1/voices?model=aura-prime&language=fa&gender=female' | python3 -m json.tool
```

### مدل‌ها

```bash
python3 api_client.py official-models
node api_client.mjs official-models
```

```http
GET /api/v1/models
```

### زبان‌ها

```bash
python3 api_client.py official-languages
python3 api_client.py official-languages --model aura-prime
node api_client.mjs official-languages --model aura-prime
```

```http
GET /api/v1/languages?model=aura-prime
```

مسیر درست `/api/v1/languages` است. بعضی صفحات مستندات اشتباهاً `/api/api/v1/languages` نوشته‌اند که در تست زنده 404 بود.

### مصرف و سهمیه

```bash
python3 api_client.py official-usage
node api_client.mjs official-usage
```

```http
GET /api/v1/usage
```

طبق spec، پاسخ اطلاعاتی مثل usage و `rate_limits` دارد؛ ساختار دقیق را با کلید خودتان بررسی کنید. مسیر `/api/v1/user/credits` در بعضی صفحات آمده، اما در تست زنده 404 (`{"detail":"Not Found"}`) برگرداند؛ این بسته از `/api/v1/usage` استفاده می‌کند.

---

## 9) API رسمی — Speech-to-Text

کلاینت Python برای آپلود فایل صوتی و گرفتن متن:

```bash
export YOURVOIC_API_KEY="yv_live_xxxxxxxxxxxxx"
python3 api_client.py official-stt ./audio.mp3 --model cipher-fast
```

درخواست:

```http
POST https://yourvoic.com/api/v1/stt/transcribe
X-API-Key: <YOURVOIC_API_KEY>
Content-Type: multipart/form-data

file=<audio file>
model=cipher-fast
```

curl معادل نمونه مستندات:

```bash
curl -X POST "https://yourvoic.com/api/v1/stt/transcribe" \
  -H "X-API-Key: $YOURVOIC_API_KEY" \
  -F "file=@audio.mp3" \
  -F "model=cipher-fast"
```

اگر endpoint یا گزینه خاصی در مستندات حساب/نسخه API شما وجود دارد، با `--endpoint` و `--field` استفاده کنید:

```bash
python3 api_client.py official-stt ./audio.wav \
  --model cipher-fast \
  --field language=fa
```

قواعد `--field`:

- هر بار یک فیلد `key=value` اضافه می‌کند و قابل تکرار است.
- نام فیلدها را فقط از مستندات همان endpoint بردارید؛ گزینه‌هایی مثل زبان، diarization و timestamps در مستندات STT مطرح شده‌اند، اما نام/اثر دقیقشان می‌تواند به endpoint و مدل وابسته باشد.
- `--endpoint` را فقط با مسیرهایی استفاده کنید که در مستندات رسمی حساب شما آمده‌اند. مقدار پیش‌فرض این بسته `/api/v1/stt/transcribe` است.

پاسخ موفق JSON transcription است؛ ساختار دقیق فیلدها را از پاسخ واقعی حساب خودتان و مستندات STT بررسی کنید، چون این بسته بدون API Key کاربر نتوانست پاسخ موفق STT را live ضبط کند.

### STT بلادرنگ

مستندات این موارد را ذکر می‌کنند:

```http
GET https://yourvoic.com/api/v1/stt/realtime/info
X-API-Key: <YOURVOIC_API_KEY>
```

```text
wss://yourvoic.com:8443/api/v1/stt/realtime/stream?api_key=<YOURVOIC_API_KEY>
```

کلاینت‌های این بسته WebSocket را wrap نکرده‌اند؛ برای آن به WebSocket client و قرارداد پیام‌های همان نسخه مستندات نیاز دارید. API Key را در URL WebSocket فقط روی اتصال امن و بدون لاگ‌کردن URL استفاده کنید.

---

## 10) ابزار رایگان وب — `POST /api/generate`

این همان endpoint داخلی صفحه‌های tools است؛ API رسمی توسعه‌دهنده نیست.

### درخواست دقیق صفحه فارسی

```http
POST https://yourvoic.com/api/generate
Content-Type: application/json
Referer: https://yourvoic.com/tools/persian-text-to-speech

{
  "text": "This speaker speaks with a Persian accent.: سلام، این یک تست کوتاه است.",
  "voice": "Zephyr",
  "language": "fa",
  "device_fingerprint": "fp_local_client"
}
```

فیلدها:

| فیلد | توضیح |
|---|---|
| `text` | متن نهایی ارسالی؛ فرانت‌اند قبل از متن کاربر یک دستور لهجه/سبک می‌گذارد: `This speaker speaks with a Persian accent.: ` |
| `voice` | شناسه زیرین صدا، نه نام نمایشی؛ برای Rowshan فارسی مقدار `Zephyr` است |
| `language` | برای صفحه فارسی `fa` |
| `device_fingerprint` | شناسه دستگاه/مرورگر برای سهمیه تلاش رایگان. فرانت‌اند آن را با هش FNV-1a از مشخصات مرورگر و پیشوند `fp_` می‌سازد؛ کلاینت این بسته مقدار ساده `fp_local_client` می‌فرستد مگر override کنید |

### دستورها

```bash
# رفتار پیش‌فرض دقیقاً مثل صفحه فارسی است (prefix لهجه اضافه می‌شود)
python3 api_client.py web-generate "سلام، این یک تست کوتاه است." --out fa-web.mp3

# بدون prefix؛ فقط متن خام ارسال می‌شود
python3 api_client.py web-generate "سلام، این یک تست کوتاه است." --no-prefix --out fa-web-raw.mp3

# انتخاب صدای زیرین دیگر و fingerprint دستی
python3 api_client.py web-generate "سلام" \
  --voice Puck --language fa --device-fingerprint fp_my_test --out fa-web.mp3
```

Node:

```bash
node api_client.mjs web-generate "سلام، این یک تست کوتاه است." --out fa-web.mp3
node api_client.mjs web-generate "سلام" --no-prefix --out fa-web.mp3
```

### پاسخ موفق

```json
{
  "success": true,
  "audio_url": "https://s3.eu-central-2.idrivee2.com/yourvoic-audio/static/audio/plans/Free/anonymous/audio_<id>_<ts>_<rand>.mp3?<signed query>",
  "trialsRemaining": 2
}
```

`audio_url` امضاشده و موقت است؛ آن را منتشر نکنید و انتظار نداشته باشید دائمی بماند. نمونه redacted در `web_generate_sample_redacted.json` هست.

### محدودیت‌ها و خطاهای ابزار وب

- سقف فرانت‌اند: **150 کاراکتر** برای متن کاربر.
- سهمیه مشاهده‌شده: **3 free trials**؛ پاسخ موفق `trialsRemaining` را برمی‌گرداند.
- وقتی سهمیه تمام شود، پاسخ می‌تواند HTTP 429 یا بدنه‌ای شامل `hasReachedLimit: true` و `error` باشد.
- `GET /api/generate` مجاز نیست و پاسخ `{"error":"Method not allowed"}` با HTTP 405 مشاهده شد.
- این مسیر برای production پایدار طراحی نشده؛ برای محصول از API رسمی استفاده کنید.

در تست زنده این بسته، یک متن کوتاه فارسی با `voice=Zephyr` و `language=fa` موفق بود: HTTP 200، `success:true`، `trialsRemaining:2` و MP3 واقعی 80,291 بایتی دانلود شد.

---

## 11) مدل‌ها و انتخاب برای فارسی

جزئیات و تناقض‌های مستندات در `models.json` خلاصه شده است.

| مدل | خانواده | زبان/صدا طبق مستندات | Expression | فارسی | هزینه طبق مستندات |
|---|---|---|:---:|:---:|---|
| `aura-lite` | Aura | 90+ زبان، صداهای Aura | ✅ | ✅ | 1 اعتبار/کاراکتر |
| `aura-prime` | Aura | 90+ زبان، صداهای Aura | ✅ | ✅ پیشنهاد اصلی | 1 اعتبار/کاراکتر |
| `aura-max` | Aura | 90+ زبان، کیفیت premium | ✅ | ✅ | صفحات مختلف 1 یا 2 اعتبار/کاراکتر می‌گویند |
| `rapid-flash` | Rapid | 18 زبان، 62 صدای Flash ثابت | ❌ | ❌ | 1 اعتبار/کاراکتر |
| `rapid-max` | Rapid | 41 زبان، زیرمجموعه Aura | ❌ | ❌ | صفحات مختلف 1 یا 2 اعتبار/کاراکتر می‌گویند |

برای فارسی از خانواده **Aura** استفاده کنید؛ انتخاب متعادل این بسته `aura-prime` است. مدل‌های Rapid را برای فارسی انتخاب نکنید.

### Expression و Break

طبق مستندات، Expression فقط برای Aura است. نمونه‌های ذکرشده:

```text
<laugh>
<chuckle>
<sigh>
<gasp>
<yawn>
<cough>
<whisper>...</whisper>
<emphasis>...</emphasis>
<break time="1s"/>
<break time="500ms"/>
```

مکث `<break>` طبق مستندات می‌تواند تا 20 ثانیه باشد و در Streaming پشتیبانی نمی‌شود. قبل از استفاده production، آن را با همان مدل/صدای حساب خودتان تست کنید.

---

## 12) صداها: نام رسمی در برابر شناسه وب

دو مجموعه صدا قابل جایگزینی نیستند:

- **Aura:** 30 صدای زیرین؛ نامشان بر اساس زبان عوض می‌شود. شناسه زیرین `Zephyr` در فارسی نام **Rowshan** دارد.
- **Flash:** 62 صدا با نام ثابت انگلیسی برای `rapid-flash` و زبان‌های محدود؛ فارسی ندارد.

قاعده طلایی:

| مسیر | مقدار `voice` برای همان صدای فارسی |
|---|---|
| API رسمی `official-generate` | `Rowshan` |
| ابزار وب `web-generate` | `Zephyr` |

نمونه‌های فایل `persian_voices_webtool.json`:

| شناسه زیرین وب | نام فارسی رسمی | جنسیت |
|---|---|---|
| `Zephyr` | `Rowshan` | زن |
| `Puck` | `Peyman` | مرد |
| `Kore` | `Katayoun` | زن |
| `Fenrir` | `Farhad` | مرد |
| `Charon` | `Kaveh` | مرد |

دیدن فایل نگاشت:

```bash
python3 -m json.tool persian_voices_webtool.json | head -120
```

---

## 13) قالب خطاهای رسمی

خطاهای رسمی JSON هستند و معمولاً ساختاری شبیه این دارند:

```json
{
  "success": false,
  "error": {
    "code": "INVALID_VOICE",
    "message": "...",
    "category": "validation",
    "resolution": "...",
    "details": {}
  },
  "request_id": "..."
}
```

کدهای مهم مستند/مشاهده‌شده:

| کد | معنی/اقدام |
|---|---|
| `AUTH_MISSING_API_KEY` / `MISSING_API_KEY` | کلید ارسال نشده؛ `YOURVOIC_API_KEY` را تنظیم کنید |
| `INVALID_API_KEY` | کلید اشتباه/منقضی؛ کلید داشبورد را بررسی کنید |
| `MISSING_TEXT` | `text` خالی یا غایب است |
| `TEXT_TOO_LONG` | متن از سقف مدل/حالت بزرگ‌تر است |
| `INVALID_VOICE` | نام صدا برای آن مدل/زبان اشتباه است؛ official و web را قاطی نکنید |
| `INVALID_LANGUAGE` / `LANGUAGE_NOT_SUPPORTED` | زبان برای مدل پشتیبانی نمی‌شود؛ برای فارسی Aura بگیرید |
| `INVALID_MODEL` / `MODEL_ACCESS_DENIED` | مدل اشتباه یا خارج از پلن |
| `INVALID_SPEED` / `INVALID_PITCH` / `INVALID_FORMAT` | پارامتر صوتی نامعتبر؛ مخصوصاً به ناسازگاری مستندات pitch/format دقت کنید |
| `INSUFFICIENT_CREDITS` | اعتبار کافی نیست؛ usage/داشبورد را بررسی کنید |
| `RATE_LIMIT_EXCEEDED` | نرخ درخواست بالاست؛ فاصله و backoff بگذارید |
| `CONCURRENT_LIMIT` | درخواست هم‌زمان بیش از حد پلن |
| `EXPRESSION_NOT_SUPPORTED` | Expression برای مدل/حالت مجاز نیست؛ Aura و non-streaming را تست کنید |

برای خطاهای 429 و خطاهای موقت شبکه/سرور، retry محدود با فاصله افزایشی بگذارید و برای هر retry همان `request_id` خطا را لاگ کنید. درخواست ساخت TTS را بدون کنترل اعتبار، بی‌نهایت retry نکنید.

---

## 14) استفاده در کد Python

```python
import os
# قبل از اجرا: export YOURVOIC_API_KEY="yv_live_..."
from api_client import official_generate, web_generate

# رسمی؛ فایل باینری ذخیره می‌شود
official_generate(
    text="سلام، این یک تست کوتاه است.",
    voice="Rowshan",
    language="fa",
    model="aura-prime",
    audio_format="mp3",
    out="fa-official.mp3",
)

# رایگان وب؛ JSON چاپ و در صورت وجود audio_url فایل ذخیره می‌شود
web_generate(
    text="سلام، این یک تست کوتاه است.",
    voice="Zephyr",
    language="fa",
    out="fa-web.mp3",
)
```

توابع `official_get`، `official_stream` و `official_stt` هم در همان فایل قابل import هستند. برای جزئیات امضای توابع، docstringهای `api_client.py` را ببینید.

---

## 15) اجرای `curl_examples.sh`

```bash
export YOURVOIC_API_KEY="yv_live_xxxxxxxxxxxxx"
bash curl_examples.sh
```

ترتیب اسکریپت:

1. نمونه رایگان وب فارسی را بدون کلید اجرا می‌کند.
2. چون بخش رسمی کلید می‌خواهد، اگر `YOURVOIC_API_KEY` ست نباشد متوقف می‌شود.
3. TTS رسمی فارسی را در `yourvoic_fa.mp3` ذخیره می‌کند.
4. voices/models/languages/usage را چاپ می‌کند.
5. نمونه Stream در انتها کامنت است؛ برای اجرا آن بخش را از کامنت خارج کنید و خروجی PCM را با ffmpeg تبدیل کنید.

---

## 16) استفاده از `openapi.yaml` و فایل‌های داده

- `openapi.yaml`: برای Import در Postman/Swagger/Insomnia. Security scheme آن `X-API-Key` است. مسیر رایگان `/api/generate` با `security: []` مشخص شده تا با API رسمی قاطی نشود.
- `models.json`: برای انتخاب مدل و دیدن اختلاف هزینه/قابلیت بین صفحات مستندات.
- `persian_voices_webtool.json`: برای نگاشت نام فارسی رسمی به شناسه زیرین ابزار وب.
- `web_generate_sample_redacted.json`: برای فهم پاسخ موفق ابزار وب؛ لینک کامل عمداً حذف شده است.

بازکردن سریع داده‌ها:

```bash
python3 -m json.tool models.json
python3 -m json.tool persian_voices_webtool.json | head -80
python3 -m json.tool web_generate_sample_redacted.json
```

---

## 17) ناسازگاری‌ها و یافته‌های زنده مهم

این موارد را هنگام توسعه در نظر بگیرید:

- مسیر درست زبان‌ها `/api/v1/languages` است؛ `/api/api/v1/languages` در تست زنده 404 بود.
- `/api/v1/user/credits` در تست زنده 404 بود؛ این بسته `/api/v1/usage` را استفاده می‌کند.
- `GET https://yourvoic.com/health` در تست، صفحه 404 سایت را برگرداند؛ روی آن حساب نکنید.
- مسیر Stream در صفحات اصلی `/api/v1/tts/stream` است، ولی بعضی مثال‌ها `/api/v1/tts/generate/stream` می‌نویسند.
- فیلد فرمت در صفحات اصلی `format` است؛ بعضی صفحات `output_format` و فرمت‌های بیشتری می‌گویند.
- پیش‌فرض فرمت و بازه `pitch` بین صفحات یکدست نیست.
- هزینه `aura-max` و `rapid-max` بین صفحات اختلاف دارد.
- تعداد زبان‌ها در صفحات مختلف 50، 90+، 41 یا 18 ذکر شده و به مدل وابسته است.

برای تصمیم مالی/فنی production، داشبورد حساب و پاسخ واقعی با کلید خودتان مرجع نهایی است.

---

## 18) قیمت و پلن طبق مستندات — با احتیاط

صفحه Get API Key در زمان بررسی این موارد را ذکر می‌کرد:

| پلن | کاراکتر/ماه | نرخ درخواست | قیمت ذکرشده |
|---|---:|---:|---:|
| Free | 50,000 | 20 req/min | $0 |
| Basic | 500,000 | 60 req/min | $29/mo |
| Pro | 2,000,000 | 120 req/min | $99/mo |
| Enterprise | سفارشی | سفارشی | تماس |

همچنین صفحه API از اعتبار ثبت‌نام 2500 اعتبار API + 1000 اعتبار وب صحبت می‌کرد. این اعداد بین صفحات کاملاً یکدست نیستند؛ قبل از خرید، داشبورد فعلی حساب را بررسی کنید.

---

## 19) عیب‌یابی سریع

| مشکل | علت محتمل | راه‌حل |
|---|---|---|
| `Set YOURVOIC_API_KEY first` | متغیر محیطی ست نشده | `export YOURVOIC_API_KEY="yv_live_..."` |
| `AUTH_MISSING_API_KEY` | هدر کلید به سرور نرسیده | از کلاینت همین بسته یا هدر `X-API-Key` استفاده کنید |
| فایل خروجی پخش نمی‌شود | پاسخ خطای JSON را به اسم mp3 ذخیره کرده‌اید یا خروجی PCM است | اول HTTP status و `file output` را بررسی کنید؛ PCM را با ffmpeg تبدیل کنید |
| `INVALID_VOICE` برای Rowshan در web | نام رسمی را در ابزار وب فرستاده‌اید | در web مقدار `Zephyr` و در official مقدار `Rowshan` بفرستید |
| فارسی با Rapid خطا می‌دهد | Rapid فارسی ندارد | `aura-prime` + `Rowshan` |
| `official-languages` 404 در ابزار دیگر | مسیر دوگانه `/api/api/v1` استفاده شده | مسیر درست `/api/v1/languages` است |
| سهمیه وب تمام شد | 3 تلاش رایگان مصرف شده | از API رسمی استفاده کنید یا طبق قوانین سایت وارد حساب شوید |
| Stream خروجی WAV نیست | خروجی PCM خام است | `ffmpeg -f s16le -ar 24000 -ac 1 -i in.pcm out.wav` |

---

## 20) وضعیت تست زنده

- ابزار وب فارسی: زنده و موفق؛ MP3 واقعی ساخته و دانلود شد.
- API رسمی بدون کلید: زنده تست شد و `401 AUTH_MISSING_API_KEY` برگشت.
- مسیرهای رسمی با کلید کاربر در این بسته تست نشدند، چون API Key کاربر در اختیار بسته نبود؛ payload آن‌ها از مستندات رسمی و spec استخراج شده است.
- STT و Stream از مستندات رسمی در کلاینت پیاده شده‌اند، اما پاسخ موفقشان بدون کلید قابل ضبط نبود.

---

## 21) مسیر پیشنهادی برای هر هدف

| هدف | انتخاب |
|---|---|
| تست فوری فارسی بدون ثبت‌نام | `python3 api_client.py web-generate "سلام" --out fa.mp3` |
| استفاده پایدار در محصول | API رسمی + `aura-prime` + `Rowshan` |
| کم‌تأخیر/streaming | `official-stream` و تبدیل PCM با ffmpeg |
| تبدیل فایل صوتی به متن | `official-stt audio.mp3 --model cipher-fast` |
| دیدن سهمیه | `official-usage` |
| انتخاب صدای فارسی | `persian_voices_webtool.json` برای web و `official-voices --language fa` برای رسمی |
