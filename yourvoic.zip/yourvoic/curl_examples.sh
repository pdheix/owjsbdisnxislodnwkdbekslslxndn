#!/usr/bin/env bash
# YourVoic: official API (API key) + free web-tool endpoint (no key).
set -euo pipefail
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'

# ---------- Free web tool used by the Persian page (no API key) ----------
# Frontend rules: max 150 chars, 3 free trials, voice is the underlying id
# (Zephyr = Rowshan in Persian), language=fa, and the text is prefixed with
# "This speaker speaks with a Persian accent.: ".
curl -s -A "$UA" -e 'https://yourvoic.com/tools/persian-text-to-speech' \
  -H 'Content-Type: application/json' \
  -d '{"text":"This speaker speaks with a Persian accent.: سلام، این یک تست کوتاه است.","voice":"Zephyr","language":"fa","device_fingerprint":"fp_local_client"}' \
  'https://yourvoic.com/api/generate' | python3 -m json.tool

# ---------- Official developer API (needs YOURVOIC_API_KEY) ----------
: "${YOURVOIC_API_KEY:?Set YOURVOIC_API_KEY first}"

# Generate Persian speech (binary audio in the response body)
curl -s -X POST 'https://yourvoic.com/api/v1/tts/generate' \
  -H "X-API-Key: $YOURVOIC_API_KEY" \
  -H 'Content-Type: application/json' \
  -d '{"text":"سلام، این یک تست کوتاه است.","voice":"Rowshan","language":"fa","model":"aura-prime","format":"mp3"}' \
  --output yourvoic_fa.mp3
file yourvoic_fa.mp3

# Voices for a model + language (Aura names are localized; fa name for Zephyr is Rowshan)
curl -s -H "X-API-Key: $YOURVOIC_API_KEY" \
  'https://yourvoic.com/api/v1/voices?model=aura-prime&language=fa' | python3 -m json.tool | head -120

# Models / languages / usage
curl -s -H "X-API-Key: $YOURVOIC_API_KEY" 'https://yourvoic.com/api/v1/models'
curl -s -H "X-API-Key: $YOURVOIC_API_KEY" 'https://yourvoic.com/api/v1/languages?model=aura-prime'
curl -s -H "X-API-Key: $YOURVOIC_API_KEY" 'https://yourvoic.com/api/v1/usage'

# Streaming (raw PCM 16-bit mono; sample_rate default 24000)
# curl -s -X POST 'https://yourvoic.com/api/v1/tts/stream' \
#   -H "X-API-Key: $YOURVOIC_API_KEY" -H 'Content-Type: application/json' \
#   -d '{"text":"Streaming audio content.","voice":"Peter","language":"en-US","model":"aura-prime","sample_rate":24000}' \
#   --output audio.pcm
# ffmpeg -f s16le -ar 24000 -ac 1 -i audio.pcm audio.wav
