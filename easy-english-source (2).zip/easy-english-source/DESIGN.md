# Easy English — Design Specification

## Direction & Layout

**Product**: Persian-language marketing page for "ایزی اینگلیش" (Easy English), a practice platform — not a language school. Visitors learn how the product actually works: sign up, write a short English sample, receive an *estimated* CEFR level, then continue through short video lessons, gap-fill listening practice, reviews and mistake-fix retries, timed quizzes, and browser-based speaking practice.

**Mood**: Warm, optimistic, tactile — cream paper, amber markers, ink-navy type, chunky hard-edged cards. It must feel like a friendly study workbook with clear rules, because the product's promise is clarity ("level is an estimate", "each quiz is one attempt").

**First visual signal**: Cream canvas, stitched amber glow, and an interactive 3D stack of floating word cards (`HELLO`, `SPEAK`, `TRAVEL`, `EASY`, `TALK`) that tilts toward the cursor.

**Composition**: 12-column grid, max width `1200px`, gutter `24px`. Hero is asymmetric: 55% copy / 45% 3D canvas. Section bands alternate cream → cream-deep → navy (the navy band carries scoring facts and limitations, so rules read as authoritative). Section padding `96px` desktop / `64px` mobile. Card gaps `20–24px`, radius `28px`, 2px ink borders, `6px 6px 0` hard shadows.

**Breakpoints**: Mobile `<640` single column, canvas 320–380px tall, nav in a sheet; tablet `640–1023` two-column grids; desktop `≥1024` asymmetric hero and wide two-column method grid.

**Do**: state the estimate disclaimer near the hero and in the CTA; show concrete numbers (10, 5, 20, 5 points; 1/3/7-day reviews; 80 characters); English sentence samples in Latin type inside an RTL flow.
**Don't**: pricing tables, testimonials, "find your dream job" copy, or any claim of official CEFR certification. No purple gradients, glassmorphism, or soft neumorphic shadows.

## Tokens

### Colors
- `--paper` `#FBF3E4` (page, 60%), `--paper-deep` `#F3E7D2` (alternating band, inset panels)
- `--ink` `#12233A` (headings, borders, primary text), `--ink-soft` `#3D4E66` (body)
- `--amber` `#F7C443` (primary CTA, marker highlight), `--amber-deep` `#E9A81C`
- `--mint` `#1FA97A` (correct answers, success), `--coral` `#E85C43` (wrong answers, warnings)
- `--sky` `#4C8DF6` (quiz method accent), `--surface` `#FFFDF8` (cards), `--night` `#0E1A2B` (rules band, footer)

### Typography
- Display: **Lalezar** — headlines `clamp(2.4rem, 5.4vw, 4.5rem)` hero, `clamp(1.9rem, 3.6vw, 3rem)` sections, line-height 1.28.
- Body: **Vazirmatn** 400/500/700 — `17px/1.95` paragraphs, `15px/1.9` card body, `13.5px/1.85` bullets.
- Latin accent: **Luckiest Guy** — wordmark, badges, English sample sentences, eyebrow micro-labels (`letter-spacing: 0.2em`).

### Spacing & shapes
Scale 4/8/12/16/24/32/48/64/96. Buttons `999px` pills, cards `28px`, chips `14px`, quiz options `16px`, image `24px`. Icon tiles `48–56px` square with `16px` radius.

### Elevation & depth
No blur shadows. Depth from 2px ink borders, hard offset shadows, layered canvas, and a sticky nav with `rgba(251,243,228,.92)` + backdrop blur.

## Shared Patterns & States

- **Pill button**: amber, 2px ink border, `0 5px 0` ink shadow; hover lifts `-2px`; active compresses to `0 2px 0`. Secondary is transparent with ink border; on navy bands use amber primary + cream outline with `!bg-transparent`.
- **Method card**: ink-bordered surface card, tonal icon tile, point tag pill, bullet list separated by a dashed rule.
- **Quiz option**: ink-20 border default; selected → amber tint; correct → mint border/tint with check icon; wrong → coral border/tint with × icon. Disabled checking until all questions answered; results panel reveals explanation per question, plus a reset action.
- **FAQ accordion**: native `button` with `aria-expanded`/`aria-controls`, plus icon rotates 135°, panel content in a right-border amber quote style.
- **Motion**: 600ms reveal on first intersection (content visible without JS), 300ms card lift, canvas drift paused offscreen, full `prefers-reduced-motion` fallback.
- **Accessibility**: 44px tap targets, ink-on-cream contrast ≥ 7:1, dashed 3px-offset focus ring, labelled quiz options (`aria-pressed`), decorative canvas `aria-hidden` with Persian description, `dir="ltr"` only on English sentence samples.

## Media

Imagery supports comprehension, not decoration; no stock people or fake testimonial portraits.

| Asset | Purpose | Source | Style | Placement |
|---|---|---|---|---|
| Interactive 3D word-card scene | Hero focal point | three.js, native WebGL | Chunky rounded cards, amber/mint/cream, soft studio light | Square canvas, right column desktop; full width on mobile |
| CSS card fallback | Guarantees hero never looks empty before WebGL's first frame or without it | Hand-built CSS/SVG | Same card language, slight rotations | Overlays canvas region |

No photography is required: the product is a practice interface, so the visual proof is the working sample quiz and the explicit scoring table. Paper texture, marker strokes and dashed rules are hand-built SVG/CSS, never raster gradients.
