import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface CardSpec {
  word: string;
  tag: string;
  background: string;
  foreground: string;
  border: string;
  position: [number, number, number];
  rotation: [number, number, number];
  size: [number, number];
  depth: number;
  drift: number;
  phase: number;
}

const CARDS: CardSpec[] = [
  {
    word: 'HELLO',
    tag: 'A1',
    background: '#F7C443',
    foreground: '#12233A',
    border: '#12233A',
    position: [-1.55, 0.95, 0.7],
    rotation: [-0.06, -0.34, 0.1],
    size: [2.5, 1.55],
    depth: 0.18,
    drift: 1.1,
    phase: 0,
  },
  {
    word: 'SPEAK',
    tag: 'B1',
    background: '#1FA97A',
    foreground: '#FFFDF8',
    border: '#12233A',
    position: [1.6, 1.35, 0.15],
    rotation: [0.05, 0.42, -0.09],
    size: [2.3, 1.4],
    depth: 0.16,
    drift: 0.8,
    phase: 1.6,
  },
  {
    word: 'TRAVEL',
    tag: 'A2',
    background: '#FFFDF8',
    foreground: '#12233A',
    border: '#12233A',
    position: [1.75, -1.05, 0.95],
    rotation: [-0.04, 0.36, 0.12],
    size: [2.4, 1.35],
    depth: 0.2,
    drift: 1.3,
    phase: 3.1,
  },
  {
    word: 'EASY',
    tag: 'ENGLISH',
    background: '#12233A',
    foreground: '#F7C443',
    border: '#12233A',
    position: [-1.35, -1.35, 0.35],
    rotation: [0.04, -0.4, -0.13],
    size: [2.15, 1.3],
    depth: 0.14,
    drift: 0.95,
    phase: 4.4,
  },
  {
    word: 'TALK',
    tag: 'C1',
    background: '#4C8DF6',
    foreground: '#FFFDF8',
    border: '#12233A',
    position: [-0.15, 0.05, -1.5],
    rotation: [0.02, -0.16, 0.03],
    size: [1.7, 1.05],
    depth: 0.12,
    drift: 0.7,
    phase: 2.2,
  },
];

const createCardTexture = (spec: CardSpec) => {
  const width = 640;
  const height = Math.round((640 * spec.size[1]) / spec.size[0]);
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');

  if (!ctx) return null;

  const radius = 46;
  ctx.clearRect(0, 0, width, height);

  ctx.fillStyle = spec.background;
  ctx.beginPath();
  ctx.moveTo(radius, 0);
  ctx.lineTo(width - radius, 0);
  ctx.quadraticCurveTo(width, 0, width, radius);
  ctx.lineTo(width, height - radius);
  ctx.quadraticCurveTo(width, height, width - radius, height);
  ctx.lineTo(radius, height);
  ctx.quadraticCurveTo(0, height, 0, height - radius);
  ctx.lineTo(0, radius);
  ctx.quadraticCurveTo(0, 0, radius, 0);
  ctx.closePath();
  ctx.fill();

  ctx.lineWidth = 9;
  ctx.strokeStyle = spec.border;
  ctx.stroke();

  ctx.fillStyle = spec.foreground;
  ctx.font = `700 ${Math.round(height * 0.3)}px "Luckiest Guy", "Vazirmatn", system-ui, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.letterSpacing = '2px';
  ctx.fillText(spec.word, width / 2, height * 0.46);

  const tagFont = Math.round(height * 0.105);
  ctx.font = `700 ${tagFont}px "Vazirmatn", system-ui, sans-serif`;
  const tagWidth = ctx.measureText(spec.tag).width + tagFont * 1.6;
  const tagHeight = tagFont * 1.75;
  ctx.strokeStyle = spec.border;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.roundRect(width / 2 - tagWidth / 2, height * 0.68, tagWidth, tagHeight, tagHeight / 2);
  ctx.stroke();
  ctx.fillText(spec.tag, width / 2, height * 0.68 + tagHeight / 2 + 1);

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  texture.needsUpdate = true;
  return texture;
};

const roundedCardGeometry = (width: number, height: number, depth: number) => {
  const radius = Math.min(width, height) * 0.16;
  const shape = new THREE.Shape();
  const x = -width / 2;
  const y = -height / 2;

  shape.moveTo(x + radius, y);
  shape.lineTo(x + width - radius, y);
  shape.quadraticCurveTo(x + width, y, x + width, y + radius);
  shape.lineTo(x + width, y + height - radius);
  shape.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  shape.lineTo(x + radius, y + height);
  shape.quadraticCurveTo(x, y + height, x, y + height - radius);
  shape.lineTo(x, y + radius);
  shape.quadraticCurveTo(x, y, x + radius, y);

  const geometry = new THREE.ExtrudeGeometry(shape, {
    depth,
    bevelEnabled: true,
    bevelThickness: 0.035,
    bevelSize: 0.035,
    bevelSegments: 2,
    curveSegments: 10,
  });

  geometry.computeBoundingBox();
  const box = geometry.boundingBox;
  if (box) {
    const position = geometry.attributes.position;
    const uv = new Float32Array(position.count * 2);
    const spanX = box.max.x - box.min.x || 1;
    const spanY = box.max.y - box.min.y || 1;
    for (let i = 0; i < position.count; i += 1) {
      uv[i * 2] = (position.getX(i) - box.min.x) / spanX;
      uv[i * 2 + 1] = (position.getY(i) - box.min.y) / spanY;
    }
    geometry.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  }

  return geometry;
};

const HeroScene = () => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const readyRef = useRef(false);
  const [webglFailed, setWebglFailed] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let renderer: THREE.WebGLRenderer;

    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      setWebglFailed(true);
      return;
    }

    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(container.clientWidth, container.clientHeight, false);
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
    camera.position.set(0, 0, 9);

    const group = new THREE.Group();
    scene.add(group);

    scene.add(new THREE.AmbientLight(0xffffff, 1.45));

    const keyLight = new THREE.DirectionalLight(0xfff4dd, 2.1);
    keyLight.position.set(4, 6, 8);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0xffc85e, 1.1);
    rimLight.position.set(-6, -3, 4);
    scene.add(rimLight);

    const textures: THREE.Texture[] = [];
    const geometries: THREE.BufferGeometry[] = [];
    const materials: THREE.Material[] = [];
    const cardMeshes: { mesh: THREE.Mesh; spec: CardSpec; base: THREE.Vector3 }[] = [];

    CARDS.forEach((spec) => {
      const texture = createCardTexture(spec);
      const geometry = roundedCardGeometry(spec.size[0], spec.size[1], spec.depth);
      const faceMaterial = new THREE.MeshStandardMaterial({
        map: texture ?? null,
        color: texture ? 0xffffff : new THREE.Color(spec.background),
        roughness: 0.62,
        metalness: 0.03,
      });
      const edgeMaterial = new THREE.MeshStandardMaterial({
        color: new THREE.Color(spec.background).multiplyScalar(0.86),
        roughness: 0.7,
        metalness: 0.03,
      });

      if (texture) textures.push(texture);
      geometries.push(geometry);
      materials.push(faceMaterial, edgeMaterial);

      const mesh = new THREE.Mesh(geometry, [faceMaterial, edgeMaterial]);
      mesh.position.set(spec.position[0], spec.position[1], spec.position[2]);
      mesh.rotation.set(spec.rotation[0], spec.rotation[1], spec.rotation[2]);
      group.add(mesh);
      cardMeshes.push({ mesh, spec, base: mesh.position.clone() });
    });

    const orbs: { mesh: THREE.Mesh; base: THREE.Vector3; phase: number; amplitude: number }[] = [];
    const orbSpecs = [
      { color: 0x1fa97a, size: 0.24, position: [-2.85, 2.25, 1.1], amplitude: 0.18 },
      { color: 0xe85c43, size: 0.18, position: [2.75, 0.35, 1.4], amplitude: 0.24 },
      { color: 0xf7c443, size: 0.3, position: [0.35, 2.45, 0.2], amplitude: 0.2 },
      { color: 0x12233a, size: 0.12, position: [-0.6, -2.45, 1.2], amplitude: 0.26 },
      { color: 0x4c8df6, size: 0.14, position: [2.2, -2.15, 0.6], amplitude: 0.22 },
    ];

    orbSpecs.forEach((orb, index) => {
      const geometry = new THREE.SphereGeometry(orb.size, 24, 24);
      const material = new THREE.MeshStandardMaterial({
        color: orb.color,
        roughness: 0.42,
        metalness: 0.08,
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(orb.position[0], orb.position[1], orb.position[2]);
      geometries.push(geometry);
      materials.push(material);
      group.add(mesh);
      orbs.push({ mesh, base: mesh.position.clone(), phase: index * 1.3, amplitude: orb.amplitude });
    });

    const ringGeometry = new THREE.TorusGeometry(3.05, 0.026, 12, 96);
    const ringMaterial = new THREE.MeshStandardMaterial({ color: 0x12233a, roughness: 0.8 });
    const ring = new THREE.Mesh(ringGeometry, ringMaterial);
    ring.position.set(0, 0, -2.1);
    ring.rotation.set(0.35, 0.12, 0);
    geometries.push(ringGeometry);
    materials.push(ringMaterial);
    group.add(ring);

    const pointer = { x: 0, y: 0 };
    const smooth = { x: 0, y: 0 };

    const handlePointerMove = (event: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = ((event.clientY - rect.top) / rect.height) * 2 - 1;
    };

    const handlePointerLeave = () => {
      pointer.x = 0;
      pointer.y = 0;
    };

    container.addEventListener('pointermove', handlePointerMove);
    container.addEventListener('pointerleave', handlePointerLeave);

    const resize = () => {
      const width = container.clientWidth;
      const height = container.clientHeight;
      if (!width || !height) return;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };

    resize();
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(container);

    const clock = new THREE.Clock();
    let frameId = 0;
    let isVisible = true;

    const renderFrame = (animate: boolean) => {
      const elapsed = clock.getElapsedTime();

      if (animate) {
        smooth.x += (pointer.x - smooth.x) * 0.06;
        smooth.y += (pointer.y - smooth.y) * 0.06;

        group.rotation.y = smooth.x * 0.34 + Math.sin(elapsed * 0.22) * 0.08;
        group.rotation.x = smooth.y * 0.24 + Math.cos(elapsed * 0.19) * 0.05;

        cardMeshes.forEach(({ mesh, spec, base }) => {
          mesh.position.y = base.y + Math.sin(elapsed * 0.9 * spec.drift + spec.phase) * 0.11;
          mesh.position.x = base.x + Math.cos(elapsed * 0.6 * spec.drift + spec.phase) * 0.05;
          mesh.rotation.z = spec.rotation[2] + Math.sin(elapsed * 0.7 + spec.phase) * 0.03;
        });

        orbs.forEach(({ mesh, base, phase, amplitude }) => {
          mesh.position.y = base.y + Math.sin(elapsed * 0.8 + phase) * amplitude;
          mesh.position.x = base.x + Math.cos(elapsed * 0.55 + phase) * amplitude * 0.6;
        });

        ring.rotation.z = elapsed * 0.05;
      } else {
        group.rotation.set(0.04, -0.06, 0);
      }

      renderer.render(scene, camera);

      if (!readyRef.current) {
        readyRef.current = true;
        setReady(true);
      }
    };

    if (prefersReduced) {
      renderFrame(false);
    } else {
      const loop = () => {
        frameId = requestAnimationFrame(loop);
        if (!isVisible) return;
        renderFrame(true);
      };
      loop();
    }

    const visibilityObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          isVisible = entry.isIntersecting;
        });
      },
      { threshold: 0.02 },
    );
    visibilityObserver.observe(container);

    return () => {
      cancelAnimationFrame(frameId);
      visibilityObserver.disconnect();
      resizeObserver.disconnect();
      container.removeEventListener('pointermove', handlePointerMove);
      container.removeEventListener('pointerleave', handlePointerLeave);
      geometries.forEach((geometry) => geometry.dispose());
      materials.forEach((material) => material.dispose());
      textures.forEach((texture) => texture.dispose());
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  const showFallback = webglFailed || !ready;

  return (
    <div className="relative h-full w-full">
      <div
        className="pointer-events-none absolute inset-[14%] -z-10 rounded-full bg-brand/35 blur-2xl"
        aria-hidden="true"
      />
      <div
        ref={containerRef}
        className="relative h-full w-full touch-pan-y"
        role="img"
        aria-label="کارت‌های سه‌بعدی شناور واژگان انگلیسی: Hello، Speak، Travel، Easy و Talk"
      />

      {showFallback && (
        <div className="pointer-events-none absolute inset-0 grid grid-cols-2 content-center gap-3 p-2 [perspective:900px] sm:gap-4 sm:p-4">
          {CARDS.map((card, index) => (
            <div
              key={card.word}
              className={`animate-bob rounded-[22px] border-2 border-ink px-4 py-5 text-center shadow-hard ${
                index === 0 ? 'col-span-2 justify-self-center w-[78%]' : ''
              } ${index === 4 ? 'col-span-2 justify-self-center w-[66%]' : ''}`}
              style={{
                background: card.background,
                color: card.foreground,
                animationDelay: `${index * 420}ms`,
                animationDuration: `${6 + index}s`,
                transform: `rotate(${card.rotation[2] * 42}deg)`,
              }}
            >
              <span className="block font-latin text-[clamp(1.15rem,3.4vw,2rem)] leading-none">{card.word}</span>
              <span className="mt-2 inline-block rounded-full border-2 border-ink px-2.5 py-0.5 text-[10px] font-bold">
                {card.tag}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HeroScene;
