import { useState } from 'react';
import { Check, RotateCcw, Trophy, X } from 'lucide-react';
import { sampleQuiz } from '@/lib/landing-content';
import Reveal from './Reveal';

const POINTS_PER_QUESTION = 5;

const Practice = () => {
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [submitted, setSubmitted] = useState(false);

  const answeredCount = Object.keys(answers).length;
  const correctCount = sampleQuiz.filter((question) => answers[question.id] === question.answer).length;
  const score = correctCount * POINTS_PER_QUESTION;

  const select = (questionId: string, optionIndex: number) => {
    if (submitted) return;
    setAnswers((current) => ({ ...current, [questionId]: optionIndex }));
  };

  const reset = () => {
    setAnswers({});
    setSubmitted(false);
  };

  return (
    <section id="practice" className="relative py-20 lg:py-28">
      <div className="u-shell grid items-start gap-8 lg:grid-cols-[0.9fr_1.1fr] lg:gap-12">
        <Reveal>
          <span className="u-eyebrow">نمونه تمرین</span>
          <h2 className="mt-5 text-[clamp(1.9rem,3.6vw,3rem)] leading-[1.28]">
            یک آزمون چهارگزینه‌ای
            <br className="hidden sm:block" /> را همین‌جا <span className="u-marker">امتحان کن</span>
          </h2>
          <p className="mt-4 max-w-[44ch] text-[16px] leading-[2] text-ink-soft">
            این چهار سؤال، نمونه‌ی تمرینی آماده‌شده برای آشنایی با فرمت آزمون است؛ لزوماً بخشی از مسیر درس فعلی
            تو نیست. بعد از ثبت، پاسخ درست و دلیل کوتاه هر سؤال نمایش داده می‌شود.
          </p>

          <ul className="mt-7 space-y-3 text-[14px] leading-[1.9] text-ink-soft">
            <li className="flex items-start gap-2.5">
              <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-brand-deep" aria-hidden="true" />
              مجموع امتیاز آزمون‌های واقعی ۲۰ است؛ هر سؤال سهم مشخصی دارد.
            </li>
            <li className="flex items-start gap-2.5">
              <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-brand-deep" aria-hidden="true" />
              هر آزمون برای هر کاربر فقط یک‌بار قابل انجام است.
            </li>
            <li className="flex items-start gap-2.5">
              <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-brand-deep" aria-hidden="true" />
              در این نمونه هر پاسخ درست ۵ امتیاز دارد تا جمعاً ۲۰ شود.
            </li>
          </ul>
        </Reveal>

        <Reveal delay={120}>
          <div className="rounded-card border-2 border-ink bg-surface p-6 shadow-hard-lg sm:p-8">
            <div className="flex items-center justify-between gap-3 border-b-2 border-dashed border-ink/15 pb-4">
              <div className="flex items-center gap-2">
                <span className="grid h-9 w-9 place-items-center rounded-full border-2 border-ink bg-brand">
                  <Trophy className="h-4 w-4 text-ink" strokeWidth={2.4} aria-hidden="true" />
                </span>
                <div>
                  <span className="block font-latin text-[10px] tracking-[0.2em] text-ink/40">SAMPLE QUIZ</span>
                  <span className="block text-[13.5px] font-bold text-ink">خانواده و فعالیت‌ها</span>
                </div>
              </div>
              <span className="rounded-full border-2 border-ink bg-paper px-3 py-1 text-[12px] font-bold text-ink">
                {submitted ? `${score} از ۲۰` : `${answeredCount} از ${sampleQuiz.length}`}
              </span>
            </div>

            <ol className="mt-5 space-y-6">
              {sampleQuiz.map((question, questionIndex) => {
                const chosen = answers[question.id];
                const isCorrect = chosen === question.answer;
                return (
                  <li key={question.id}>
                    <p className="text-[15px] font-bold leading-[1.9] text-ink" dir="ltr" style={{ textAlign: 'left' }}>
                      {questionIndex + 1}. {question.prompt}
                    </p>
                    <div className="mt-3 grid gap-2 sm:grid-cols-2">
                      {question.options.map((option, optionIndex) => {
                        const selected = chosen === optionIndex;
                        const showCorrect = submitted && optionIndex === question.answer;
                        const showWrong = submitted && selected && !isCorrect;

                        let stateClass = 'border-ink/20 bg-surface text-ink-soft hover:border-ink/60';
                        if (selected && !submitted) stateClass = 'border-ink bg-brand/30 text-ink';
                        if (showCorrect) stateClass = 'border-brand-mint bg-brand-mint/12 text-ink';
                        if (showWrong) stateClass = 'border-brand-coral bg-brand-coral/10 text-ink';

                        return (
                          <button
                            key={option}
                            type="button"
                            onClick={() => select(question.id, optionIndex)}
                            aria-pressed={selected}
                            aria-label={`گزینه ${option}`}
                            className={`flex min-h-[44px] items-center justify-between gap-2 rounded-2xl border-2 px-4 py-2.5 text-[14px] font-medium transition-colors ${stateClass}`}
                          >
                            <span dir="ltr">{option}</span>
                            {showCorrect && <Check className="h-4 w-4 text-brand-mint" strokeWidth={3} aria-hidden="true" />}
                            {showWrong && <X className="h-4 w-4 text-brand-coral" strokeWidth={3} aria-hidden="true" />}
                          </button>
                        );
                      })}
                    </div>
                    {submitted && (
                      <p className="mt-2 rounded-xl bg-paper px-3 py-2 text-[12.5px] leading-[1.85] text-ink-soft">
                        {question.explanation}
                      </p>
                    )}
                  </li>
                );
              })}
            </ol>

            <div className="mt-6 flex flex-col gap-3 border-t-2 border-dashed border-ink/15 pt-5 sm:flex-row sm:items-center">
              {!submitted ? (
                <button
                  type="button"
                  onClick={() => setSubmitted(true)}
                  disabled={answeredCount < sampleQuiz.length}
                  className="u-btn u-btn-primary w-full disabled:cursor-not-allowed disabled:opacity-45 disabled:shadow-none sm:w-auto"
                >
                  بررسی پاسخ‌ها
                </button>
              ) : (
                <button type="button" onClick={reset} className="u-btn u-btn-dark w-full sm:w-auto">
                  <RotateCcw className="h-4 w-4" strokeWidth={2.6} aria-hidden="true" />
                  تلاش دوباره
                </button>
              )}
              <p className="text-[12.5px] leading-[1.8] text-ink/50">
                {submitted
                  ? correctCount === sampleQuiz.length
                    ? 'همه‌ی پاسخ‌ها درست بود. حالا یک درس ویدیویی را شروع کن.'
                    : `${sampleQuiz.length - correctCount} پاسخ نادرست بود؛ دلیل هرکدام را در پایین سؤال ببین.`
                  : answeredCount < sampleQuiz.length
                    ? `برای بررسی، به ${sampleQuiz.length - answeredCount} سؤال دیگر پاسخ بده.`
                    : 'همه‌ی سؤال‌ها پاسخ داده شد.'}
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default Practice;
