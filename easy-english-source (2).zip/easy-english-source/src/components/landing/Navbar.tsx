import { useEffect, useState } from 'react';
import { Menu, X, ArrowUpLeft } from 'lucide-react';
import { navLinks } from '@/lib/landing-content';

const Logo = () => (
  <a href="#home" className="group inline-flex items-center gap-3" aria-label="ایزی اینگلیش، صفحه اصلی">
    <span className="relative grid h-11 w-11 shrink-0 place-items-center rounded-[16px] border-2 border-ink bg-brand shadow-[3px_3px_0_#12233A] transition-transform duration-200 group-hover:-rotate-6">
      <span className="font-latin text-[19px] leading-none text-ink">Ee</span>
    </span>
    <span className="flex flex-col leading-none">
      <span className="font-latin text-[17px] tracking-wide text-ink">EASY ENGLISH</span>
      <span className="mt-1 text-[12px] font-medium text-ink-soft">آموزش زبان انگلیسی</span>
    </span>
  </a>
);

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      const scrollTop = window.scrollY;
      const height = document.documentElement.scrollHeight - window.innerHeight;
      setScrolled(scrollTop > 24);
      setProgress(height > 0 ? Math.min(scrollTop / height, 1) : 0);
    };

    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <header className="sticky top-0 z-50">
      <div
        className={`border-b-2 transition-colors duration-300 ${
          scrolled
            ? 'border-ink/15 bg-paper/92 backdrop-blur-md'
            : 'border-transparent bg-paper'
        }`}
      >
        <div className="u-shell flex h-[76px] items-center justify-between gap-4">
          <Logo />

          <nav aria-label="منوی اصلی" className="hidden items-center gap-1 lg:flex">
            {navLinks.map((link) => (
              <a
                key={link.id}
                href={`#${link.id}`}
                className="rounded-full px-4 py-2 text-[15px] font-medium text-ink-soft transition-colors hover:bg-brand/30 hover:text-ink"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            <a href="#how" className="u-btn u-btn-primary text-[14px]">
              شروع از تعیین سطح
              <ArrowUpLeft className="h-4 w-4" strokeWidth={2.6} />
            </a>
          </div>

          <button
            type="button"
            onClick={() => setOpen((value) => !value)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? 'بستن منو' : 'باز کردن منو'}
            className="grid h-11 w-11 place-items-center rounded-full border-2 border-ink bg-surface shadow-hard-sm transition-transform active:translate-y-0.5 lg:hidden"
          >
            {open ? <X className="h-5 w-5" strokeWidth={2.6} /> : <Menu className="h-5 w-5" strokeWidth={2.6} />}
          </button>
        </div>
      </div>

      <div className="h-[3px] w-full bg-ink/10" aria-hidden="true">
        <div
          className="h-full bg-brand-deep transition-[width] duration-150 ease-out"
          style={{ width: `${progress * 100}%` }}
        />
      </div>

      {open && (
        <div id="mobile-menu" className="border-b-2 border-ink bg-paper lg:hidden">
          <nav aria-label="منوی موبایل" className="u-shell flex flex-col gap-1 py-5">
            {navLinks.map((link) => (
              <a
                key={link.id}
                href={`#${link.id}`}
                onClick={() => setOpen(false)}
                className="rounded-2xl px-4 py-3 text-[16px] font-medium text-ink transition-colors hover:bg-brand/30"
              >
                {link.label}
              </a>
            ))}
            <a
              href="#how"
              onClick={() => setOpen(false)}
              className="u-btn u-btn-primary mt-3 w-full"
            >
              شروع از تعیین سطح
              <ArrowUpLeft className="h-4 w-4" strokeWidth={2.6} />
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Navbar;
