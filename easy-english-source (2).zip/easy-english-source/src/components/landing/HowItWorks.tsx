import { UserPlus, PenLine, Gauge, MonitorSmartphone } from 'lucide-react';
import { dashboardItems, startSteps } from '@/lib/landing-content';
import Reveal from './Reveal';

const icons = {
  account: UserPlus,
  write: PenLine,
  level: Gauge,
} as const;

const HowItWorks = () => (
  <section id="how" className="relative py-20 lg:py-28">
    <div className="u-shell">
      <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
        <Reveal className="max-w-xl">
          <span className="u-eyebrow">شروع کار</span>
          <h2 className="mt-5 text-[clamp(1.9rem,3.6vw,3rem)] leading-[1.28]">
            از یک نمونه‌ی کوتاه تا <span className="u-marker">مسیر شخصی</span> تو
          </h2>
          <p className="mt-4 text-[16px] leading-[1.95] text-ink-soft">
            لازم نیست آزمون سختی بدهی. یک پاراگراف کوتاه می‌نویسی و مسیر بر همان اساس تنظیم می‌شود.
          </p>
        </Reveal>
      </div>

      <ol className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {startSteps.map((step, index) => {
          const Icon = icons[step.icon as keyof typeof icons];
          return (
            <Reveal
              as="li"
              key={step.step}
              delay={index * 110}
              className="group relative flex h-full flex-col rounded-card border-2 border-ink bg-surface p-7 shadow-hard transition-all duration-300 hover:-translate-y-1.5 hover:shadow-hard-lg"
            >
              <div className="flex items-start justify-between">
                <span className="grid h-14 w-14 place-items-center rounded-2xl border-2 border-ink bg-brand transition-transform duration-300 group-hover:-rotate-6">
                  <Icon className="h-6 w-6 text-ink" strokeWidth={2.2} aria-hidden="true" />
                </span>
                <span className="font-display text-[38px] leading-none text-ink/12">{step.step}</span>
              </div>

              <span className="mt-6 font-latin text-[10px] tracking-[0.24em] text-ink/40">{step.english}</span>
              <h3 className="mt-2 text-[22px] leading-snug">{step.title}</h3>
              <p className="mt-3 text-[15px] leading-[1.9] text-ink-soft">{step.description}</p>
            </Reveal>
          );
        })}
      </ol>

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <Reveal className="rounded-card border-2 border-dashed border-ink/25 bg-paper-deep/60 p-6 sm:p-7">
          <h3 className="text-[19px] leading-snug">قوانین حساب کاربری</h3>
          <ul className="mt-4 space-y-2.5 text-[14px] leading-[1.9] text-ink-soft">
            <li>نام کاربری حداقل ۳ نویسه و شامل حروف انگلیسی، عدد یا زیرخط باشد.</li>
            <li>رمز عبور حداقل ۱۰ نویسه و شامل حرف و عدد باشد؛ تکرار رمز هم لازم است.</li>
            <li>در ثبت‌نام، رضایت برای ارسال نوشته‌ی تعیین سطح به ارزیابی هوش مصنوعی گرفته می‌شود.</li>
            <li>در ارزیابی فقط متن نوشته بررسی می‌شود؛ نام و اطلاعات حساب ارسال نمی‌شوند.</li>
            <li>گزینه‌ی «مرا به خاطر بسپار» برای ورودهای بعدی در دسترس است.</li>
            <li>بازیابی خودکار رمز از راه ایمیل فعلاً ارائه نشده است؛ در این حالت از پشتیبانی انسانی کمک بگیر.</li>
          </ul>
        </Reveal>

        <Reveal delay={100} className="rounded-card border-2 border-ink/12 bg-surface p-6 sm:p-7">
          <span className="grid h-11 w-11 place-items-center rounded-2xl border-2 border-ink bg-paper">
            <MonitorSmartphone className="h-5 w-5 text-ink" strokeWidth={2.2} aria-hidden="true" />
          </span>
          <h3 className="mt-4 text-[19px] leading-snug">داشبورد چه چیزی نشان می‌دهد</h3>
          <ul className="mt-4 space-y-2 text-[14px] leading-[1.85] text-ink-soft">
            {dashboardItems.map((item) => (
              <li key={item} className="flex items-start gap-2">
                <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-brand-deep" aria-hidden="true" />
                {item}
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </div>
  </section>
);

export default HowItWorks;
