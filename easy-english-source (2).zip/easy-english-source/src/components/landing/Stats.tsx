import { facts } from '@/lib/landing-content';
import useCountUp from '@/hooks/useCountUp';
import Reveal from './Reveal';

const toPersianDigits = (value: string) =>
  value.replace(/[0-9]/g, (digit) => '۰۱۲۳۴۵۶۷۸۹'[Number(digit)]);

const FactValue = ({ value, suffix }: { value: number; suffix: string }) => {
  const { ref, value: current } = useCountUp(value);
  return (
    <span ref={ref} className="font-display text-[clamp(1.9rem,3.4vw,2.6rem)] leading-none text-ink">
      {toPersianDigits(String(Math.round(current)))}
      <span className="text-[0.5em] text-ink-soft">{suffix}</span>
    </span>
  );
};

const Stats = () => (
  <section aria-label="نمای کلی پلتفرم" className="relative">
    <div className="u-shell">
      <Reveal className="u-card relative overflow-hidden bg-surface px-5 py-8 sm:px-8 lg:px-10">
        <div className="u-grid-paper pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" />
        <dl className="relative grid grid-cols-2 gap-y-8 sm:grid-cols-4">
          {facts.map((fact, index) => (
            <Reveal
              key={fact.label}
              delay={index * 90}
              className="flex flex-col items-center gap-2 border-ink/10 px-2 text-center sm:border-l sm:first:border-l-0"
            >
              <span className="font-latin text-[10px] tracking-[0.22em] text-ink/35">{fact.english}</span>
              <FactValue value={fact.value} suffix={fact.suffix} />
              <dt className="text-[13.5px] font-medium text-ink-soft">{fact.label}</dt>
            </Reveal>
          ))}
        </dl>
      </Reveal>
    </div>
  </section>
);

export default Stats;
