import { useState } from 'react';
import { Plus } from 'lucide-react';
import { faqs } from '@/lib/landing-content';
import Reveal from './Reveal';

const Faq = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="faq" className="relative bg-paper-deep/60 py-20 lg:py-28">
      <div className="u-shell grid gap-10 lg:grid-cols-[0.75fr_1fr] lg:gap-14">
        <Reveal>
          <span className="u-eyebrow">سوالات متداول</span>
          <h2 className="mt-5 text-[clamp(1.9rem,3.4vw,2.8rem)] leading-[1.3]">
            هر چیزی که قبل از شروع
            <br className="hidden md:block" /> باید بدانی
          </h2>
          <p className="mt-4 text-[15px] leading-[1.95] text-ink-soft">
            جواب سوالت اینجا نبود؟ برای مشکلی که به بررسی حساب یا محتوای خاص نیاز دارد با پشتیبانی انسانی تماس بگیر؛
            اطلاعات ورود یا رمز را در پیام ننویس.
          </p>
          <a href="#progress" className="u-btn u-btn-ghost mt-6 text-[14px]">
            دیدن محدودیت‌ها
          </a>
        </Reveal>

        <Reveal delay={100}>
          <ul className="divide-y-2 divide-dashed divide-ink/15 overflow-hidden rounded-card border-2 border-ink bg-surface shadow-hard">
            {faqs.map((faq, index) => {
              const isOpen = openIndex === index;
              const panelId = `faq-panel-${index}`;
              const buttonId = `faq-button-${index}`;

              return (
                <li key={faq.question}>
                  <h3>
                    <button
                      id={buttonId}
                      type="button"
                      onClick={() => setOpenIndex(isOpen ? null : index)}
                      aria-expanded={isOpen}
                      aria-controls={panelId}
                      className="flex w-full items-center justify-between gap-4 px-5 py-5 text-right transition-colors hover:bg-brand/10 sm:px-6"
                    >
                      <span className="text-[16px] font-bold leading-snug text-ink">{faq.question}</span>
                      <span
                        className={`grid h-9 w-9 shrink-0 place-items-center rounded-full border-2 border-ink transition-transform duration-300 ${
                          isOpen ? 'rotate-[135deg] bg-brand' : 'bg-paper'
                        }`}
                        aria-hidden="true"
                      >
                        <Plus className="h-4 w-4" strokeWidth={3} />
                      </span>
                    </button>
                  </h3>
                  <div
                    id={panelId}
                    role="region"
                    aria-labelledby={buttonId}
                    hidden={!isOpen}
                    className="px-5 pb-5 sm:px-6"
                  >
                    <p className="border-r-2 border-brand pr-4 text-[14.5px] leading-[2] text-ink-soft">
                      {faq.answer}
                    </p>
                  </div>
                </li>
              );
            })}
          </ul>
        </Reveal>
      </div>
    </section>
  );
};

export default Faq;
