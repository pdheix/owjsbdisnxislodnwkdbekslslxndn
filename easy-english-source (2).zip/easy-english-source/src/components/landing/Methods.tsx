import { CheckCircle2, MonitorPlay, Wrench, ClipboardList, Mic } from 'lucide-react';
import { methods } from '@/lib/landing-content';
import Reveal from './Reveal';

const toneStyles: Record<string, { chip: string; accent: string }> = {
  amber: { chip: 'bg-brand text-ink', accent: 'bg-brand' },
  coral: { chip: 'bg-brand-coral text-white', accent: 'bg-brand-coral' },
  mint: { chip: 'bg-brand-mint text-white', accent: 'bg-brand-mint' },
  sky: { chip: 'bg-brand-sky text-white', accent: 'bg-brand-sky' },
  paper: { chip: 'bg-ink text-paper', accent: 'bg-ink' },
};

const icons = {
  video: MonitorPlay,
  fix: Wrench,
  quiz: ClipboardList,
  speaking: Mic,
} as const;

const Methods = () => (
  <section id="methods" className="relative overflow-hidden bg-paper-deep/60 py-20 lg:py-28">
    <div className="u-shell">
      <Reveal className="max-w-2xl">
        <span className="u-eyebrow">روش‌ها</span>
        <h2 className="mt-5 text-[clamp(1.9rem,3.6vw,3rem)] leading-[1.28]">
          چهار روش تمرین، <span className="u-marker">بدون کار اضافه</span>
        </h2>
        <p className="mt-4 text-[16px] leading-[1.95] text-ink-soft">
          هر روش یک مهارت جدا را تمرین می‌دهد و همه‌ی امتیازها در یک مسیر جمع می‌شوند تا بدانی کجای مسیر هستی.
        </p>
      </Reveal>

      <ul className="mt-12 grid gap-5 lg:grid-cols-2">
        {methods.map((method, index) => {
          const Icon = icons[method.id as keyof typeof icons];
          const tone = toneStyles[method.tone] ?? toneStyles.amber;
          return (
            <Reveal
              as="li"
              key={method.id}
              delay={index * 90}
              className="group flex h-full flex-col rounded-card border-2 border-ink bg-surface p-6 shadow-hard transition-transform duration-300 hover:-translate-y-1.5 sm:p-7"
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl border-2 border-ink ${tone.accent}`}>
                    <Icon className="h-5 w-5 text-ink" strokeWidth={2.2} aria-hidden="true" />
                  </span>
                  <div>
                    <span className="font-latin text-[10px] tracking-[0.22em] text-ink/40">{method.english}</span>
                    <h3 className="mt-1 text-[20px] leading-tight">{method.title}</h3>
                  </div>
                </div>
                <span className={`rounded-full border-2 border-ink px-3 py-1 text-[11.5px] font-bold ${tone.chip}`}>
                  {method.tag}
                </span>
              </div>

              <p className="mt-4 text-[14.5px] leading-[1.95] text-ink-soft">{method.description}</p>

              <ul className="mt-4 space-y-2.5 border-t-2 border-dashed border-ink/15 pt-4">
                {method.bullets.map((bullet) => (
                  <li key={bullet} className="flex items-start gap-2 text-[13.5px] leading-[1.85] text-ink">
                    <CheckCircle2 className="mt-1 h-4 w-4 shrink-0 text-brand-mint" strokeWidth={2.6} aria-hidden="true" />
                    {bullet}
                  </li>
                ))}
              </ul>
            </Reveal>
          );
        })}
      </ul>
    </div>
  </section>
);

export default Methods;
