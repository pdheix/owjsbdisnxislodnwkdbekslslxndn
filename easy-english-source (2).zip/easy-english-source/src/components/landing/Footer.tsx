import { ArrowUp, Mail, ShieldCheck } from 'lucide-react';
import { navLinks } from '@/lib/landing-content';

const Footer = () => (
  <footer className="relative bg-night pt-14 pb-8 text-paper">
    <div className="u-shell">
      <div className="rounded-card border-2 border-brand/40 bg-gradient-to-l from-[#152438] to-[#101d2e] p-7 sm:p-10">
        <div className="flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-center">
          <div>
            <h2 className="text-[clamp(1.6rem,3vw,2.4rem)] leading-snug text-paper">
              امروز یک درس کوتاه <span className="text-brand">تمام کن</span>
            </h2>
            <p className="mt-2 max-w-[52ch] text-[14.5px] leading-[1.9] text-paper/70">
              با یک نمونه‌ی نوشتاری کوتاه شروع کن؛ سطح تقریبی‌ات را می‌بینی و مسیر تمرین برایت تنظیم می‌شود.
            </p>
          </div>
          <a href="#how" className="u-btn u-btn-primary shrink-0">
            شروع از تعیین سطح
            <ArrowUp className="h-[18px] w-[18px]" strokeWidth={2.8} aria-hidden="true" />
          </a>
        </div>
      </div>

      <div className="mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.5fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-3">
            <span className="grid h-11 w-11 place-items-center rounded-[16px] border-2 border-brand bg-brand text-ink">
              <span className="font-latin text-[19px] leading-none">Ee</span>
            </span>
            <span className="flex flex-col leading-none">
              <span className="font-latin text-[17px] tracking-wide text-paper">EASY ENGLISH</span>
              <span className="mt-1 text-[12px] text-paper/60">تمرین انگلیسی، فارسی‌زبان</span>
            </span>
          </div>
          <p className="mt-5 max-w-[40ch] text-[14px] leading-[1.95] text-paper/65">
            پلتفرم تمرین انگلیسی با درس‌های کوتاه، ویدیو، تمرین شنیداری، مرور متن، آزمون و تمرین گفتاری. سطح
            CEFR همیشه تخمینی است و مدرک رسمی محسوب نمی‌شود.
          </p>
          <div className="mt-5 flex items-start gap-2 rounded-2xl border border-paper/20 p-3 text-[12.5px] leading-[1.85] text-paper/60">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-brand" strokeWidth={2.2} aria-hidden="true" />
            پشتیبانی هرگز رمز عبور، کد تأیید یا کلیدهای شخصی را درخواست نمی‌کند.
          </div>
        </div>

        <nav aria-label="لینک‌های فوتر">
          <h3 className="text-[15px] font-bold text-paper">بخش‌های صفحه</h3>
          <ul className="mt-4 space-y-2.5">
            {navLinks.map((link) => (
              <li key={link.id}>
                <a href={`#${link.id}`} className="text-[14px] text-paper/65 transition-colors hover:text-brand">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h3 className="text-[15px] font-bold text-paper">پشتیبانی</h3>
          <ul className="mt-4 space-y-2.5 text-[14px] text-paper/65">
            <li className="flex items-start gap-2.5">
              <Mail className="mt-0.5 h-4 w-4 shrink-0 text-brand" strokeWidth={2.2} aria-hidden="true" />
              <a href="mailto:support@easyenglish.ir" dir="ltr" className="transition-colors hover:text-brand">
                support@easyenglish.ir
              </a>
            </li>
            <li className="flex items-start gap-2.5">
              <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-brand" aria-hidden="true" />
              اگر رمزت را فراموش کرده‌ای، بازیابی خودکار ایمیل فعلاً ارائه نشده است؛ با پشتیبانی انسانی تماس بگیر و
              رمز را در پیام ننویس.
            </li>
            <li className="flex items-start gap-2.5">
              <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-brand" aria-hidden="true" />
              برای مشکلی که به بررسی حساب نیاز دارد، تصویر پیام خطا را بدون اطلاعات حساس بفرست.
            </li>
          </ul>
        </div>
      </div>

      <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-paper/15 pt-6 text-[12.5px] text-paper/45 sm:flex-row">
        <p>© ۱۴۰۴ ایزی اینگلیش. همه حقوق محفوظ است.</p>
        <div className="flex items-center gap-3">
          <img
            src="/assets/perham-portrait.jpg"
            alt="پرهام دباغی، کد نویس و توسعه‌دهنده ارشد"
            width={44}
            height={44}
            loading="lazy"
            className="h-11 w-11 rounded-full border-2 border-brand object-cover"
          />
          <p className="leading-[1.7]">
            <span className="block font-bold text-paper/80">پرهام دباغی</span>
            <span className="block">کد نویس و توسعه‌دهنده ارشد</span>
          </p>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;
