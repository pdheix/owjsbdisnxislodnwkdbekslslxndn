import { ArrowDown, MousePointerClick, Sparkles } from 'lucide-react';
import HeroScene from './HeroScene';

const Hero = () => (
  <section id="home" className="relative overflow-hidden pb-16 pt-10 sm:pt-14 lg:pb-24">
    <div
      className="pointer-events-none absolute -left-32 top-10 h-[420px] w-[420px] rounded-full bg-brand/30 blur-3xl"
      aria-hidden="true"
    />
    <div
      className="pointer-events-none absolute -right-24 bottom-0 hidden h-[300px] w-[300px] rounded-full bg-brand-mint/15 blur-3xl lg:block"
      aria-hidden="true"
    />

    <div className="u-shell relative grid items-center gap-10 lg:grid-cols-[1.06fr_0.94fr] lg:gap-6">
      <div className="order-2 lg:order-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="u-eyebrow">
            <span className="h-2 w-2 rounded-full bg-brand-mint" aria-hidden="true" />
            تمرین انگلیسی به فارسی
          </span>
          <span className="inline-flex items-center gap-1.5 rounded-full border-2 border-ink/15 bg-surface px-4 py-1.5 text-[12px] font-medium text-ink-soft">
            <Sparkles className="h-3.5 w-3.5 text-brand-deep" aria-hidden="true" />
            ویدیو، شنیداری، آزمون، گفتار
          </span>
        </div>

        <h1 className="mt-6 text-[clamp(2.4rem,5.4vw,4.5rem)] leading-[1.22]">
          انگلیسی را با{' '}
          <span className="u-marker">تمرین کوتاه</span>
          <br className="hidden sm:block" /> هر روز جلو ببر.
        </h1>

        <p className="mt-6 max-w-[48ch] text-[17px] leading-[1.95] text-ink-soft">
          ایزی اینگلیش یک پلتفرم فارسی‌زبان برای تمرین انگلیسی است. با یک نمونه‌ی نوشتاری کوتاه شروع می‌کنی،
          سطح تقریبی‌ات را می‌بینی و بعد با درس‌های کوتاه، ویدیو، تمرین شنیداری، مرور متن و فعالیت‌های تعاملی
          مسیر را ادامه می‌دهی.
        </p>

        <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
          <a href="#how" className="u-btn u-btn-primary w-full sm:w-auto">
            چطور کار می‌کند
            <ArrowDown className="h-[18px] w-[18px]" strokeWidth={2.8} aria-hidden="true" />
          </a>
          <a href="#practice" className="u-btn u-btn-ghost w-full sm:w-auto">
            <MousePointerClick className="h-[17px] w-[17px]" strokeWidth={2.8} aria-hidden="true" />
            امتحان یک تمرین نمونه
          </a>
        </div>

        <dl className="mt-10 grid max-w-lg grid-cols-3 gap-3 border-t-2 border-dashed border-ink/20 pt-6">
          {[
            { value: '۶ سطح', label: 'CEFR تخمینی' },
            { value: '۴ روش', label: 'تمرین متفاوت' },
            { value: '۸۰ نویسه', label: 'حداقل نمونه نوشته' },
          ].map((item) => (
            <div key={item.label}>
              <dt className="sr-only">{item.label}</dt>
              <dd>
                <span className="block font-display text-[21px] leading-none text-ink">{item.value}</span>
                <span className="mt-1.5 block text-[12.5px] leading-snug text-ink-soft">{item.label}</span>
              </dd>
            </div>
          ))}
        </dl>

        <p className="mt-5 text-[12.5px] leading-[1.9] text-ink/50">
          سطحی که می‌بینی تخمینی است و مدرک یا ارزیابی رسمی محسوب نمی‌شود.
        </p>
      </div>

      <div className="order-1 lg:order-2">
        <div className="relative mx-auto aspect-square w-full max-w-[560px]">
          <div
            className="pointer-events-none absolute inset-[8%] rounded-full border-2 border-dashed border-ink/20"
            aria-hidden="true"
          />
          <HeroScene />

          <div className="pointer-events-none absolute -bottom-2 right-2 hidden rotate-[3deg] items-center gap-2 rounded-2xl border-2 border-ink bg-surface px-4 py-2.5 shadow-hard-sm sm:flex">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-brand-mint text-[13px] font-bold text-white">
              ✓
            </span>
            <span className="text-[13px] font-bold text-ink">هر درس فقط چند دقیقه</span>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default Hero;
