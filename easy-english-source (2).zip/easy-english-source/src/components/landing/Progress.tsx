import { Repeat2, ShieldAlert, Sparkles, Timer } from 'lucide-react';
import { limitations, scoringRows } from '@/lib/landing-content';
import Reveal from './Reveal';

const progressHighlights = [
  {
    icon: Timer,
    title: 'مرور زمان‌بندی‌شده',
    text: 'برای تمرین ویدیویی، پاسخ ضعیف پس از ۱ روز، نتیجه‌ی متوسط پس از ۳ روز و نتیجه‌ی خوب پس از ۷ روز دوباره پیشنهاد می‌شود.',
  },
  {
    icon: Repeat2,
    title: 'پیشرفت قابل ادامه',
    text: 'اگر صفحه را ببندی یا دوباره وارد شوی، درس از همان مرحله‌ی ثبت‌شده ادامه پیدا می‌کند.',
  },
  {
    icon: Sparkles,
    title: 'تداوم روزانه',
    text: 'روزهایی که فعالیت یادگیری ثبت کرده‌ای نمایش داده می‌شود؛ تمرین کوتاه و منظم پیشنهاد می‌شود.',
  },
];

const Progress = () => (
  <section id="progress" className="relative overflow-hidden bg-night py-20 text-paper lg:py-28">
    <div
      className="pointer-events-none absolute -left-24 top-6 h-64 w-64 rounded-full bg-brand/20 blur-3xl"
      aria-hidden="true"
    />
    <div className="u-shell relative">
      <Reveal className="max-w-2xl">
        <span className="inline-flex items-center gap-2 rounded-full border-2 border-paper/25 px-4 py-1.5 text-[12px] font-bold tracking-[0.14em] text-paper/80">
          <span className="h-2 w-2 rounded-full bg-brand" aria-hidden="true" />
          امتیاز و مرور
        </span>
        <h2 className="mt-5 text-[clamp(1.9rem,3.6vw,3rem)] leading-[1.28] text-paper">
          امتیازها <span className="text-brand">ساده و شفاف</span> هستند
        </h2>
        <p className="mt-4 text-[16px] leading-[1.95] text-paper/70">
          هر فعالیت امتیاز مشخصی دارد و همه‌ی امتیازها در داشبورد و تاریخچه دیده می‌شوند.
        </p>
      </Reveal>

      <div className="mt-10 grid gap-5 lg:grid-cols-[0.95fr_1.05fr]">
        <Reveal className="rounded-card border-2 border-brand/40 bg-[#152438] p-6 sm:p-7">
          <h3 className="text-[19px] text-paper">جدول امتیازها</h3>
          <dl className="mt-4 divide-y divide-paper/12">
            {scoringRows.map((row) => (
              <div key={row.label} className="flex items-center justify-between gap-4 py-3.5">
                <dt className="text-[14px] leading-[1.8] text-paper/75">{row.label}</dt>
                <dd className="shrink-0 rounded-full border border-brand/50 px-3 py-1 text-[12.5px] font-bold text-brand">
                  {row.value}
                </dd>
              </div>
            ))}
          </dl>
        </Reveal>

        <div className="grid gap-4">
          {progressHighlights.map((item, index) => (
            <Reveal
              key={item.title}
              delay={index * 90}
              className="flex gap-4 rounded-card border-2 border-paper/15 bg-[#111f31] p-5"
            >
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl border-2 border-brand/50 text-brand">
                <item.icon className="h-5 w-5" strokeWidth={2.3} aria-hidden="true" />
              </span>
              <div>
                <h3 className="text-[16px] leading-snug text-paper">{item.title}</h3>
                <p className="mt-1.5 text-[13.5px] leading-[1.9] text-paper/65">{item.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>

      <Reveal delay={120} className="mt-6 rounded-card border-2 border-dashed border-paper/25 p-6 sm:p-7">
        <div className="flex items-center gap-2">
          <ShieldAlert className="h-5 w-5 text-brand" strokeWidth={2.3} aria-hidden="true" />
          <h3 className="text-[17px] text-paper">محدودیت‌هایی که باید بدانی</h3>
        </div>
        <ul className="mt-4 grid gap-2.5 sm:grid-cols-2">
          {limitations.map((item) => (
            <li key={item} className="flex items-start gap-2 text-[13.5px] leading-[1.9] text-paper/70">
              <span className="mt-[9px] h-1.5 w-1.5 shrink-0 rounded-full bg-brand" aria-hidden="true" />
              {item}
            </li>
          ))}
        </ul>
      </Reveal>
    </div>
  </section>
);

export default Progress;
