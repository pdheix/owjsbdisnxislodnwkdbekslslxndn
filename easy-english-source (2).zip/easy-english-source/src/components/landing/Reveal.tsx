import { useEffect, useRef, useState } from 'react';

type RevealTag = 'div' | 'section' | 'li' | 'article' | 'header' | 'footer' | 'span';

interface RevealProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  as?: RevealTag;
}

/**
 * Content is always rendered and visible. When it enters the viewport for the
 * first time, a short entrance animation plays. Nothing depends on scroll or
 * JavaScript to become readable.
 */
const Reveal = ({ children, className = '', delay = 0, as = 'div' }: RevealProps) => {
  const ref = useRef<HTMLElement | null>(null);
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (typeof IntersectionObserver === 'undefined') return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          setAnimated(true);
          observer.disconnect();
        });
      },
      { threshold: 0.1, rootMargin: '0px 0px -40px 0px' },
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  const Tag = as as React.ElementType;

  return (
    <Tag
      ref={ref}
      className={`${animated ? 'animate-fade-up' : ''} ${className}`}
      style={animated ? { animationDelay: `${delay}ms` } : undefined}
    >
      {children}
    </Tag>
  );
};

export default Reveal;
