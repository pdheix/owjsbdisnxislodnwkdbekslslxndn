import Navbar from '@/components/landing/Navbar';
import Hero from '@/components/landing/Hero';
import Stats from '@/components/landing/Stats';
import HowItWorks from '@/components/landing/HowItWorks';
import Methods from '@/components/landing/Methods';
import Practice from '@/components/landing/Practice';
import Progress from '@/components/landing/Progress';
import Faq from '@/components/landing/Faq';
import Footer from '@/components/landing/Footer';

const marqueeWords = ['WATCH', 'LISTEN', 'FILL', 'REVIEW', 'SPEAK', 'REPEAT', 'SCORE', 'GROW'];

const Ticker = () => (
  <div className="relative overflow-hidden border-y-2 border-ink bg-brand py-3" aria-hidden="true">
    <div className="flex w-max animate-marquee items-center gap-8 whitespace-nowrap">
      {[0, 1].map((copy) => (
        <div key={copy} className="flex items-center gap-8">
          {marqueeWords.map((word) => (
            <span
              key={`${copy}-${word}`}
              className="flex items-center gap-8 font-latin text-[15px] tracking-[0.18em] text-ink"
            >
              {word}
              <span className="h-1.5 w-1.5 rounded-full bg-ink/50" />
            </span>
          ))}
        </div>
      ))}
    </div>
  </div>
);

const Index = () => (
  <div className="min-h-screen bg-paper">
    <Navbar />
    <main>
      <Hero />
      <Ticker />
      <Stats />
      <HowItWorks />
      <Methods />
      <Practice />
      <Progress />
      <Faq />
    </main>
    <Footer />
  </div>
);

export default Index;
